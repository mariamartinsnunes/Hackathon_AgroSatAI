// Função do Vercel: /api/fogo?fonte=inpe&lat=-21.8&lon=-48.2&raio=45
// Busca os focos de fogo do dia e devolve só os que estão perto.
// Recebe localização GROSSA (1 casa decimal ≈ 11 km); a distância exata é calculada no celular.

const R = 6371;
const rad = (g) => (g * Math.PI) / 180;
function km(a, b) {
  const h = Math.sin(rad(b.lat - a.lat) / 2) ** 2 + Math.cos(rad(a.lat)) * Math.cos(rad(b.lat)) * Math.sin(rad(b.lon - a.lon) / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}

function lerCsv(texto) {
  const linhas = texto.trim().split(/\r?\n/);
  const cab = linhas.shift().split(',').map((c) => c.trim().toLowerCase());
  const i = (...nomes) => cab.findIndex((c) => nomes.includes(c));
  const iLat = i('lat', 'latitude'), iLon = i('lon', 'longitude');
  const iData = i('data_hora_gmt', 'data_pas', 'datahora', 'acq_date');
  if (iLat < 0 || iLon < 0) throw new Error('CSV sem colunas de latitude/longitude: ' + cab.join(','));
  return linhas.map((l) => {
    const c = l.split(',');
    return { lat: +c[iLat], lon: +c[iLon], quando: iData >= 0 ? c[iData] : '' };
  });
}

const dataUTC = (diasAtras) => {
  const d = new Date(Date.now() - diasAtras * 864e5);
  return d.toISOString().slice(0, 10).replace(/-/g, '');
};

async function inpe() {
  // CSV diário do INPE Queimadas (sem chave). Junta HOJE e ONTEM (dia em UTC): o de hoje começa
  // vazio às 21h de Brasília, e sozinho diria "nenhum fogo" sem verdade.
  const arquivos = await Promise.all([0, 1].map(async (atras) => {
    const url = `https://dataserver-coids.inpe.br/queimadas/queimadas/focos/csv/diario/Brasil/focos_diario_br_${dataUTC(atras)}.csv`;
    try { const r = await fetch(url); return r.ok ? lerCsv(await r.text()) : null; } catch { return null; }
  }));
  if (!arquivos[1]) throw new Error('INPE sem o arquivo de ontem');
  return { focos: arquivos.flatMap((a) => a || []), fonte: 'INPE Queimadas (últimas 24 a 48 h)' };
}

async function firms(centro, raio, key) {
  if (!key) throw new Error('FIRMS precisa de MAP_KEY');
  const g = raio / 111;
  const caixa = [centro.lon - g, centro.lat - g, centro.lon + g, centro.lat + g].map((v) => v.toFixed(2)).join(',');
  const r = await fetch(`https://firms.modaps.eosdis.nasa.gov/api/area/csv/${key}/VIIRS_SNPP_NRT/${caixa}/1`);
  if (!r.ok) throw new Error('FIRMS respondeu ' + r.status);
  return { focos: lerCsv(await r.text()), fonte: 'NASA FIRMS' };
}

export default async function handler(req, res) {
  try {
    const { fonte = 'inpe', key } = req.query;
    const centro = { lat: Number(req.query.lat), lon: Number(req.query.lon) };
    const raio = Math.min(Number(req.query.raio) || 45, 100);
    if (!Number.isFinite(centro.lat) || !Number.isFinite(centro.lon)) {
      return res.status(400).json({ erro: 'Mande lat e lon' });
    }
    const dados = fonte === 'firms' ? await firms(centro, raio, key || process.env.FIRMS_KEY) : await inpe();
    const focos = dados.focos.filter((f) => Number.isFinite(f.lat) && km(centro, f) <= raio);
    res.setHeader('Cache-Control', 's-maxage=1800, stale-while-revalidate=3600');
    res.status(200).json({ focos, fonte: dados.fonte });
  } catch (e) {
    res.status(502).json({ erro: e.message });
  }
}
