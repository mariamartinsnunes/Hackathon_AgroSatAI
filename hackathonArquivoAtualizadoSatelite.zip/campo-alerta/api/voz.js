// Função do Vercel: /api/voz?texto=Bom%20dia...
// Transforma texto em fala com a VOZ CLONADA da ElevenLabs e devolve um MP3.
//
// A chave fica SÓ aqui no servidor (nunca no app), em variáveis do Vercel:
//   ELEVENLABS_API_KEY   -> a chave da ElevenLabs
//   ELEVENLABS_VOICE_ID  -> o ID da voz clonada
//   ELEVENLABS_MODEL     -> opcional (padrão: eleven_multilingual_v2, que fala português)
//   VOZ_SITE             -> opcional: endereço do seu site (ex.: https://campo-alerta.vercel.app)
//                           para só o seu app poder gastar seus créditos
//
// Usa GET de propósito: o Vercel guarda a resposta em cache e a mesma frase
// não gasta crédito de novo.

const LIMITE = 900; // caracteres por pedido (o boletim de 1 minuto cabe)

export default async function handler(req, res) {
  const chave = process.env.ELEVENLABS_API_KEY;
  const voz = process.env.ELEVENLABS_VOICE_ID;
  if (!chave || !voz) {
    return res.status(503).json({ erro: 'Configure ELEVENLABS_API_KEY e ELEVENLABS_VOICE_ID no Vercel.' });
  }

  const site = process.env.VOZ_SITE;
  const origem = req.headers.origin || req.headers.referer || '';
  if (site && origem && !origem.startsWith(site)) {
    return res.status(403).json({ erro: 'Origem não permitida.' });
  }

  const texto = String(req.query.texto || '').trim().slice(0, LIMITE);
  if (!texto) return res.status(400).json({ erro: 'Mande ?texto=' });

  try {
    const r = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${voz}?output_format=mp3_44100_128`, {
      method: 'POST',
      headers: { 'xi-api-key': chave, 'Content-Type': 'application/json', Accept: 'audio/mpeg' },
      body: JSON.stringify({
        text: texto,
        model_id: process.env.ELEVENLABS_MODEL || 'eleven_multilingual_v2',
        voice_settings: { stability: 0.5, similarity_boost: 0.8 },
      }),
    });
    if (!r.ok) {
      const detalhe = await r.text();
      return res.status(502).json({ erro: `ElevenLabs respondeu ${r.status}`, detalhe: detalhe.slice(0, 300) });
    }
    const audio = Buffer.from(await r.arrayBuffer());
    res.setHeader('Content-Type', 'audio/mpeg');
    res.setHeader('Cache-Control', 'public, s-maxage=604800, max-age=86400');
    return res.status(200).send(audio);
  } catch (e) {
    return res.status(502).json({ erro: e.message });
  }
}
