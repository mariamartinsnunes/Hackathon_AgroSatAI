// Função do Vercel: /api/folha  (POST, multipart com o campo "file")
// Repassa a foto da folha para a API da IA no Render e devolve a resposta.
// Existe só por causa do CORS: o navegador não deixa o app chamar a API direto
// enquanto ela não liberar o endereço do app. Se a API liberar, o app nem passa por aqui.

const API = process.env.IA_API_URL || 'https://fastapi-ml-7fcy.onrender.com';
const LIMITE = 5 * 1024 * 1024; // 5 MB (o app já manda a foto reduzida, ~100 KB)

function lerCorpo(req) {
  return new Promise((ok, erro) => {
    const partes = [];
    let tamanho = 0;
    req.on('data', (p) => {
      tamanho += p.length;
      if (tamanho > LIMITE) { erro(new Error('Foto grande demais')); req.destroy(); return; }
      partes.push(p);
    });
    req.on('end', () => ok(Buffer.concat(partes)));
    req.on('error', erro);
  });
}

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ erro: 'Use POST' });
  try {
    const corpo = await lerCorpo(req);
    const r = await fetch(`${API}/predict`, {
      method: 'POST',
      headers: { 'Content-Type': req.headers['content-type'] },
      body: corpo,
    });
    res.status(r.status).setHeader('Content-Type', 'application/json');
    return res.send(await r.text());
  } catch (e) {
    return res.status(502).json({ erro: e.message });
  }
}
