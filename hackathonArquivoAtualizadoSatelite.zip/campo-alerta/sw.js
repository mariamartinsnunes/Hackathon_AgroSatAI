// Guarda as telas para abrir sem internet (os dados ficam no último valor buscado).
// Só guarda arquivos do próprio app: imagens de satélite e APIs de fora passam direto.
const CACHE = 'campo-alerta-v5';
const ARQUIVOS = [
  './', 'index.html', 'css/estilo.css', 'js/app.js', 'img/icone.svg',
  'fontes/poppins-latin-700-normal.woff2', 'fontes/poppins-latin-600-normal.woff2',
  'fontes/caladea-latin-400-normal.woff2', 'fontes/caladea-latin-700-normal.woff2',
];
self.addEventListener('install', (e) => {
  self.skipWaiting();
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(ARQUIVOS)));
});
self.addEventListener('activate', (e) => {
  e.waitUntil(caches.keys().then((nomes) => Promise.all(nomes.filter((n) => n !== CACHE).map((n) => caches.delete(n))))
    .then(() => self.clients.claim()));
});
self.addEventListener('fetch', (e) => {
  const url = new URL(e.request.url);
  if (e.request.method !== 'GET' || url.origin !== location.origin || url.pathname.startsWith('/api/')) return;
  e.respondWith(
    fetch(e.request).then((r) => { const copia = r.clone(); caches.open(CACHE).then((c) => c.put(e.request, copia)); return r; })
      .catch(() => caches.match(e.request))
  );
});
