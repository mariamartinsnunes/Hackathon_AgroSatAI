# Contexto completo: Campo Alerta no Hackathon de Dados Abertos (IFSP Araraquara)

Você vai me ajudar a terminar e apresentar o projeto abaixo. Leia tudo antes de responder. Responda em português simples e direto. Não mude nenhuma funcionalidade sem eu pedir, não quebre as regras de ética da seção 6 e nunca coloque chave de API no código.

## 1. O evento

- **Hackathon de Dados Abertos**, IFSP Araraquara, 2 e 3 de outubro de 2026.
- **Requisito obrigatório:** usar dados do portal do MAPA (dados.agricultura.gov.br).
- **Ética é critério eliminatório.**
- **Agenda:** o congelamento de funcionalidades era sexta às 20h (já passou, então agora é só correção e polimento). A entrega é sábado, das 8h às 9h30, e o pitch é às 10h.
- **Concorrência:** um grupo vizinho tem uma ideia parecida. Na mesa, não contamos os detalhes nem os diferenciais para quem vem perguntar (usamos uma ideia "isca" sem graça). Os diferenciais só aparecem no pitch.

## 2. O produto

**Campo Alerta** é um app (celular e computador, PWA) para o **pequeno produtor de café**. O público é mais velho, tem pouca familiaridade com celular e internet fraca. O app avisa, sempre com frases curtas e por voz:

1. **Tempo:** hoje e próximos dias, umidade e vento.
2. **Época de plantar mudas de café:** um semáforo feito com o **ZARC do MAPA**.
3. **Fogo perto da roça:** focos vistos por satélite, num raio de 30 km.
4. **Saúde da lavoura por satélite:** índice de verde (NDVI) do Sentinel-2 sobre a foto aérea, numa área de 800 x 600 m **em volta da localização atual do aparelho**. Mostra 9 pontos (saudável, atenção, preocupação) e aponta o pior ("Olhe aqui").
5. **Doença na folha por foto:** a IA do nosso time devolve 3 possibilidades e o botão "Chamar técnico". (O quadro do Agrofit saiu desta tela em 02/10.)
6. **Minhas lavouras:** feito por uma colega do time. Simula o crescimento da planta por graus-dia, compara com o verde esperado, prevê a colheita, mostra zonas 3x3 e tem um check-in ("confere com a sua lavoura?").

**Diferenciais (ninguém na sala tem):**
- **Boletim de 1 minuto para a rádio comunitária**, gerado a partir dos mesmos dados, "a cada 3 dias, todo dia se tiver alerta". Serve para quem não tem smartphone nem internet.
- **"0800 Campo Alerta" para celular de botão:** ideia para o produto real (o produtor dá um toque e o sistema liga de volta e lê o boletim). **A tela "Ligar" saiu do app em 02/10**; se falarem disso no pitch, é próximo passo.
- **Voz humana clonada (ElevenLabs):** idosos confiam mais em voz de gente do que em voz robótica. Sempre com o aviso "Voz gerada por IA".

## 3. Decisões tomadas

- **Só café**, por enquanto. Milho, mandioca e feijão aparecem como "em breve".
- **Tecnologia:** HTML, CSS e JavaScript puro (módulos ES), sem etapa de build. As funções serverless ficam no Vercel (pasta `/api`) e os scripts de dados são em Python.
- **APIs trocáveis:** cada serviço tem "provedores" em `js/config.js` (`mock` ou real), e todos devolvem o mesmo formato. As telas nunca chamam API direto, só `js/api/index.js`.
- **Nada de dado inventado (02/10):** se uma API real falha ou demora, o app usa o último valor salvo no aparelho (com etiqueta) ou diz **"sem informação agora"**. Nunca cai em exemplo.
- **Velocidade:**
  - Nenhuma tela espera a internet para abrir; a troca leva menos de 40 ms.
  - Os resultados ficam guardados no aparelho: tempo e fogo por 30 min, plantio e produtos por 7 dias, satélite por 6 h.
  - Cada API tem tempo máximo de espera: tempo 6 s, fogo 20 s, satélite 40 s.
- **Visual inspirado no site da Green Place Agro:**
  - Verde #006633 e títulos em Poppins (uma linha em negrito e outra fina); texto em Roboto.
  - Botões com canto de 10 px e sombra; menu com o item atual numa pílula verde.
  - Cabeçalho claro com o sol e as fileiras de café no morro.
  - Copiamos só o estilo, não as fotos nem o logo deles.
- **Linguagem:** frases curtas e faladas ("Espere a chuva", "O canto de baixo, à esquerda, está perdendo o verde"). O texto da rádio tem tom de locutor.

## 4. O que está implementado (estado em 02/10, 21h40)

**Telas:** cadastro (nome, localização e cultura, por voz ou digitando), saber (mês em que costuma plantar), início, foto da folha, avisos, falar (comandos de voz), rádio, fogo (mapa), satélite (saúde da lavoura na localização atual), minhas lavouras, nova lavoura e detalhe da lavoura.

**De onde vem cada dado:**

| O quê | Fonte | Situação |
|---|---|---|
| Época de plantio (semáforo) | **ZARC, Tábua de Risco (MAPA)** | **Dado real**, em `dados/zarc-cafe.json` |
| Produtos registrados por doença | **Agrofit, Produto Formulado (MAPA)** | Arquivo continua em `dados/`, mas **saiu da tela** em 02/10 |
| Município da pessoa | IBGE (645 municípios de SP, lista kelvins/municipios-brasileiros) | **Real**, escolhido no celular e cruzado com o ZARC |
| Tempo | Open-Meteo, direto do navegador, sem chave | Real |
| Satélite da lavoura | Sentinel-2 pelo Microsoft Planetary Computer, com foto de fundo da Esri | **Real, na localização atual do aparelho** (testado em 02/10). Se falhar: "O satélite não respondeu agora" |
| Doença na folha | Nossa API: https://fastapi-ml-7fcy.onrender.com/predict | Real, liberada para o app e testada em 02/10 (~11 s) |
| Fogo | INPE Queimadas (Vercel, ou direto do INPE no Live Server) | **Real** (`fogo: 'inpe'`). Últimas 24 a 48 h. CORS direto testado em 02/10 |
| Mapa do fogo | NASA GIBS (MODIS) + Leaflet | Real |
| Clima desde o plantio (Minhas lavouras) | Open-Meteo (`historico: 'openmeteo'`) | **Real**. Fase e colheita são **estimativa** por graus-dia |
| Verde de cada lavoura (Minhas lavouras) | nenhum (`ndvi: 'nenhum'`) | **Não aparece**: a lavoura não tem contorno. Nada inventado |
| Voz | Voz do navegador; ElevenLabs pela função `api/voz.js` | ElevenLabs **ainda não configurado** |

**Como os dados do MAPA foram tratados** (baixados em 02/10 de dados.agricultura.gov.br):
- **ZARC:**
  - O arquivo "Perene, Olerícola e Sem Safra" tem 535 MB e 2,3 milhões de linhas.
  - Ficou só o **Café Arábica Implantação** (plantio de mudas), **sequeiro**, nos **640 municípios de SP** com café zoneado.
  - 73 desses municípios só têm Café Canéfora e usam ele.
  - Base legal: Portaria 582/2021 (arábica) e Portaria 07/2024 (canéfora).
  - Em cada decêndio fica o **menor risco entre os tipos de solo** (o melhor caso). O técnico confirma para o solo da roça.
  - Exemplo: em Araraquara a boa época vai de meados de outubro ao começo de dezembro. Hoje o app mostra "Espere a chuva", porque o risco ainda é médio e o tempo está seco (El Niño).
- **Agrofit:**
  - O arquivo "Produto Formulado" tem 392 MB.
  - Conta registros ativos para café, um por número de registro, para cada doença que a IA reconhece: ferrugem 257, bicho-mineiro 242, olho-pardo 173, phoma 97, antracnose/mancha-manteigosa 21, mancha-aureolada 6.
  - Mostra só a contagem: nada de nome comercial nem dose.
- **Na tela:** o início mostra o selo "Dado oficial do MAPA · ZARC". O rodapé do início, dos avisos e da rádio mostra a fonte de cada informação.
- **Frase para o pitch:** com o Agrofit fora da tela, o que o app usa do MAPA é o ZARC: "transformamos 535 MB da Tábua de Risco do ZARC em 12 KB dentro do app, que funciona até sem internet". (A frase antiga, de 900 MB em 13 KB, somava o Agrofit.)
- **Pivôs centrais (dados.gov.br):** decidimos **não usar**. Não é do portal do MAPA, e pivô é irrigação de fazenda grande, longe do nosso público.

**IA da folha (API do time):**
- FastAPI com MobileNetV2 treinado no DigiPathos.
- Recebe `POST` multipart com o campo `file` e responde `{"diagnostico", "confianca", "probabilidades": {bicho_mineiro, cercosporiose, ferrugem, mancha_aureolada, mancha_mantegosa, phoma}}`, em porcentagem.
- O app reduz a foto para 512 px antes de enviar e mostra as 3 doenças mais prováveis.
- **Ela não tem a classe "folha sadia"** (sempre aponta alguma doença). O aviso na tela saiu em 02/10: falem isso no pitch.
- O servidor gratuito do Render "dorme" e pode levar até 1 minuto para acordar. O app acorda a API sozinho e avisa a pessoa se demorar.

## 5. Onde fica o projeto

- **Pasta:** `C:\Users\Lauan\Desktop\campo-alerta`. Atenção: é o Desktop do Windows, **não** a "Área de Trabalho" do OneDrive.
- **Zip mais recente:** `Hackathon atualizado 3.zip`, na mesma pasta Desktop.
- **Para rodar:** abrir a pasta no VS Code, clicar em **Go Live** (http://127.0.0.1:5501) e recarregar com **Ctrl+F5** depois de cada atualização. Usar Chrome ou Edge, que são os navegadores que ouvem a voz.
- **Arquivos principais:**
  - `js/config.js`: troca de APIs, contato do técnico e lavoura de demonstração.
  - `js/regras.js`: todos os textos dos avisos, do semáforo e do boletim.
  - `js/telas/*.js`: uma tela por arquivo.
  - `js/api/*.js`: provedores de dados.
  - `css/estilo.css`: cores no `:root`.
  - `js/voz.js`: palavras que a voz entende.
  - `api/`: funções do Vercel (clima, fogo, voz, folha).
  - `scripts/`: geração dos dados do ZARC e do Agrofit, e do MP3 do boletim.
  - `README.md`: explica tudo.

## 6. Ética e privacidade: regras que não podem quebrar

- Nome, localização exata e lavouras ficam **só no aparelho** (localStorage). Para fora vai só o município, ou a localização arredondada (~11 km) no caso do tempo e do fogo. A distância até o fogo é calculada no celular.
- **Satélite:** para o Planetary Computer vai só um quadrado de ~2,5 km em volta de um ponto arredondado (~1 km); o recorte da área é feito no celular. Para a Esri vão os quadradinhos da foto (~12), como em qualquer mapa.
- **Nenhum dado inventado:** sem resposta, a tela diz "sem informação agora".
- A foto da folha vai reduzida para a nossa API **só para análise**, sem nome nem localização junto.
- A IA **nunca dá certeza**: são sempre 3 possibilidades, com "A máquina pode errar. Quem dá a palavra final é o técnico" e o botão **Chamar técnico**. Nunca inventa diagnóstico, nem quando a API falha.
- **Voz clonada:** só de alguém que autorizou, sempre com o aviso "Voz gerada por IA".
- A **chave da ElevenLabs** fica só nas variáveis de ambiente do Vercel (`ELEVENLABS_API_KEY` e `ELEVENLABS_VOICE_ID`). Nunca vai no código, no GitHub nem no chat. O `.env` está no `.gitignore`.
- Tudo que é exemplo ou simulação aparece com etiqueta na tela.

## 7. O que preciso garantir antes da entrega (8h–9h30) e do pitch (10h)

**Entrega e commit**
- [ ] Fazer o commit a partir de `Hackathon atualizado 3.zip` ou da pasta do Desktop.
- [ ] Apagar da pasta os arquivos que sobraram: `fontes/bricolage-*`, `fontes/atkinson-*`, `js/api/lavoura.js` e `js/telas/ligar.js`.
- [ ] Conferir que **não existe `.env` nem chave** no repositório.

**Publicar no Vercel** (recomendado, porque dá HTTPS para o microfone e ativa `/api/folha`, `/api/fogo` e `/api/voz`)
- [ ] Rodar `vercel` na pasta e testar o link no celular.
- [ ] Se for usar a voz clonada: colocar `ELEVENLABS_API_KEY` e `ELEVENLABS_VOICE_ID` no Vercel e fazer Redeploy.
- [ ] Fogo já está em `'inpe'` (real). Conferir no Vercel e no Live Server.
- [ ] **Telefone do técnico** em `js/config.js` ainda é de mentira (`+5516999999999`). Trocar pelo número real da Casa da Agricultura ou tirar.

**Antes do pitch**
- [ ] Abrir a tela **Foto da folha** uns 2 minutos antes, para acordar a API do Render. Levar uma foto de folha doente de verdade no celular.
- [ ] Testar o microfone na sala. Se falhar, usar os 4 botões de exemplo da tela Falar, que funcionam como se a pessoa tivesse falado.
- [ ] Abrir a tela Satélite antes e liberar a localização (fica guardado por 6 h). No notebook a localização vem do Wi-Fi e pode errar; no celular com GPS fica certa. No IFSP a área vai ser o campus.
- [ ] Gerar o MP3 do boletim da rádio para tocar no pitch: `python scripts/gerar_audio.py boletim.txt boletim.mp3`.
- [ ] Confirmar com o colega da IA se a API **guarda** as fotos. Se não guarda, dá para dizer "a foto só é analisada, não fica guardada" (vale mostrar essa frase na tela da foto).
- [ ] Conferir os números do pitch com a fonte. Exemplo: o Censo Agropecuário 2017 (IBGE) indica que a maioria dos estabelecimentos rurais não tinha internet. Pegar o número exato antes de falar.

**Ser honesto no pitch** (ética é eliminatória)
- Dado real: ZARC (MAPA), tempo e clima desde o plantio (Open-Meteo), fogo (INPE), satélite na localização atual (Sentinel-2), municípios (IBGE) e a IA da folha.
- Estimativa: fase e colheita de "Minhas lavouras" (graus-dia sobre clima real).
- Sem exemplo inventado em nenhuma tela: quando falta dado, aparece "sem informação agora".
- A IA não reconhece folha sadia, e o app só tem municípios de SP. Esses são próximos passos.

## 8. Próximos passos (para o slide "o que vem depois")

- Treinar a classe "folha sadia" na IA.
- Lista completa de municípios do IBGE e ZARC do Brasil inteiro (já temos o caminho pronto).
- 0800 de verdade com retorno de ligação (Twilio, Zenvia ou parceria com a Emater ou a Casa da Agricultura).
- Parceria com rádios comunitárias para o boletim.
- Satélite na roça de cada produtor (ele desenha o contorno, e o contorno fica só no celular).
- Validar os graus-dia e as curvas de verde com a Embrapa ou um agrônomo.

## 9. Como quero que você me ajude agora

Estou na reta final. Priorize o que garante a entrega e um pitch seguro. Explique em passos curtos o que eu preciso fazer. Se for mexer em código, diga exatamente qual arquivo e o que muda, sem alterar funcionalidade que já funciona. Se algo for exemplo ou simulação, me ajude a dizer isso de forma honesta e convincente.


## Mudanças de 03/10 (madrugada)

- **Fonte voltou ao que era:** títulos em Poppins, texto em Roboto. (A Cambria/Caladea saiu.)
- **Satélite:** as datas agora são TODAS as passagens reais (antes um filtro de nuvem escondia algumas, como 30/09, 20/09 e 10/09). Saiu a frase inventada "a próxima foto chega em X dias"; no lugar, o app conta quantas vezes o satélite passou de verdade nos últimos 80 dias e quando foi a última. Mostra 6 datas.
- **Tela de mapa do fogo saiu** (o mapa MODIS ficava cinza com nuvem e pesava). O fogo virou só o cartão do início: distância, direção, hora em que o satélite viu (horário de Brasília) e quantos focos no raio de 30 km. Fonte: INPE Queimadas, que junta vários satélites e atualiza ao longo do dia; o app guarda por 30 min.
- **Minhas lavouras revisado:** saíram as fases por graus-dia, o "% até a colheita", o "atrasada X dias", o mapa 3x3, o check-in e o cartão "Visto do satélite". Motivo: os números de graus-dia não tinham fonte oficial e o "atraso" vinha de um verde de satélite inventado. Ficou só dado medido: dias desde o plantio, chuva dos últimos 30 dias, dias seguidos sem chuva firme, máxima média da semana e chuva total desde o plantio (Open-Meteo). Colheita: "o app ainda não estima; quem diz é o técnico". Só café (soja saiu).
- **Voz mais jovem e animada:** no navegador, prefere a voz "Thalita" (Edge), depois "Francisca", "Google português do Brasil", "Maria"; tom 15% mais agudo e ritmo normal. Na ElevenLabs (quando configurar): mais expressiva (stability 0,35, style 0,45).
- **Telefone do técnico:** (19) 3743-3700 (`+551937433700` em `js/config.js`).
- Arquivos que podem ser apagados: `js/telas/mapa.js`, `js/planta.js`, `js/telas/ligar.js`, `js/api/lavoura.js`, `fontes/caladea-*`, `fontes/bricolage-*`, `fontes/atkinson-*`. (As fontes Roboto agora SÃO usadas: não apague.)
