// Transforma dados das APIs em frases curtas para o produtor.
// Todas as telas, a voz e o boletim da rádio usam estas mesmas regras.
import { CONFIG } from './config.js';
import { decendio, mesDoDecendio, distanciaKm, rumo, rumoEmPalavras, MESES } from './util.js';
import { buscarClima, buscarFogo, buscarPlantio, buscarSaude } from './api/index.js';
import { analisarTodas } from './lavouras.js';
import { pontosDaPassagem, nomeCurto } from './satelite.js';
import { pegarLocal } from './local.js';

// "na segunda", "no sábado"
function naDia(nome) { return ['sábado', 'domingo'].includes(nome) ? `no ${nome}` : `na ${nome}`; }

export function contexto(perfil) {
  const municipio = perfil.municipio || CONFIG.municipioPadrao;
  const centro = perfil.lat != null ? { lat: perfil.lat, lon: perfil.lon } : { lat: municipio.lat, lon: municipio.lon };
  return { municipio, centro };
}

// Nada é inventado: se um serviço não responde (e não tem valor guardado), ele vem null
// e cada tela diz "sem informação agora" no lugar daquele dado.
export async function carregarTudo(perfil) {
  const ctx = contexto(perfil);
  const erros = {};
  const semDado = (nome) => (e) => { console.warn(`[${nome}] sem dado:`, e.message); erros[nome] = e.message; return null; };
  const [clima, fogo, plantio] = await Promise.all([
    buscarClima(ctx).catch(semDado('clima')),
    buscarFogo(ctx).catch(semDado('fogo')),
    buscarPlantio(ctx).catch(semDado('plantio')),
  ]);
  return {
    ctx, clima, fogoBruto: fogo, plantioBruto: plantio, erros,
    plantio: plantio ? semaforoPlantio(plantio, clima) : null,
    fogo: fogo ? fogoPerto(fogo, ctx.centro) : null,
    semFogo: !fogo, // true = NÃO SABEMOS se tem fogo (diferente de "não tem fogo")
    exemplo: Boolean(clima?.exemplo || fogo?.exemplo || plantio?.exemplo),
  };
}

// As partes lentas carregam SEPARADAS, sem travar as outras telas:
// o satélite (alguns segundos) e as lavouras cadastradas (histórico do clima desde o plantio).
// Satélite: usa a localização ATUAL do aparelho. pedir=false não abre a pergunta do navegador.
export async function carregarSaude(perfil, { pedir = true } = {}) {
  const local = await pegarLocal({ pedir });
  const bruta = await buscarSaude({ local });
  return { bruta, resumo: resumoLavoura(bruta) };
}

export function carregarLavouras(perfil) {
  return analisarTodas(perfil, contexto(perfil));
}

// ---------- Plantio: semáforo ----------
export function semaforoPlantio(plantio, clima, hoje = new Date()) {
  const r = plantio.riscos;
  const dec = decendio(hoje);
  const risco = r[dec - 1];
  const chuvaSemana = (clima?.dias || []).reduce((s, d) => s + (d.chuvaMm || 0), 0);

  let proximo = null;
  for (let i = 1; i <= 36; i++) {
    const d = ((dec - 1 + i) % 36) + 1;
    if (r[d - 1] === 20) { proximo = d; break; }
  }
  const mesBom = proximo ? mesDoDecendio(proximo) : null;

  if (!risco || risco >= 40) {
    return { cor: 'vermelho', titulo: 'Ainda não é hora', detalhe: mesBom ? `A melhor época é em ${mesBom}` : 'Converse com o técnico', mesBom,
      fala: mesBom ? `Ainda não é hora de plantar café. A melhor época é em ${mesBom}.` : 'Ainda não é hora de plantar café. Converse com o técnico.',
      radio: mesBom ? `Para quem planta café, ainda não é hora: a melhor época é em ${mesBom}.` : 'Para quem planta café, ainda não é hora de plantar.' };
  }
  if (CONFIG.elNino && clima && chuvaSemana < 20) { // sem previsão do tempo, não dá para dizer que está seco
    return { cor: 'amarelo', titulo: 'Espere a chuva', detalhe: 'A terra ainda está seca para as mudas', mesBom: MESES[hoje.getMonth()], motivo: 'elnino',
      fala: 'Ainda não. Espere a chuva firmar antes de pôr as mudas de café na terra.',
      radio: 'Para quem planta café, a dica é esperar a chuva firmar antes de pôr as mudas na terra.' };
  }
  if (risco === 30) {
    return { cor: 'amarelo', titulo: 'Plante com cuidado', detalhe: 'O risco de perder mudas é médio', mesBom,
      fala: 'Dá para plantar, mas com cuidado: o risco de perder mudas é médio.',
      radio: 'Para quem planta café, dá para plantar, mas com cuidado.' };
  }
  return { cor: 'verde', titulo: 'Pode plantar', detalhe: 'A época está boa para as mudas', mesBom: MESES[hoje.getMonth()],
      fala: 'Pode plantar as mudas de café: a época está boa.',
      radio: 'Para quem planta café, a época está boa para plantar as mudas.' };
}

// ---------- Satélite: os 9 pontos da foto mais nova, comparados com a mais antiga (sem nuvem) ----------
const ddmm = (iso) => iso.slice(8, 10) + '/' + iso.slice(5, 7);

export function resumoLavoura(lav, ate = lav.passagens.length - 1) {
  const validas = lav.passagens.map((p, i) => ({ ...p, i }))
    .filter((p) => !p.nuvem && p.i <= ate && p.partes?.some((v) => v != null));
  if (!validas.length) return null;
  const primeira = validas[0], ultima = validas.at(-1);
  const comparou = validas.length >= 2;
  const pontos = pontosDaPassagem(lav, ultima, comparou ? primeira : null);
  const comQueda = pontos.filter((p) => p.queda != null);
  const pior = comQueda.length ? comQueda.reduce((a, b) => (b.queda > a.queda ? b : a)) : null;
  const alerta = Boolean(pior && pior.queda >= 0.08); // perdeu verde: é o aviso mais forte
  const vermelhos = pontos.filter((p) => p.cor === 'vermelho');
  const amarelos = pontos.filter((p) => p.cor === 'amarelo');
  const maisFraco = vermelhos.length ? vermelhos.reduce((a, b) => (b.valor < a.valor ? b : a)) : null;
  const destaque = alerta ? pior : maisFraco;

  let titulo, detalhe;
  if (alerta) {
    titulo = `${pior.nome} está perdendo o verde`;
    detalhe = `O verde caiu desde a foto de ${ddmm(primeira.data)}. Dê uma olhada lá e tire foto de uma folha.`;
  } else if (vermelhos.length) {
    titulo = vermelhos.length === 1 ? `${nomeCurto(maisFraco.nome)} tem pouco verde` : `${vermelhos.length} pontos com pouco verde`;
    detalhe = 'Se ali for lavoura, dê uma olhada e tire foto de uma folha. Estrada, casa e terra sem planta também ficam vermelhas.';
  } else if (amarelos.length) {
    titulo = 'Verde médio em alguns pontos';
    detalhe = comparou ? `Fique de olho nos pontos amarelos. Nada caiu muito desde ${ddmm(primeira.data)}.` : 'Fique de olho nos pontos amarelos.';
  } else {
    titulo = 'Tudo verde em volta de você';
    detalhe = comparou ? `Nada mudou muito desde a foto de ${ddmm(primeira.data)}.` : 'É a primeira foto limpa. As próximas vão mostrar se algo mudar.';
  }
  return {
    primeira, ultima, pontos, pior, destaque, alerta, atencao: vermelhos.length > 0, comparou,
    analise: { partes: pontos, pior: destaque }, // nome antigo, usado no cartão do início
    titulo, detalhe,
  };
}

// ---------- Fogo: o mais perto da roça ----------
export function fogoPerto(fogo, centro) {
  const perto = (fogo.focos || [])
    .map((f) => ({ ...f, km: distanciaKm(centro, f), graus: rumo(centro, f) }))
    .filter((f) => f.km <= CONFIG.raioFogoKm)
    .sort((a, b) => a.km - b.km);
  if (!perto.length) return null;
  const f = perto[0];
  return { ...f, kmTexto: f.km < 1 ? 'menos de 1 km' : `${Math.round(f.km)} km`, direcao: rumoEmPalavras(f.graus), total: perto.length };
}

// ---------- Avisos de cada lavoura cadastrada (colheita e satélite) ----------
function avisosDaLavoura({ lavoura, sim, comp }) {
  const lista = [];
  if (!sim) return lista; // sem o clima, não deu para calcular esta lavoura
  const col = sim.colheita;
  if (col.estado === 'epoca') {
    lista.push({ cor: 'folha', icone: 'planta', prioridade: 1, titulo: `${lavoura.nome}: hora de colher`, detalhe: col.detalhe });
  } else if (col.estado === 'breve') {
    lista.push({ cor: 'folha', icone: 'planta', prioridade: 2, titulo: `${lavoura.nome}: a colheita está chegando`, detalhe: col.detalhe });
  }
  if (comp.estado === 'alerta' || comp.estado === 'atencao') {
    lista.push({ cor: comp.estado === 'alerta' ? 'cereja' : 'grao', icone: 'satelite', prioridade: comp.estado === 'alerta' ? 1 : 2,
      titulo: comp.lag ? `${lavoura.nome} está uns ${comp.lag} dias atrasada` : `${lavoura.nome} está abaixo do esperado`,
      detalhe: comp.detalhe });
  }
  return lista;
}

// ---------- Avisos personalizados (no máximo 1 "do dia" + extras) ----------
export function gerarAvisos(perfil, d) {
  const avisos = [];
  const nome = perfil.nome ? perfil.nome.split(' ')[0] : '';

  if (d.fogo) {
    avisos.push({ cor: 'cereja', icone: 'fogo', prioridade: d.fogo.km <= 10 ? 0 : 3,
      titulo: `Fogo a ${d.fogo.kmTexto}`, detalhe: `Para os lados do ${d.fogo.direcao}. Se ele chegar perto, ligue 193.` });
  }

  if (d.semFogo) {
    avisos.push({ cor: 'cereja', icone: 'fogo', prioridade: 4, titulo: 'Sem informação do fogo agora',
      detalhe: 'O satélite do INPE não respondeu. Se vir fumaça perto, ligue 193.' });
  }

  const p = d.plantio;
  if (!p) {
    avisos.push({ cor: 'folha', icone: 'calendario', prioridade: 4, titulo: 'Sem dado do plantio agora',
      detalhe: d.erros?.plantio?.startsWith('ZARC sem café') ? `O ZARC do MAPA não indica café para ${d.ctx.municipio.nome}.` : 'Não deu para ler o ZARC agora.' });
  } else if (p.cor !== 'verde') {
    let detalhe = p.detalhe;
    if (perfil.mesTradicional && p.motivo === 'elnino') {
      detalhe = `Você costuma plantar em ${MESES[perfil.mesTradicional - 1]}, mas este ano o El Niño deixou a chuva irregular. Espere a terra molhar bem.`;
    }
    avisos.push({ cor: 'folha', icone: 'calendario', prioridade: 1,
      titulo: `${nome ? nome + ', e' : 'E'}spere para plantar`, detalhe });  // ex.: "João, espere para plantar"
  } else {
    avisos.push({ cor: 'folha', icone: 'calendario', prioridade: 1, titulo: `${nome ? nome + ', p' : 'P'}ode plantar as mudas`, detalhe: p.detalhe });
  }

  if (d.lavoura?.alerta) { // só entra se o satélite já tiver carregado
    avisos.push({ cor: 'grao', icone: 'satelite', prioridade: 1.5, titulo: d.lavoura.titulo, detalhe: `O satélite percebeu. ${d.lavoura.detalhe}` });
  }

  if (!d.clima) {
    avisos.push({ cor: 'ceu', icone: 'nuvem', prioridade: 4, titulo: 'Sem previsão do tempo agora', detalhe: 'Confira a internet. Quando ela voltar, os avisos do tempo aparecem aqui.' });
    (d.lavouras || []).forEach((a) => avisos.push(...avisosDaLavoura(a)));
    return avisos.sort((a, b) => a.prioridade - b.prioridade);
  }
  const hoje = d.clima.hoje;
  if (hoje.max >= 33) {
    avisos.push({ cor: 'grao', icone: 'calor', prioridade: 2, titulo: 'Calor forte hoje', detalhe: 'Evite trabalhar no sol das 11h às 15h e não deixe as mudas sem água.' });
  }
  if (hoje.umidade != null && hoje.umidade < 30) {
    avisos.push({ cor: 'cereja', icone: 'gota', prioridade: d.fogo ? 3 : 2, titulo: 'Ar muito seco',
      detalhe: `A umidade está em ${hoje.umidade}%. Não queime lixo nem palha: o fogo se espalha fácil.` });
  }
  if (hoje.ventoKmh != null && hoje.ventoKmh > 10) {
    avisos.push({ cor: 'ceu', icone: 'vento', prioridade: 3, titulo: 'Vento forte',
      detalhe: `Está ventando ${hoje.ventoKmh} km/h. Deixe para passar produto outro dia: o vento espalha.` });
  }
  const amanha = d.clima.dias?.[0];
  if (amanha && amanha.chuvaMm >= 5) {
    avisos.push({ cor: 'ceu', icone: 'chuva', prioridade: 2, titulo: 'Vai chover amanhã', detalhe: 'Se for passar produto, deixe para depois: a chuva lava tudo.' });
  } else {
    const dia = (d.clima.dias || []).find((x) => x.chuvaMm >= 5);
    if (dia) avisos.push({ cor: 'ceu', icone: 'chuva', prioridade: 4, titulo: `Chuva ${naDia(dia.nome)}`, detalhe: `Devem cair uns ${dia.chuvaMm} milímetros.` });
  }
  (d.lavouras || []).forEach((a) => avisos.push(...avisosDaLavoura(a))); // só entra se já tiver carregado
  return avisos.sort((a, b) => a.prioridade - b.prioridade);
}

// ---------- Boletim da rádio (até 150 palavras ≈ 1 minuto, jeito de locutor) ----------
const DIA_DE = { 'Sol forte': 'de sol forte', Sol: 'de sol', Nublado: 'nublado', Chuva: 'de chuva' };

export function gerarBoletim(d) {
  const m = d.ctx.municipio;
  const hoje = d.clima?.hoje;
  const partes = [`Bom dia, produtor e produtora de ${m.nome} e região! Aqui é o Campo Alerta, com as notícias da roça.`];
  if (hoje) {
    partes.push(`Hoje o dia é ${DIA_DE[hoje.frase] || hoje.frase.toLowerCase()}, com máxima de ${hoje.max} graus.`);
    const chuva = (d.clima.dias || []).find((x) => x.chuvaMm >= 5);
    partes.push(chuva ? `A chuva deve chegar ${naDia(chuva.nome)}.` : 'Nos próximos dias, nada de chuva forte.');
    if (hoje.max >= 33) partes.push('Com esse calor, evite o sol das onze às três da tarde.');
  } else {
    partes.push('A previsão do tempo não chegou a tempo deste boletim.');
  }
  if (d.plantio) partes.push(d.plantio.radio);
  if (!d.fogo && hoje?.umidade != null && hoje.umidade < 30) partes.push('O ar está muito seco: não queime lixo nem palha.');
  if (d.fogo) partes.push(`Atenção: o satélite viu fogo na região, para os lados do ${d.fogo.direcao}. Não queime lixo nem palha. E se vir fogo, ligue cento e noventa e três.`);
  partes.push('Ficou com dúvida na lavoura? Procure a Casa da Agricultura. Até o próximo boletim!');
  const texto = partes.join(' ');
  return { texto, palavras: texto.split(/\s+/).length };
}
