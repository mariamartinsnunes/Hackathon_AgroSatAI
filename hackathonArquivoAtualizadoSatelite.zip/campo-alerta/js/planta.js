const COR = {
  folha: '#4E9A3C',
  folhaEscura: '#2F5B27',
  velha: '#D6B03A',
  seca: '#8A5A3B',
  caule: '#7AB05E',
  tronco: '#7A5238',
  vagem: '#6BB06F',
  vagemSeca: '#B5895A',
  flor: '#B48CD8',
  verde: '#6BB06F',
  amarelo: '#E0A21B',
  vermelho: '#B3261E',
  semente: '#E8D3A2',
};

const SOLO = 163;

function chao() {
  return `<path d="M0 ${SOLO} Q50 ${SOLO - 8} 100 ${SOLO - 4} T200 ${SOLO - 6} V200 H0Z" fill="#6B2E1F"/>
    <path d="M0 ${SOLO} Q50 ${SOLO - 8} 100 ${SOLO - 4} T200 ${SOLO - 6} V${SOLO + 4} Q150 ${SOLO + 7} 100 ${SOLO + 2} T0 ${SOLO + 6}Z" fill="#8A4A32"/>`;
}

function caule(altura, cor, largura = 4) {
  return `<line x1="100" y1="${SOLO}" x2="100" y2="${SOLO - altura}" stroke="${cor}" stroke-width="${largura}" stroke-linecap="round"/>`;
}

function folha(x, y, lado, tam, cor, angulo = 28) {
  return `<g transform="rotate(${lado * -angulo} ${x} ${y})"><ellipse cx="${x + lado * tam}" cy="${y}" rx="${tam}" ry="${(tam * 0.5).toFixed(1)}" fill="${cor}"/></g>`;
}

function nos(altura, quantidade) {
  return Array.from({ length: quantidade }, (_, i) =>
    SOLO - 20 - (altura - 24) * (i / Math.max(quantidade - 1, 1)));
}

function folhasSoja(ys, cor, tam = 15) {
  return ys.map((y, i) => folha(100, y, 1, tam - i * 0.5, cor) + folha(100, y, -1, tam - i * 0.5, cor)).join('');
}

function sojaDesenho(id, p) {
  let corpo = '';
  if (id === 'semente') {
    corpo = `<ellipse cx="100" cy="${SOLO + 22}" rx="9" ry="6" fill="${COR.semente}" stroke="#B79A5E" stroke-width="2"/>`;
    if (p > 0.45) corpo += `<path d="M100 ${SOLO + 28} q-5 6 -1 12" stroke="${COR.semente}" stroke-width="2.5" fill="none" stroke-linecap="round"/>`;
    if (p > 0.75) corpo += `<path d="M100 ${SOLO + 16} V${SOLO + 2}" stroke="${COR.caule}" stroke-width="3" stroke-linecap="round"/>`;
  } else if (id === 'brotou') {
    const h = 16 + 30 * p;
    corpo = caule(h, COR.caule) + folha(100, SOLO - h, 1, 11, COR.folha, 22) + folha(100, SOLO - h, -1, 11, COR.folha, 22);
  } else if (id === 'folhas') {
    const h = 46 + 58 * p;
    const ys = nos(h, 2 + Math.round(4 * p));
    corpo = caule(h, COR.caule) + folhasSoja(ys, COR.folha) + folha(100, SOLO - h, 1, 9, COR.folha, 50) + folha(100, SOLO - h, -1, 9, COR.folha, 50);
  } else if (id === 'flor') {
    const h = 104 + 6 * p;
    const ys = nos(h, 6);
    const flores = Math.ceil(6 * (0.3 + 0.7 * p));
    corpo = caule(h, COR.caule) + folhasSoja(ys, COR.folha);
    corpo += ys.slice(0, flores).map((y, i) => `<circle cx="${100 + (i % 2 ? 8 : -8)}" cy="${y + 3}" r="3.5" fill="${COR.flor}"/>`).join('');
  } else if (id === 'vagem') {
    const ys = nos(112, 6);
    corpo = caule(112, COR.caule) + folhasSoja(ys, COR.folha);
    corpo += ys.map((y) => [-1, 1].map((l) => `<ellipse cx="${100 + l * 10}" cy="${y + 9}" rx="3.2" ry="${(6 + 5 * p).toFixed(1)}" fill="${COR.vagem}"/>`).join('')).join('');
  } else if (id === 'madura') {
    const ys = nos(112, p > 0.5 ? 4 : 6);
    const vagem = p > 0.5 ? COR.vagemSeca : COR.vagem;
    corpo = caule(112, p > 0.6 ? COR.seca : COR.caule) + folhasSoja(ys, COR.velha, 13);
    corpo += nos(112, 6).map((y) => [-1, 1].map((l) => `<ellipse cx="${100 + l * 10}" cy="${y + 9}" rx="3.2" ry="11" fill="${vagem}"/>`).join('')).join('');
  } else {
    const ys = nos(108, 6);
    corpo = caule(108, COR.seca);
    corpo += folha(100, SOLO - 108, 1, 8, COR.seca, 60) + folha(100, SOLO - 108, -1, 8, COR.seca, 60);
    corpo += ys.map((y) => [-1, 1].map((l) => `<ellipse cx="${100 + l * 10}" cy="${y + 9}" rx="3.2" ry="11" fill="${COR.vagemSeca}"/>`).join('')).join('');
  }
  return corpo;
}

function galhos(altura, pares, comprimento) {
  const lista = [];
  for (let i = 0; i < pares; i++) {
    const y = SOLO - 18 - (altura - 28) * (i / Math.max(pares - 1, 1));
    const c = comprimento * (1 - (i / pares) * 0.45);
    lista.push({ x: 100, y, lado: 1, c }, { x: 100, y, lado: -1, c });
  }
  return lista;
}

function desenharGalhos(lista, cor = COR.folhaEscura) {
  return lista.map(({ x, y, lado, c }) => {
    const fx = x + lado * c;
    const fy = y + c * 0.18;
    return `<path d="M${x} ${y} L${fx.toFixed(1)} ${fy.toFixed(1)}" stroke="${COR.tronco}" stroke-width="2.4" stroke-linecap="round"/>
      ${folha(x + lado * c * 0.5, y + c * 0.09, lado, 9, cor, 20)}${folha(fx, fy, lado, 10, cor, 10)}`;
  }).join('');
}

function frutosCafe(lista, raio, corDe) {
  return lista.map(({ x, y, lado, c }, i) => {
    const pontos = [0.45, 0.7, 0.95];
    return pontos.map((t, k) => {
      const px = x + lado * c * t;
      const py = y + c * 0.18 * t + 5;
      return `<circle cx="${px.toFixed(1)}" cy="${py.toFixed(1)}" r="${raio}" fill="${corDe(i + k)}"/>`;
    }).join('');
  }).join('');
}

function floresCafe(lista, quantidade) {
  return lista.slice(0, quantidade).map(({ x, y, lado, c }) => {
    const px = x + lado * c * 0.8;
    const py = y + c * 0.18 * 0.8 + 3;
    return `<circle cx="${px.toFixed(1)}" cy="${py.toFixed(1)}" r="3.6" fill="#fff" stroke="#DADADA" stroke-width="1"/><circle cx="${(px + lado * 5).toFixed(1)}" cy="${(py + 3).toFixed(1)}" r="3" fill="#fff" stroke="#DADADA" stroke-width="1"/>`;
  }).join('');
}

function cafeDesenho(id, p) {
  if (id === 'pegando') {
    const h = 14 + 10 * p;
    return caule(h, COR.tronco, 3) + folha(100, SOLO - h, 1, 9, COR.folhaEscura, 25) + folha(100, SOLO - h, -1, 9, COR.folhaEscura, 25);
  }
  if (id === 'crescendo') {
    const h = 34 + 54 * p;
    const g = galhos(h, 2 + Math.round(5 * p), 24);
    return caule(h, COR.tronco, 4) + desenharGalhos(g) + folha(100, SOLO - h, 1, 9, COR.folhaEscura, 55) + folha(100, SOLO - h, -1, 9, COR.folhaEscura, 55);
  }
  const g = galhos(108, 8, 40);
  const base = caule(108, COR.tronco, 5) + desenharGalhos(g) + folha(100, SOLO - 108, 1, 10, COR.folhaEscura, 55) + folha(100, SOLO - 108, -1, 10, COR.folhaEscura, 55);
  if (id === 'ramos') return base;
  if (id === 'florada') return base + floresCafe(g, Math.ceil(g.length * (0.3 + 0.7 * p)));
  if (id === 'granacao') return base + frutosCafe(g, 2.5 + 2 * p, () => COR.verde);
  if (id === 'madura') {
    const corDe = (i) => {
      const r = (i * 37 % 10) / 10;
      if (p < 0.35) return r < 0.7 ? COR.verde : COR.amarelo;
      if (p < 0.7) return r < 0.4 ? COR.amarelo : r < 0.7 ? COR.vermelho : COR.verde;
      return r < 0.85 ? COR.vermelho : COR.amarelo;
    };
    return base + frutosCafe(g, 4.5, corDe);
  }
  return base + frutosCafe(g, 5, () => COR.vermelho);
}

export function desenharPlanta(sim) {
  const id = sim.fase.id;
  const p = Math.min(Math.max(sim.progressoFase, 0), 1);
  const corpo = sim.cultura === 'soja' ? sojaDesenho(id, p) : cafeDesenho(id, p);
  return `<svg class="planta" viewBox="0 0 200 200" role="img" aria-label="${sim.def.nome}: ${sim.fase.nome}">
    ${chao()}${corpo}
  </svg>`;
}
