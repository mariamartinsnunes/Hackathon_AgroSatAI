// Desenha a área em volta de você vista do satélite: foto aérea real (Esri) por baixo
// e o índice de verde (NDVI, Sentinel-2) por cima. Nada aqui é simulado:
// se a foto ou o satélite não chegam, a tela diz que não chegou.

export const LARGURA = 960, ALTURA = 720;

// A área analisada é o quadro inteiro (de 0 a 1 nos dois sentidos)
export const AREA_TODA = [[0, 0], [1, 0], [1, 1], [0, 1]];

const px = (p) => [p[0] * LARGURA, p[1] * ALTURA];

function caminho(ctx, pontos) {
  ctx.beginPath();
  pontos.forEach((p, i) => { const [x, y] = px(p); i ? ctx.lineTo(x, y) : ctx.moveTo(x, y); });
  ctx.closePath();
}

export function dentro(p, poli) { // ponto dentro do polígono?
  let ok = false;
  for (let i = 0, j = poli.length - 1; i < poli.length; j = i++) {
    const [xi, yi] = poli[i], [xj, yj] = poli[j];
    if ((yi > p[1]) !== (yj > p[1]) && p[0] < ((xj - xi) * (p[1] - yi)) / (yj - yi) + xi) ok = !ok;
  }
  return ok;
}

// ---------- imagens ----------
const imagens = new Map();
function carregarImagem(url, cors = true) {
  if (!imagens.has(url)) {
    const promessa = new Promise((ok, erro) => {
      const img = new Image();
      if (cors) img.crossOrigin = 'anonymous';
      img.onload = () => ok(img); img.onerror = () => erro(new Error('Imagem não carregou'));
      img.src = url;
    });
    promessa.catch(() => imagens.delete(url)); // deixa tentar de novo depois
    imagens.set(url, promessa);
  }
  return imagens.get(url);
}

// ---------- foto aérea (Esri World Imagery, em quadradinhos de ~280 m) ----------
// O servidor da Esri recebe só os quadradinhos que cobrem a área (uns 12), como em qualquer mapa.
const ESRI = 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile';
const ZOOM = 17; // ~1 m por ponto

function mercator(lon, lat, z) {
  const n = 256 * 2 ** z;
  const s = Math.sin((lat * Math.PI) / 180);
  return [((lon + 180) / 360) * n, (0.5 - Math.log((1 + s) / (1 - s)) / (4 * Math.PI)) * n];
}

function semFoto(ctx, texto) {
  ctx.fillStyle = '#5C6650'; ctx.fillRect(0, 0, LARGURA, ALTURA);
  ctx.fillStyle = 'rgba(255,255,255,.85)';
  ctx.font = '600 30px Roboto, system-ui, sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText(texto, LARGURA / 2, ALTURA - 40);
}

export async function desenharFoto(ctx, lav) {
  const bbox = lav.area?.bbox;
  if (!bbox) { semFoto(ctx, 'Sem foto aérea'); return; }
  const [o, s, l, n] = bbox;
  const [x0, y0] = mercator(o, n, ZOOM), [x1, y1] = mercator(l, s, ZOOM);
  const ex = LARGURA / (x1 - x0), ey = ALTURA / (y1 - y0);
  const pedacos = [];
  for (let tx = Math.floor(x0 / 256); tx <= Math.floor(x1 / 256); tx++) {
    for (let ty = Math.floor(y0 / 256); ty <= Math.floor(y1 / 256); ty++) pedacos.push([tx, ty]);
  }
  ctx.fillStyle = '#5C6650'; ctx.fillRect(0, 0, LARGURA, ALTURA);
  const r = await Promise.allSettled(pedacos.map(async ([tx, ty]) => {
    const img = await carregarImagem(`${ESRI}/${ZOOM}/${ty}/${tx}`, false);
    const x = Math.floor((tx * 256 - x0) * ex), y = Math.floor((ty * 256 - y0) * ey);
    ctx.drawImage(img, x, y, Math.ceil(256 * ex) + 1, Math.ceil(256 * ey) + 1);
  }));
  if (r.every((x) => x.status === 'rejected')) semFoto(ctx, 'A foto aérea não carregou');
}

// ---------- NDVI ----------
// 0,30 (vermelho) -> 0,55 (amarelo) -> 0,78 (verde)
const ESCALA = [[0.3, [196, 48, 32]], [0.45, [234, 128, 40]], [0.56, [244, 200, 52]], [0.66, [150, 196, 70]], [0.78, [38, 140, 64]]];
export function corNdvi(v) {
  if (v <= ESCALA[0][0]) return ESCALA[0][1];
  for (let i = 1; i < ESCALA.length; i++) {
    const [a, ca] = ESCALA[i - 1], [b, cb] = ESCALA[i];
    if (v <= b) { const t = (v - a) / (b - a); return ca.map((c, k) => Math.round(c + (cb[k] - c) * t)); }
  }
  return ESCALA[ESCALA.length - 1][1];
}

// Pinta a grade de NDVI (cada célula = 10 x 10 m). Célula sem dado (nuvem, água, fora da foto) fica transparente.
export function desenharNdvi(ctx, lav, grade, opacidade = 0.72) {
  const { colunas, linhas } = lav;
  const peq = document.createElement('canvas');
  peq.width = colunas; peq.height = linhas;
  const pc = peq.getContext('2d');
  const img = pc.createImageData(colunas, linhas);
  for (let j = 0; j < linhas; j++) for (let i = 0; i < colunas; i++) {
    const v = grade[j][i];
    if (v == null) continue;
    const [r, g, b] = corNdvi(v);
    const k = (j * colunas + i) * 4;
    img.data[k] = r; img.data[k + 1] = g; img.data[k + 2] = b; img.data[k + 3] = 255;
  }
  pc.putImageData(img, 0, 0);
  ctx.save();
  caminho(ctx, lav.talhao || AREA_TODA); ctx.clip();
  ctx.globalAlpha = opacidade;
  ctx.imageSmoothingEnabled = false; // mostra os quadradinhos de 10 m como o satélite vê
  ctx.drawImage(peq, 0, 0, LARGURA, ALTURA);
  ctx.restore();
}

export async function prepararPassagem() { /* a grade já vem pronta: nada para baixar */ }

export async function desenharPassagem(ctx, lav, passagem, opacidade = 0.72) {
  if (passagem?.grade) desenharNdvi(ctx, lav, passagem.grade, opacidade);
}

// Dia nublado: um véu cinza por cima da foto (não é dado, só mostra que não deu para ver)
export function desenharNuvens(ctx) {
  ctx.save();
  ctx.fillStyle = 'rgba(235,238,240,.78)'; ctx.fillRect(0, 0, LARGURA, ALTURA);
  ctx.restore();
}

// ---------- as 9 partes (3 x 3) ----------
// Nome de cada parte do jeito que se fala ("O canto de baixo, à esquerda, está perdendo o verde")
const NOMES = [
  ['O canto de cima, à esquerda,', 'A parte de cima', 'O canto de cima, à direita,'],
  ['O lado esquerdo', 'O meio', 'O lado direito'],
  ['O canto de baixo, à esquerda,', 'A parte de baixo', 'O canto de baixo, à direita,'],
];
export const nomeCurto = (nome) => nome.replace(/,$/, '');

export function caixasDasPartes(talhao = AREA_TODA) {
  const xs = talhao.map((p) => p[0]), ys = talhao.map((p) => p[1]);
  const x0 = Math.min(...xs), x1 = Math.max(...xs), y0 = Math.min(...ys), y1 = Math.max(...ys);
  const caixas = [];
  for (let l = 0; l < 3; l++) for (let c = 0; c < 3; c++) {
    caixas.push({
      linha: l, coluna: c,
      nome: NOMES[l][c],
      caixa: [x0 + (c * (x1 - x0)) / 3, y0 + (l * (y1 - y0)) / 3, (x1 - x0) / 3, (y1 - y0) / 3],
    });
  }
  return caixas;
}

// NDVI médio de cada parte (null = nuvem ou sem dado em boa parte dela)
export function valoresDasPartes(lav, passagem) {
  if (passagem.partes) return passagem.partes;
  if (!passagem.grade) return caixasDasPartes(lav.talhao).map(() => null);
  const { colunas, linhas } = lav;
  return caixasDasPartes(lav.talhao).map(({ caixa: [x0, y0, w, h] }) => {
    let soma = 0, n = 0, total = 0;
    for (let j = 0; j < linhas; j++) for (let i = 0; i < colunas; i++) {
      const x = (i + 0.5) / colunas, y = (j + 0.5) / linhas;
      if (x < x0 || x >= x0 + w || y < y0 || y >= y0 + h) continue;
      total++;
      const v = passagem.grade[j][i];
      if (v != null) { soma += v; n++; }
    }
    return n >= total * 0.4 ? soma / n : null;
  });
}

export function mediaPassagem(lav, passagem) {
  if (!passagem || passagem.nuvem) return null;
  const v = valoresDasPartes(lav, passagem).filter((x) => x != null);
  return v.length ? v.reduce((s, x) => s + x, 0) / v.length : null;
}

// Cor de cada ponto. Vermelho = preocupação (pouco verde OU perdeu verde desde a primeira foto).
export function estadoPonto(valor, queda) {
  if (valor == null) return { cor: 'cinza', nome: 'Sem dado' };
  if (valor < 0.5 || (queda != null && queda >= 0.08)) return { cor: 'vermelho', nome: 'Preocupação' };
  if (valor < 0.66 || (queda != null && queda >= 0.04)) return { cor: 'amarelo', nome: 'Atenção' };
  return { cor: 'verde', nome: 'Saudável' };
}

// Os 9 pontos de uma passagem, comparando com uma passagem anterior (se tiver)
export function pontosDaPassagem(lav, passagem, antes = null) {
  const agora = valoresDasPartes(lav, passagem);
  const base = antes && antes !== passagem ? valoresDasPartes(lav, antes) : null;
  return caixasDasPartes(lav.talhao).map((q, k) => {
    const valor = agora[k];
    const queda = base && base[k] != null && valor != null ? base[k] - valor : null;
    const { cor, nome: estado } = estadoPonto(valor, queda);
    return { ...q, valor, queda, cor, estado }; // nome = nome da parte ("O meio"); estado = "Saudável"...
  });
}

export function estadoNdvi(v) {
  const e = estadoPonto(v, null);
  return e.cor === 'cinza' ? { cor: 'cinza', nome: 'Sem dado' } : e;
}
