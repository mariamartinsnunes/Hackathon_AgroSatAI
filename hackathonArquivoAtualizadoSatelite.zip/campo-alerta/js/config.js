// ============================================================
//  CONFIGURAÇÃO — o único arquivo que vocês precisam mexer
//  para trocar de API. Cada serviço tem vários "provedores".
//  'mock' = dados INVENTADOS, só para testar sem internet.
//  NÃO usar 'mock' na apresentação: a regra do app é não inventar dado.
// ============================================================

export const CONFIG = {
  provedores: {
    clima: 'openmeteo', // 'mock' | 'openmeteo' | 'inmet' | 'nasa'
    fogo: 'inpe',      // 'inpe' (INPE Queimadas) | 'firms' | 'mock'
    plantio: 'zarc',   // 'mock' | 'zarc'   (lê dados/zarc-cafe.json — Tábua de Risco do ZARC, MAPA)
    produtos: 'agrofit', // 'mock' | 'agrofit' (lê dados/agrofit-cafe.json — Agrofit, MAPA)
    ia: 'api',         // 'api' (modelo de vocês no Render) | 'teachable' | 'mock'
    saude: 'planetary',   // 'planetary' (Sentinel-2 real, na localização ATUAL do aparelho)
    historico: 'openmeteo', // 'openmeteo' (clima medido desde o plantio) | 'nasa' (só no Vercel) | 'mock'
    ndvi: 'nenhum',       // 'nenhum' (lavoura sem contorno: não mostra satélite) | 'arquivo' | 'mock'
  },

  // Se um provedor real falhar: usa o último valor bom guardado no aparelho (com a data).
  // Se não tiver, a tela diz "sem informação agora". NUNCA cai em dado inventado.
  usarMockSeFalhar: false,

  // Endereço das funções do Vercel (pasta /api). Em produção fica ''.
  // Rodando local com Live Server, as funções não existem (o fogo tenta direto no INPE).
  baseApi: '',

  // VOZ CLONADA (ElevenLabs). A chave NÃO fica aqui: fica escondida no Vercel
  // (variáveis ELEVENLABS_API_KEY e ELEVENLABS_VOICE_ID). Veja o README.
  // Sem o Vercel (ex.: Live Server), o app usa a voz do navegador sozinho.
  vozIA: { ativa: true, aviso: 'Voz gerada por IA' },

  // API da IA da folha (FastAPI no Render, modelo MobileNetV2 treinado com DigiPathos).
  // proxy: caminho da função do Vercel que repassa a foto (resolve o bloqueio de CORS).
  iaApi: { url: 'https://fastapi-ml-7fcy.onrender.com', proxy: '/api/folha', esperaMs: 90000 },

  // Teachable Machine: cole aqui o link do modelo exportado
  // (ou deixe './modelo/' se colocar os arquivos na pasta modelo).
  modeloIA: './modelo/',

  // NASA FIRMS (reserva do fogo). Chave grátis: firms.modaps.eosdis.nasa.gov/api/map_key
  firmsKey: '',

  // Raio (km) para avisar fogo perto da plantação
  raioFogoKm: 30,

  // El Niño 2026/27 ativo: deixa os avisos de plantio mais cautelosos
  elNino: true,

  // Contato do técnico (Emater / Casa da Agricultura / cooperativa)
  tecnico: { nome: 'Técnico', telefone: '+551937433700' }, // (19) 3743-3700, número passado pelo time em 03/10

  // Município usado quando a pessoa não libera a localização
  municipioPadrao: { nome: 'Araraquara', uf: 'SP', geocodigo: '3503208', lat: -21.79, lon: -48.18 },

  culturas: [
    { id: 'cafe', nome: 'Café', ativo: true },
    { id: 'milho', nome: 'Milho', ativo: false },
    { id: 'mandioca', nome: 'Mandioca', ativo: false },
    { id: 'feijao', nome: 'Feijão', ativo: false },
  ],
};
