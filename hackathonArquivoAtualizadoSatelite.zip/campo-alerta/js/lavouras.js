// Junta o clima MEDIDO desde o plantio para cada lavoura cadastrada.
// Guarda o resultado na memória: abrir a mesma lavoura de novo é instantâneo.
import { resumoClima, estimarMaturacao } from './crescimento.js';
import { buscarHistorico } from './api/index.js';
import { paraISO } from './util.js';

const memoria = new Map();

export function analisarLavoura(lavoura, ctx, hoje = new Date()) {
  const chave = [lavoura.id, lavoura.plantio, lavoura.florada || '', lavoura.variedade || '', paraISO(hoje), ctx.municipio.geocodigo].join('|');
  if (memoria.has(chave)) return memoria.get(chave);

  const promessa = (async () => {
    // Busca o clima desde o que vier primeiro: o plantio ou a florada
    const inicio = lavoura.florada && lavoura.florada < lavoura.plantio ? lavoura.florada : lavoura.plantio;
    const historico = await buscarHistorico({ ...ctx, inicio, fim: paraISO(hoje) });
    return {
      lavoura, clima: resumoClima(lavoura, historico, hoje), maturacao: estimarMaturacao(lavoura, historico, hoje),
      exemplo: Boolean(historico.exemplo), fontes: historico.fonte,
    };
  })();

  memoria.set(chave, promessa);
  promessa.catch(() => memoria.delete(chave));
  return promessa;
}

// Se o clima não chegar, a lavoura aparece com "sem informação" (nunca com conta inventada)
export async function analisarTodas(perfil, ctx, hoje = new Date()) {
  const lista = perfil.lavouras || [];
  return Promise.all(lista.map((l) => analisarLavoura(l, ctx, hoje).catch((e) => ({ lavoura: l, erro: e.message }))));
}

// Frases curtas sobre o clima da lavoura (dado medido)
export function frasesClima(c) {
  return {
    dias: `Dia ${c.diasDesdePlantio} desde o plantio`,
    chuva: `Choveu ${c.chuva30} mm nos últimos 30 dias`,
    seca: c.semChuva >= 1 ? `${c.semChuva} ${c.semChuva === 1 ? 'dia' : 'dias'} sem chuva firme` : 'Choveu ontem',
    calor: c.maxMedia7 != null ? `Máxima média de ${c.maxMedia7}° na última semana` : null,
  };
}
