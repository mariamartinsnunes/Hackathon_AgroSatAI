// Perfil do produtor. Fica SÓ no aparelho (LGPD): nome e localização
// exata nunca são enviados para servidor nenhum.
const CHAVE = 'campo-alerta-perfil';

const VAZIO = {
  nome: '',
  cultura: 'cafe',
  lat: null,           // localização exata: só no aparelho
  lon: null,
  municipio: null,     // { nome, uf, geocodigo, lat, lon } — é só isso que sai do aparelho
  mesTradicional: null, // "quando você planta?" (1 a 12)
  lavouras: [],        // o que a pessoa plantou (nome da área, cultura, dia do plantio) — só no aparelho
  pronto: false,
};

let memoria = { ...VAZIO };

export function lerPerfil() {
  try {
    const salvo = JSON.parse(localStorage.getItem(CHAVE) || 'null');
    if (salvo) memoria = { ...VAZIO, ...salvo };
  } catch { /* navegador sem armazenamento: segue em memória */ }
  return memoria;
}

export function salvarPerfil(mudancas) {
  memoria = { ...memoria, ...mudancas };
  try { localStorage.setItem(CHAVE, JSON.stringify(memoria)); } catch { /* ok */ }
  return memoria;
}

export function apagarPerfil() {
  memoria = { ...VAZIO };
  try { localStorage.removeItem(CHAVE); } catch { /* ok */ }
}
