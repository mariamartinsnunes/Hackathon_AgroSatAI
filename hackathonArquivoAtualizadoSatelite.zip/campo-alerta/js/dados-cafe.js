// O que a IA da folha sabe reconhecer. As chaves são os nomes das classes do modelo
// (a API manda "bicho_mineiro"; o app troca "_" por "-").
export const PROBLEMAS = {
  ferrugem: {
    nome: 'Ferrugem', cientifico: 'Hemileia vastatrix',
    sinal: 'Pó alaranjado embaixo da folha',
  },
  cercosporiose: {
    nome: 'Olho-pardo', cientifico: 'Cercospora coffeicola',
    sinal: 'Mancha marrom com centro claro',
  },
  'bicho-mineiro': {
    nome: 'Bicho-mineiro', cientifico: 'Leucoptera coffeella',
    sinal: 'Mancha seca que descasca',
  },
  'mancha-aureolada': {
    nome: 'Mancha-aureolada', cientifico: 'Pseudomonas syringae pv. garcae',
    sinal: 'Mancha escura com borda amarelada',
  },
  'mancha-manteigosa': {
    nome: 'Mancha-manteigosa', cientifico: 'Colletotrichum spp.',
    sinal: 'Manchas claras, com jeito de óleo',
  },
  phoma: {
    nome: 'Mancha de Phoma', cientifico: 'Phoma spp.',
    sinal: 'Mancha escura nas folhas novas e nas pontas',
  },
  saudavel: {
    nome: 'Folha saudável', cientifico: '',
    sinal: 'Não vimos problema',
  },
};
