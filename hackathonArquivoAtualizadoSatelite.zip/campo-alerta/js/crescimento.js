// MINHAS LAVOURAS — só o que é DADO REAL (sem fase nem colheita estimadas).
// Antes havia uma simulação por graus-dia (fases, % até a colheita, "atrasada X dias").
// Ela foi tirada em 03/10: os limites de graus-dia não tinham fonte oficial e o "atraso"
// dependia de um verde de satélite inventado. Quando houver fonte (Embrapa/agrônomo), volta.
import { deISO, paraISO, somarDias, diasEntre } from './util.js';

export const CULTURAS = {
  cafe: { id: 'cafe', nome: 'Café' },
};

// Resume o clima MEDIDO desde o plantio (Open-Meteo). historico.dias = [{ data, max, min, chuvaMm }]
export function resumoClima(lavoura, historico, hoje = new Date()) {
  const ontem = paraISO(somarDias(hoje, -1));
  const dias = (historico.dias || [])
    .filter((d) => d.data <= ontem && Number.isFinite(d.chuvaMm)) // hoje ainda não acabou: fica de fora
    .sort((a, b) => a.data.localeCompare(b.data));
  const desde = (n) => paraISO(somarDias(hoje, -n));
  const soma = (lista) => Math.round(lista.reduce((s, d) => s + d.chuvaMm, 0));

  let semChuva = 0; // dias seguidos sem chuva firme (menos de 2 mm), contando de ontem para trás
  for (let i = dias.length - 1; i >= 0 && dias[i].chuvaMm < 2; i--) semChuva++;

  const ultimos7 = dias.filter((d) => d.data >= desde(7) && Number.isFinite(d.max));
  return {
    diasDesdePlantio: Math.max(diasEntre(deISO(lavoura.plantio), hoje), 0),
    chuva30: soma(dias.filter((d) => d.data >= desde(30))),
    chuvaTotal: soma(dias),
    semChuva,
    maxMedia7: ultimos7.length ? Math.round(ultimos7.reduce((s, d) => s + d.max, 0) / ultimos7.length) : null,
    diasMedidos: dias.length,
  };
}

// ---------- Época de maturação (colheita) a partir da FLORADA ----------
// Fonte: Bardin-Camparotto, L.; Camargo, M. B. P.; Moraes, J. F. L. (2012). "Época provável de maturação
// para diferentes cultivares de café arábica para o Estado de São Paulo". Ciência Rural (IAC).
// Método: soma diária de (temperatura média - 10,2 °C) desde a florada. A maturação acontece quando a soma
// chega ao valor de cada cultivar. Usamos a temperatura média MEDIDA (Open-Meteo).
export const MATURACAO = {
  tb: 10.2,
  fonte: 'Bardin-Camparotto, Camargo e Moraes (2012), Ciência Rural, IAC',
  cultivares: {
    'mundo-novo': { nome: 'Mundo Novo', gd: 2900 },
    catuai: { nome: 'Catuaí', gd: 2990 },
    obata: { nome: 'Obatã', gd: 3203 },
  },
};

export function estimarMaturacao(lavoura, historico, hoje = new Date()) {
  if (!lavoura.florada) return null;
  const hojeISO = paraISO(hoje);
  const media = (d) => (Number.isFinite(d.media) ? d.media : (Number.isFinite(d.max) && Number.isFinite(d.min) ? (d.max + d.min) / 2 : null));
  const dias = (historico.dias || [])
    .filter((d) => d.data >= lavoura.florada && d.data < hojeISO && media(d) != null)
    .sort((a, b) => a.data.localeCompare(b.data));
  const gd = (d) => Math.max(media(d) - MATURACAO.tb, 0);
  const soma = dias.reduce((s, d) => s + gd(d), 0);
  const ult = dias.slice(-30);
  const ritmo = ult.length >= 7 ? ult.reduce((s, d) => s + gd(d), 0) / ult.length : null; // graus-dia por dia, último mês
  const desde = Math.max(diasEntre(deISO(lavoura.florada), hoje), 0);
  const escolhida = MATURACAO.cultivares[lavoura.variedade];
  const lista = escolhida ? [escolhida] : Object.values(MATURACAO.cultivares);
  return {
    soma: Math.round(soma),
    desde,
    faltamDiasDeDado: Math.max(desde - dias.length, 0),
    alvos: lista.map((c) => {
      const falta = c.gd - soma;
      const dias = falta <= 0 ? 0 : ritmo ? Math.ceil(falta / ritmo) : null;
      return { ...c, pct: Math.min(Math.round((soma / c.gd) * 100), 100), pronto: falta <= 0, data: dias == null ? null : somarDias(hoje, dias) };
    }),
  };
}
