// Porta única de dados. As telas só chamam estas funções —
// nunca uma API direto. Para trocar de API, mude js/config.js.
import { CONFIG } from '../config.js';
import * as clima from './clima.js';
import * as fogo from './fogo.js';
import * as plantio from './plantio.js';
import * as produtos from './produtos.js';
import * as ia from './ia.js';
import * as saude from './saude.js';
import * as historico from './historico.js';
import * as ndvi from './ndvi.js';

const SERVICOS = { clima, fogo, plantio, produtos, ia, saude, historico, ndvi };
const cache = new Map();

// Quanto tempo um resultado bom vale guardado NO APARELHO (nunca vai para servidor nenhum).
// Dentro do prazo a tela abre na hora, sem esperar a internet.
const VALIDADE = { clima: 30 * 60e3, fogo: 30 * 60e3, plantio: 7 * 864e5, produtos: 7 * 864e5, saude: 6 * 36e5 };
// Tempo máximo de espera por API. Passou disso: usa o último valor guardado ou o exemplo.
// A IA da folha não entra aqui: ela tem a própria espera (o servidor gratuito demora a acordar).
const ESPERA_MS = { clima: 6000, fogo: 20000, plantio: 6000, produtos: 6000, saude: 40000, historico: 10000, ndvi: 10000 };
const PREFIXO = 'campo-alerta-cache:';

function lerGuardado(chave) {
  try { return JSON.parse(localStorage.getItem(PREFIXO + chave)); } catch { return null; }
}
function guardarNoAparelho(chave, valor) {
  try { localStorage.setItem(PREFIXO + chave, JSON.stringify({ t: Date.now(), valor })); } catch { /* sem espaço: segue sem guardar */ }
}

function comLimite(promessa, ms, servico) {
  if (!ms) return promessa;
  let relogio;
  const estouro = new Promise((_, erro) => { relogio = setTimeout(() => erro(new Error(`${servico}: passou de ${ms / 1000}s`)), ms); });
  return Promise.race([promessa, estouro]).finally(() => clearTimeout(relogio));
}

async function chamar(servico, ctx, { guardar = true } = {}) {
  const nome = CONFIG.provedores[servico] || 'mock';
  // Satélite: a chave é a sua posição (~100 m). Esse guardado fica só no aparelho.
  const extra = servico === 'saude' ? `${ctx.local.lat.toFixed(3)},${ctx.local.lon.toFixed(3)}` : ctx?.municipio?.geocodigo || '';
  const chave = `${servico}:${nome}:${extra}`;
  if (guardar && cache.has(chave)) return cache.get(chave);

  const validade = guardar && nome !== 'mock' ? VALIDADE[servico] : 0;
  const salvo = validade ? lerGuardado(chave) : null;
  if (salvo && Date.now() - salvo.t < validade) {
    cache.set(chave, salvo.valor);
    return salvo.valor;
  }

  const lista = SERVICOS[servico].provedores;
  let resultado;
  try {
    resultado = await comLimite(lista[nome](ctx), ESPERA_MS[servico], servico);
    if (Array.isArray(resultado)) resultado = { itens: resultado };
    resultado.exemplo = nome === 'mock';
    if (validade) guardarNoAparelho(chave, resultado);
  } catch (erro) {
    // Diagnóstico da folha NUNCA cai no exemplo: mostrar doença inventada seria enganar o produtor
    if (nome === 'mock' || servico === 'ia') throw erro;
    if (salvo) { // sem internet: mostra o último valor bom, avisando que é antigo
      console.warn(`[${servico}] ${nome} falhou, usando o último valor guardado:`, erro.message);
      resultado = { ...salvo.valor, fonte: `${salvo.valor.fonte || nome} (último valor salvo)` };
    } else {
      if (!CONFIG.usarMockSeFalhar) throw erro;
      console.warn(`[${servico}] ${nome} falhou, usando exemplo:`, erro.message);
      resultado = await lista.mock(ctx);
      if (Array.isArray(resultado)) resultado = { itens: resultado };
      resultado.exemplo = true;
    }
  }
  if (guardar) cache.set(chave, resultado);
  return resultado;
}

// ctx = { municipio, centro } — centro é a localização da plantação (só usada no aparelho)
export const buscarClima = (ctx) => chamar('clima', ctx);
export const buscarFogo = (ctx) => chamar('fogo', ctx);
export const buscarPlantio = (ctx) => chamar('plantio', ctx);
export const buscarSaude = (ctx) => chamar('saude', ctx);
export const buscarHistorico = (ctx) => chamar('historico', ctx, { guardar: false }); // lavouras.js já guarda
export const buscarNdvi = (ctx) => chamar('ndvi', ctx, { guardar: false });
export const buscarProdutos = (ctx) => chamar('produtos', ctx);
export const diagnosticar = async (imagem) => (await chamar('ia', { imagem }, { guardar: false })).itens;

export function limparCache() {
  cache.clear();
  try { Object.keys(localStorage).filter((k) => k.startsWith(PREFIXO)).forEach((k) => localStorage.removeItem(k)); } catch { /* ok */ }
}
