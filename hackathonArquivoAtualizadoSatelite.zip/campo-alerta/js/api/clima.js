// CLIMA — todo provedor devolve o MESMO formato:
// { hoje: { max, min, chuvaMm, ceu: 'sol'|'nuvem'|'chuva', frase,
//           agora?, umidade?, ventoKmh? },   // os com ? são opcionais
//   dias: [{ nome, ceu, max, chuvaMm }],  // próximos dias
//   fonte }
import { CONFIG } from '../config.js';
import { DIAS, arredondar } from '../util.js';

function proximosNomes(n) {
  const hoje = new Date().getDay();
  return Array.from({ length: n }, (_, i) => DIAS[(hoje + i + 1) % 7]);
}

// Código do tempo da OMM (o Open-Meteo usa) -> sol / nuvem / chuva
function ceuDoCodigo(cod) {
  if (cod >= 51) return 'chuva';   // garoa, chuva, pancada, trovoada
  if (cod >= 2) return 'nuvem';    // parcialmente nublado, nublado, neblina
  return 'sol';
}
const frase = (ceu, max) => (ceu === 'chuva' ? 'Chuva' : ceu === 'nuvem' ? 'Nublado' : max >= 33 ? 'Sol forte' : 'Sol');

export const provedores = {
  async mock() {
    const nomes = proximosNomes(5);
    return {
      hoje: { max: 34, min: 19, chuvaMm: 0, ceu: 'sol', frase: 'Sol forte', agora: 31, umidade: 28, ventoKmh: 14 },
      dias: [
        { nome: nomes[0], ceu: 'sol', max: 35, chuvaMm: 0 },
        { nome: nomes[1], ceu: 'nuvem', max: 33, chuvaMm: 0 },
        { nome: nomes[2], ceu: 'chuva', max: 27, chuvaMm: 8 },
        { nome: nomes[3], ceu: 'nuvem', max: 29, chuvaMm: 2 },
        { nome: nomes[4], ceu: 'chuva', max: 26, chuvaMm: 6 },
      ],
      fonte: 'Exemplo',
    };
  },

  // OPEN-METEO — chama direto do navegador (aceita CORS, sem chave, grátis p/ uso não comercial).
  // Manda só a localização GROSSA (~11 km): para previsão do tempo é mais que suficiente.
  async openmeteo({ centro }) {
    const q = new URLSearchParams({
      latitude: arredondar(centro.lat),
      longitude: arredondar(centro.lon),
      current: 'temperature_2m,relative_humidity_2m,precipitation,wind_speed_10m,weather_code',
      daily: 'weather_code,temperature_2m_max,temperature_2m_min,precipitation_sum,precipitation_probability_max',
      timezone: 'America/Sao_Paulo',
      forecast_days: '6',
    });
    const r = await fetch(`https://api.open-meteo.com/v1/forecast?${q}`);
    if (!r.ok) throw new Error('Open-Meteo respondeu ' + r.status);
    const j = await r.json();
    const c = j.current, d = j.daily;
    const ceuHoje = ceuDoCodigo(d.weather_code[0]);
    return {
      hoje: {
        max: Math.round(d.temperature_2m_max[0]),
        min: Math.round(d.temperature_2m_min[0]),
        chuvaMm: Math.round(d.precipitation_sum[0]),
        ceu: ceuHoje,
        frase: frase(ceuHoje, d.temperature_2m_max[0]),
        agora: Math.round(c.temperature_2m),
        umidade: Math.round(c.relative_humidity_2m),
        ventoKmh: Math.round(c.wind_speed_10m),
      },
      dias: d.time.slice(1).map((data, i) => ({
        nome: DIAS[new Date(data + 'T12:00').getDay()],
        ceu: ceuDoCodigo(d.weather_code[i + 1]),
        max: Math.round(d.temperature_2m_max[i + 1]),
        chuvaMm: Math.round(d.precipitation_sum[i + 1]),
        chance: d.precipitation_probability_max?.[i + 1],
      })),
      fonte: 'Open-Meteo',
    };
  },

  // INMET (governo) — passa pela função /api/clima por causa de CORS.
  // Só manda o código do município, nunca a localização exata.
  async inmet({ municipio }) {
    const r = await fetch(`${CONFIG.baseApi}/api/clima?fonte=inmet&geocodigo=${municipio.geocodigo}`);
    if (!r.ok) throw new Error('INMET fora do ar');
    return r.json();
  },

  // NASA POWER — reserva. Usa localização grossa (~11 km).
  async nasa({ municipio }) {
    const r = await fetch(`${CONFIG.baseApi}/api/clima?fonte=nasa&lat=${municipio.lat}&lon=${municipio.lon}`);
    if (!r.ok) throw new Error('NASA POWER fora do ar');
    return r.json();
  },
};
