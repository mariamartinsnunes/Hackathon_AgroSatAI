// HISTÓRICO DO CLIMA desde o plantio (temperatura e chuva de cada dia) — usado pelas lavouras.
// Todo provedor devolve: { dias: [{ data, max, min, chuvaMm }], fonte }
import { CONFIG } from '../config.js';
import { arredondar, deISO, paraISO, somarDias, diasEntre, aleatorioDe as aleatorio } from '../util.js';
// (o 'mock' abaixo é inventado: só para testar sem internet. O app usa 'openmeteo'.)


function diaDoAno(d) {
  return diasEntre(new Date(d.getFullYear(), 0, 0), d);
}

export const provedores = {
  async mock({ inicio, fim }) {
    const ini = deISO(inicio);
    const total = diasEntre(ini, deISO(fim));
    const dias = [];
    for (let i = 0; i <= total; i++) {
      const dia = somarDias(ini, i);
      const data = paraISO(dia);
      const estacao = Math.cos((2 * Math.PI * (diaDoAno(dia) - 20)) / 365);
      const max = 29.5 + 3.5 * estacao + (aleatorio(data + 'x') - 0.5) * 5;
      const min = 16 + 4 * estacao + (aleatorio(data + 'n') - 0.5) * 3;
      const chove = aleatorio(data + 'c') < 0.26 + 0.2 * estacao;
      const chuvaMm = chove ? Math.round(2 + aleatorio(data + 'q') * 24) : 0;
      dias.push({ data, max: Math.round(max * 10) / 10, min: Math.round(min * 10) / 10, chuvaMm });
    }
    return { dias, fonte: 'Exemplo' };
  },

  // DADO REAL: Open-Meteo, direto do navegador (sem chave, aceita CORS). Localização GROSSA (~11 km).
  // Dias antigos: arquivo histórico (ERA5, chega com ~5 dias de atraso). Últimos 14 dias: previsão já medida.
  async openmeteo({ centro, inicio, fim }) {
    const lat = arredondar(centro.lat), lon = arredondar(centro.lon);
    const diario = 'temperature_2m_max,temperature_2m_min,precipitation_sum';
    const comum = `latitude=${lat}&longitude=${lon}&daily=${diario}&timezone=America%2FSao_Paulo`;
    const ultimo = deISO(fim);
    const corte = paraISO(somarDias(ultimo, -10)); // o arquivo vai até aqui; depois, a previsão cobre
    const pedidos = [];
    if (inicio <= corte) pedidos.push(`https://archive-api.open-meteo.com/v1/archive?${comum}&start_date=${inicio}&end_date=${corte}`);
    pedidos.push(`https://api.open-meteo.com/v1/forecast?${comum}&past_days=14&forecast_days=1`);
    const respostas = await Promise.all(pedidos.map(async (url) => {
      const r = await fetch(url);
      if (!r.ok) throw new Error('Open-Meteo respondeu ' + r.status);
      return (await r.json()).daily;
    }));
    const porData = new Map();
    respostas.forEach((d) => d.time.forEach((data, i) => {
      const max = d.temperature_2m_max[i], min = d.temperature_2m_min[i];
      if (data < inicio || data > fim || max == null || min == null) return; // dia sem medida: fica de fora (não inventa)
      porData.set(data, { data, max, min, chuvaMm: d.precipitation_sum[i] ?? null });
    }));
    const dias = [...porData.values()].sort((a, b) => a.data.localeCompare(b.data));
    if (!dias.length) throw new Error('Open-Meteo sem dias medidos');
    return { dias, fonte: 'Open-Meteo (clima medido)' };
  },

  async nasa({ centro, inicio, fim }) {
    const q = `fonte=nasa-hist&lat=${arredondar(centro.lat)}&lon=${arredondar(centro.lon)}&inicio=${inicio}&fim=${fim}`;
    const r = await fetch(`${CONFIG.baseApi}/api/clima?${q}`);
    if (!r.ok) throw new Error('NASA POWER fora do ar');
    return r.json();
  },
};
