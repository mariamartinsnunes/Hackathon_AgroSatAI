// SAÚDE DA LAVOURA (NDVI do Sentinel-2) EM VOLTA DE ONDE VOCÊ ESTÁ — todo provedor devolve:
// {
//   passagens: [{ data: 'AAAA-MM-DD', nuvem: bool, grade: [[ndvi|null...]...] | null, partes: [9 x ndvi|null] }], // mais antiga primeiro
//   colunas, linhas,       // grade sobre a área (cada célula = 10 x 10 m, o tamanho do ponto do satélite)
//   talhao,                // contorno analisado, de 0 a 1 (aqui: a área toda)
//   area: { bbox, larguraM, alturaM, centro, precisaoM },
//   passou: { vezes, ultima, menorIntervalo, maiorIntervalo, satelites }, credito, fonte
// }
// NDVI: 0,8 = muito verde/saudável · 0,5 = atenção · 0,3 ou menos = pouco verde
//
// PRIVACIDADE: a posição exata NUNCA sai do aparelho. O servidor do satélite recebe só um quadrado
// de ~2,5 km centrado num ponto ARREDONDADO (grade de 0,01°, ~1 km). O app baixa o NDVI desse
// quadrado inteiro e recorta a sua área AQUI no celular.

import { caixasDasPartes, AREA_TODA } from '../satelite.js';

const PC = 'https://planetarycomputer.microsoft.com/api';
// NDVI = (infravermelho - vermelho) / (infravermelho + vermelho).
// No Sentinel-2 L2A (desde 2022) cada banda vem somada de 1000: por isso o "- 2000".
const NDVI = '(B08-B04)/(B08+B04-2000)';
// Classes do mapa SCL do Sentinel-2
const NUVEM = [3, 8, 9, 10]; // sombra de nuvem, nuvem média, nuvem alta, cirro
const FORA = [0, 1, 6];      // sem dado, pixel com defeito, água (água não é planta: fica de fora)

export const AREA = { larguraM: 800, alturaM: 600 }; // 4 x 3, do jeito da tela
const PIXEL_M = 10;
const COLS = AREA.larguraM / PIXEL_M, LINHAS = AREA.alturaM / PIXEL_M; // 80 x 60
const GRADE = 0.01;          // arredondamento do ponto que sai do aparelho
const MEIO_QUADRADO = 0.012; // o quadrado pedido tem 0,024° de lado (~2,5 km)
const M_POR_GRAU = 111320;

const diaISO = (d) => d.toISOString().slice(0, 10);
// Dia da passagem no horário de Brasília (o satélite passa por SP perto das 10h20)
const diaLocal = (iso) => new Date(iso).toLocaleDateString('en-CA', { timeZone: 'America/Sao_Paulo' });
const cosLat = (lat) => Math.cos((lat * Math.PI) / 180);

// A sua área: 800 x 600 m com você no meio (fica só no aparelho)
export function areaEmVolta({ lat, lon }) {
  const dLat = AREA.alturaM / 2 / M_POR_GRAU;
  const dLon = AREA.larguraM / 2 / (M_POR_GRAU * cosLat(lat));
  return [lon - dLon, lat - dLat, lon + dLon, lat + dLat];
}

// O que vai para o servidor: um quadrado em volta do ponto da grade mais perto (não em volta de você)
export function quadradoPublico({ lat, lon }) {
  const r = (v) => Math.round(v / GRADE) * GRADE;
  const la = r(lat), lo = r(lon);
  return [lo - MEIO_QUADRADO, la - MEIO_QUADRADO, lo + MEIO_QUADRADO, la + MEIO_QUADRADO].map((v) => +v.toFixed(4));
}

// Ponto dentro do contorno da imagem do satélite (Polygon ou MultiPolygon, em lon/lat)?
function naImagem([lon, lat], geometria) {
  const poligonos = geometria.type === 'Polygon' ? [geometria.coordinates] : geometria.coordinates;
  return poligonos.some(([anel]) => {
    let ok = false;
    for (let i = 0, j = anel.length - 1; i < anel.length; j = i++) {
      const [xi, yi] = anel[i], [xj, yj] = anel[j];
      if ((yi > lat) !== (yj > lat) && lon < ((xj - xi) * (lat - yi)) / (yj - yi) + xi) ok = !ok;
    }
    return ok;
  });
}

// Baixa um PNG do Planetary Computer e devolve os números de cada ponto (sem mexer nas cores)
async function lerPng(url) {
  const r = await fetch(url);
  if (!r.ok) throw new Error('Planetary Computer respondeu ' + r.status);
  const bmp = await createImageBitmap(await r.blob(), { premultiplyAlpha: 'none', colorSpaceConversion: 'none' });
  const c = document.createElement('canvas');
  c.width = bmp.width; c.height = bmp.height;
  const ctx = c.getContext('2d', { willReadFrequently: true });
  ctx.drawImage(bmp, 0, 0);
  return { w: c.width, h: c.height, px: ctx.getImageData(0, 0, c.width, c.height).data };
}

// Recorta a sua área de dentro do quadrado baixado: uma célula de 10 m por vez
function recortar(img, quadrado, area, converter) {
  const [qo, qs, ql, qn] = quadrado, [ao, as, al, an] = area;
  const grade = [];
  for (let j = 0; j < LINHAS; j++) {
    const lat = an - ((j + 0.5) / LINHAS) * (an - as);
    const y = Math.min(img.h - 1, Math.max(0, Math.floor(((qn - lat) / (qn - qs)) * img.h)));
    const linha = [];
    for (let i = 0; i < COLS; i++) {
      const lon = ao + ((i + 0.5) / COLS) * (al - ao);
      const x = Math.min(img.w - 1, Math.max(0, Math.floor(((lon - qo) / (ql - qo)) * img.w)));
      const k = (y * img.w + x) * 4;
      linha.push(img.px[k + 3] === 0 ? null : converter(img.px[k]));
    }
    grade.push(linha);
  }
  return grade;
}

function mediasDasPartes(grade) {
  return caixasDasPartes(AREA_TODA).map(({ caixa: [x0, y0, w, h] }) => {
    let soma = 0, n = 0, total = 0;
    for (let j = 0; j < LINHAS; j++) for (let i = 0; i < COLS; i++) {
      const x = (i + 0.5) / COLS, y = (j + 0.5) / LINHAS;
      if (x < x0 || x >= x0 + w || y < y0 || y >= y0 + h) continue;
      total++;
      if (grade[j][i] != null) { soma += grade[j][i]; n++; }
    }
    return n >= total * 0.4 ? +(soma / n).toFixed(3) : null; // menos de 40% visível: sem dado
  });
}

export const provedores = {
  // DADO REAL: Sentinel-2 pelo Microsoft Planetary Computer (grátis, sem chave, aceita CORS).
  // Foto de fundo: Esri World Imagery (alta resolução, mas pode ser de meses ou anos atrás).
  async planetary({ local }) {
    if (!local) throw new Error('Sem localização');
    const area = areaEmVolta(local);
    const quadrado = quadradoPublico(local);
    const larguraPx = Math.round(((quadrado[2] - quadrado[0]) * M_POR_GRAU * cosLat(local.lat)) / PIXEL_M);
    const alturaPx = Math.round(((quadrado[3] - quadrado[1]) * M_POR_GRAU) / PIXEL_M);

    const busca = await fetch(`${PC}/stac/v1/search`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        collections: ['sentinel-2-l2a'], bbox: quadrado,
        datetime: `${diaISO(new Date(Date.now() - 80 * 864e5))}/${diaISO(new Date())}`,
        // SEM filtro de nuvem: todas as passagens aparecem, as nubladas marcadas como nubladas
        sortby: [{ field: 'datetime', direction: 'desc' }], limit: 100,
      }),
    });
    if (!busca.ok) throw new Error('Busca do Sentinel-2 falhou');
    const itens = (await busca.json()).features || [];

    // Só imagens que cobrem a área inteira; uma por dia (a com menos nuvem); as 6 mais recentes
    const cantos = [[area[0], area[1]], [area[2], area[1]], [area[2], area[3]], [area[0], area[3]]];
    const porDia = new Map();
    for (const f of itens) {
      if (!f.geometry || !cantos.every((c) => naImagem(c, f.geometry))) continue;
      const dia = diaLocal(f.properties.datetime);
      if (!porDia.has(dia) || f.properties['eo:cloud_cover'] < porDia.get(dia).properties['eo:cloud_cover']) porDia.set(dia, f);
    }
    const todasAsDatas = [...porDia.keys()].sort();
    const escolhidos = [...porDia.entries()].sort((a, b) => (a[0] < b[0] ? 1 : -1)).slice(0, 6).reverse();
    if (!escolhidos.length) throw new Error('Nenhuma foto do satélite nos últimos 80 dias');

    const base = `${PC}/data/v1/item/bbox/${quadrado.join(',')}/${larguraPx}x${alturaPx}.png?collection=sentinel-2-l2a`;
    const total = COLS * LINHAS;

    const passagens = await Promise.all(escolhidos.map(async ([data, item]) => {
      // 1) Mapa de classes (nuvem, água...) do dia
      const scl = recortar(await lerPng(`${base}&item=${item.id}&assets=SCL`), quadrado, area, (v) => v);
      let nuvem = 0, semDado = 0;
      scl.flat().forEach((c) => { if (c == null || c === 0) semDado++; else if (NUVEM.includes(c)) nuvem++; });
      if (semDado > total * 0.5) return null;                            // a imagem não cobre a área: ignora
      if (nuvem > (total - semDado) * 0.1) return { data, nuvem: true, grade: null, partes: null }; // mais de 10% com nuvem: nublado (nuvem fina baixa o verde e daria alarme falso)

      // 2) NDVI do dia (0 a 1 vira 0 a 255 no PNG; o app volta para 0 a 1)
      const params = `&item=${item.id}&assets=B04&assets=B08&asset_as_band=true&expression=${encodeURIComponent(NDVI)}&rescale=0,1`;
      const ndvi = recortar(await lerPng(base + params), quadrado, area, (v) => +(v / 255).toFixed(3));
      const grade = ndvi.map((linha, j) => linha.map((v, i) => {
        const c = scl[j][i];
        return v == null || c == null || NUVEM.includes(c) || FORA.includes(c) ? null : v;
      }));
      return { data, nuvem: false, grade, partes: mediasDasPartes(grade) };
    }));

    const validas = passagens.filter(Boolean);
    if (!validas.length) throw new Error('As fotos do satélite não cobrem esta área');
    // Quantas vezes o satélite passou de verdade aqui nos últimos 80 dias (nada de previsão inventada)
    const intervalos = todasAsDatas.slice(1).map((d, i) => (new Date(d) - new Date(todasAsDatas[i])) / 864e5);
    return {
      passou: {
        vezes: todasAsDatas.length,
        ultima: todasAsDatas.at(-1),
        menorIntervalo: intervalos.length ? Math.min(...intervalos) : null,
        maiorIntervalo: intervalos.length ? Math.max(...intervalos) : null,
        satelites: [...new Set(itens.map((f) => f.id.slice(0, 3)))].sort().map((s) => 'Sentinel-' + s.slice(1)).join(', '),
      },
      passagens: validas,
      colunas: COLS, linhas: LINHAS, talhao: AREA_TODA,
      area: { bbox: area, ...AREA, centro: { lat: local.lat, lon: local.lon }, precisaoM: local.precisaoM },
      credito: 'Cores da saúde: Copernicus Sentinel-2 (via Microsoft Planetary Computer). Foto de fundo: Esri World Imagery (pode ser de meses ou anos atrás).',
      fonte: 'Sentinel-2',
    };
  },
};
