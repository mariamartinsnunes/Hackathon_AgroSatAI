// PLANTIO (ZARC / MAPA) — todo provedor devolve:
// { riscos: [36 números], fonte }
// Um número por decêndio do ano: 20 = risco baixo, 30 = médio, 40 = alto, 0 = não indicado.
// Para café (perene) o ZARC indica a época de plantar as MUDAS.

export const provedores = {
  async mock() {
    const riscos = Array.from({ length: 36 }, (_, i) => {
      const dec = i + 1;
      if (dec >= 28 || dec <= 3) return 20;  // out a jan: boa época (chuvas)
      if (dec === 27 || dec === 4) return 30;
      return 0;
    });
    return { riscos, fonte: 'Exemplo' };
  },

  // Lê dados/zarc-cafe.json: a Tábua de Risco do ZARC (MAPA, dados.agricultura.gov.br) já filtrada para café em SP.
  // Cada padrão tem 36 dígitos (um por decêndio): 0 = não indicado, 1 = 20%, 2 = 30%, 3 = 40%.
  // (O script scripts/gerar_zarc.py gera a mesma coisa em lista de números; os dois formatos funcionam.)
  async zarc({ municipio }) {
    const r = await fetch('dados/zarc-cafe.json');
    if (!r.ok) throw new Error('Arquivo do ZARC não encontrado');
    const tabela = await r.json();
    let linha = tabela.municipios?.[municipio.geocodigo];
    if (linha == null) throw new Error(`ZARC sem café para ${municipio.nome}`);
    if (typeof linha === 'number') linha = tabela.padroes[linha]; // municípios iguais dividem o mesmo padrão
    const riscos = typeof linha === 'string' ? [...linha].map((c) => [0, 20, 30, 40][+c]) : linha;
    const tipo = tabela.canefora?.includes(municipio.geocodigo) ? 'canéfora' : 'arábica';
    return { riscos, tipo, fonte: `ZARC/MAPA (café ${tipo})` };
  },
};
