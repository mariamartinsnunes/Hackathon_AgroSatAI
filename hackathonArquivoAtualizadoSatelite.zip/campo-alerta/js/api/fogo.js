// FOGO VISTO POR SATÉLITE — todo provedor devolve:
// { focos: [{ lat, lon, quando }], fonte }
// A distância até a plantação é calculada NO APARELHO (a localização exata não sai dele).
import { CONFIG } from '../config.js';
import { arredondar, distanciaKm } from '../util.js';

const dataUTC = (diasAtras) => new Date(Date.now() - diasAtras * 864e5).toISOString().slice(0, 10).replace(/-/g, '');

function lerCsv(texto) {
  const linhas = texto.trim().split(/\r?\n/);
  const cab = linhas.shift().split(',').map((c) => c.trim().toLowerCase());
  const i = (...nomes) => cab.findIndex((c) => nomes.includes(c));
  const iLat = i('lat', 'latitude'), iLon = i('lon', 'longitude'), iData = i('data_hora_gmt', 'data_pas', 'datahora');
  if (iLat < 0 || iLon < 0) throw new Error('CSV do INPE sem latitude/longitude');
  return linhas.map((l) => { const c = l.split(','); return { lat: +c[iLat], lon: +c[iLon], quando: iData >= 0 ? c[iData] : '' }; });
}

// Junta o arquivo de HOJE e o de ONTEM (dia em UTC): o de hoje começa vazio às 21h de Brasília,
// então só ele diria "nenhum fogo" sem verdade. Os dois juntos = focos das últimas 24 a 48 horas.
async function inpeDireto(centro) {
  const arquivos = await Promise.all([0, 1].map(async (atras) => {
    const url = `https://dataserver-coids.inpe.br/queimadas/queimadas/focos/csv/diario/Brasil/focos_diario_br_${dataUTC(atras)}.csv`;
    try { const r = await fetch(url); return r.ok ? lerCsv(await r.text()) : null; } catch { return null; }
  }));
  if (!arquivos[1]) throw new Error('INPE sem o arquivo de ontem'); // sem as últimas 24 h, não dá para dizer que não tem fogo
  const focos = arquivos.flatMap((a) => a || [])
    .filter((f) => Number.isFinite(f.lat) && distanciaKm(centro, f) <= CONFIG.raioFogoKm + 15);
  return { focos, fonte: 'INPE Queimadas (últimas 24 a 48 h)' };
}

export const provedores = {
  async mock({ centro }) {
    // Um foco a ~4 km a nordeste e outro mais longe, só para a demo
    return {
      focos: [
        { lat: centro.lat + 0.026, lon: centro.lon + 0.026, quando: 'hoje cedo' },
        { lat: centro.lat - 0.15, lon: centro.lon - 0.12, quando: 'ontem' },
      ],
      fonte: 'Exemplo',
    };
  },

  // INPE Queimadas — CSV diário, sem chave. No Vercel passa por /api/fogo.
  // Sem o Vercel (Live Server), tenta baixar o CSV do Brasil direto do INPE e filtra AQUI
  // (assim nenhuma localização sai do aparelho).
  async inpe({ centro }) {
    const q = `lat=${arredondar(centro.lat)}&lon=${arredondar(centro.lon)}&raio=${CONFIG.raioFogoKm + 15}`;
    try {
      const r = await fetch(`${CONFIG.baseApi}/api/fogo?fonte=inpe&${q}`);
      if (r.ok && (r.headers.get('content-type') || '').includes('json')) return r.json();
    } catch { /* sem a função do Vercel: tenta direto */ }
    return inpeDireto(centro);
  },

  // NASA FIRMS — reserva. Precisa de chave grátis (CONFIG.firmsKey).
  async firms({ centro }) {
    const q = `lat=${arredondar(centro.lat)}&lon=${arredondar(centro.lon)}&raio=${CONFIG.raioFogoKm + 15}&key=${CONFIG.firmsKey}`;
    const r = await fetch(`${CONFIG.baseApi}/api/fogo?fonte=firms&${q}`);
    if (!r.ok) throw new Error('FIRMS fora do ar');
    return r.json();
  },
};
