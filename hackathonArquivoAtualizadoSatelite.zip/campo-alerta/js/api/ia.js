// IA DA FOLHA — todo provedor recebe uma <img> e devolve
// [{ id, prob }] em ordem (a maior primeiro), com prob de 0 a 1.
// 'api': manda a foto (reduzida) para o modelo de vocês no Render.
// 'teachable': o modelo roda no próprio celular (a foto não sai dele).
import { CONFIG } from '../config.js';

// Nomes que a API usa -> nomes do app (inclusive o erro de digitação "mantegosa")
const NOMES_API = { bicho_mineiro: 'bicho-mineiro', mancha_aureolada: 'mancha-aureolada', mancha_mantegosa: 'mancha-manteigosa', mancha_manteigosa: 'mancha-manteigosa' };

// Diminui a foto antes de enviar: 512 px bastam para o modelo e o envio fica bem mais rápido no 3G
function fotoReduzida(img, lado = 512) {
  const escala = Math.min(1, lado / Math.max(img.naturalWidth, img.naturalHeight));
  const c = document.createElement('canvas');
  c.width = Math.round(img.naturalWidth * escala);
  c.height = Math.round(img.naturalHeight * escala);
  c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
  return new Promise((ok) => c.toBlob(ok, 'image/jpeg', 0.85));
}

async function enviar(url, foto, ms) {
  const corpo = new FormData();
  corpo.append('file', foto, 'folha.jpg');
  const r = await fetch(url, { method: 'POST', body: corpo, signal: AbortSignal.timeout(ms) });
  if (!r.ok) throw new Error('A IA respondeu ' + r.status);
  return r.json();
}

// O servidor gratuito "dorme" quando ninguém usa. Este toque acorda ele antes da foto chegar.
let acordado = false;
export function acordarIA() {
  if (acordado || CONFIG.provedores.ia !== 'api') return;
  acordado = true;
  fetch(CONFIG.iaApi.url + '/', { mode: 'no-cors' }).catch(() => { acordado = false; });
}

function carregarScript(src) {
  return new Promise((ok, erro) => {
    if (document.querySelector(`script[src="${src}"]`)) return ok();
    const s = document.createElement('script');
    s.src = src; s.onload = ok; s.onerror = () => erro(new Error('Não carregou ' + src));
    document.head.appendChild(s);
  });
}

let modelo = null;

export const provedores = {
  async api({ imagem }) {
    const foto = await fotoReduzida(imagem);
    const { url, proxy, esperaMs } = CONFIG.iaApi;
    let r;
    try {
      r = await enviar(`${url}/predict`, foto, esperaMs);          // direto (precisa de CORS liberado na API)
    } catch (direto) {
      if (!proxy || direto.name === 'TimeoutError') throw direto;
      r = await enviar(`${CONFIG.baseApi}${proxy}`, foto, esperaMs); // pelo Vercel (sem problema de CORS)
    }
    return Object.entries(r.probabilidades || {})
      .map(([classe, pct]) => ({ id: NOMES_API[classe] || classe.replace(/_/g, '-'), prob: pct / 100 }))
      .sort((a, b) => b.prob - a.prob);
  },

  async mock() {
    await new Promise((r) => setTimeout(r, 1200)); // finge que está pensando
    return [
      { id: 'ferrugem', prob: 0.62 },
      { id: 'cercosporiose', prob: 0.24 },
      { id: 'bicho-mineiro', prob: 0.09 },
      { id: 'saudavel', prob: 0.05 },
    ];
  },

  // Teachable Machine (imagem). Exportem como "TensorFlow.js" e coloquem
  // model.json, metadata.json e weights.bin em /modelo (ou usem o link do upload).
  // Os nomes das classes precisam ser: ferrugem, cercosporiose, bicho-mineiro, saudavel
  async teachable({ imagem }) {
    if (!modelo) {
      await carregarScript('https://cdn.jsdelivr.net/npm/@tensorflow/tfjs@1.3.1/dist/tf.min.js');
      await carregarScript('https://cdn.jsdelivr.net/npm/@teachablemachine/image@0.8/dist/teachablemachine-image.min.js');
      const url = CONFIG.modeloIA.endsWith('/') ? CONFIG.modeloIA : CONFIG.modeloIA + '/';
      modelo = await window.tmImage.load(url + 'model.json', url + 'metadata.json');
    }
    const saida = await modelo.predict(imagem);
    return saida
      .map((c) => ({ id: c.className.trim().toLowerCase(), prob: c.probability }))
      .sort((a, b) => b.prob - a.prob);
  },
};
