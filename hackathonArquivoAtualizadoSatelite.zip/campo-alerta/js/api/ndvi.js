// NDVI DE CADA LAVOURA CADASTRADA — não usado desde 03/10.
// A lavoura não tem contorno no mapa, então o satélite não sabe onde ela fica: não mostramos nada
// (antes havia um 'mock' que inventava o verde). O satélite de verdade está na tela Satélite.
export const provedores = {
  async nenhum() {
    return { pontos: [], zonas: null, fonte: null, semContorno: true };
  },
};
