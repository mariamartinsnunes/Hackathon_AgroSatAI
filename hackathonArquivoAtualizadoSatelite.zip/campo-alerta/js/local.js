// LOCALIZAÇÃO ATUAL (GPS do aparelho) — usada pelo satélite.
// A posição exata fica SÓ no aparelho. Para fora vai só um quadrado arredondado
// (veja js/api/saude.js): o recorte da plantação é feito aqui no celular.

let ultima = null; // última posição boa, só na memória desta aba

const ERROS = {
  1: 'negado',        // a pessoa não deixou
  2: 'sem-sinal',     // o aparelho não achou a posição
  3: 'demorou',       // passou do tempo
};

// O navegador já deixou usar a localização? ('granted' | 'prompt' | 'denied' | 'desconhecido')
export async function permissaoLocal() {
  if (!('geolocation' in navigator) || !window.isSecureContext) return 'sem-gps';
  try {
    const p = await navigator.permissions.query({ name: 'geolocation' });
    return p.state;
  } catch {
    return 'desconhecido';
  }
}

// Pega a posição atual. pedir=false: só pega se a pessoa JÁ deixou antes (não abre a pergunta do navegador).
export async function pegarLocal({ pedir = true } = {}) {
  if (!('geolocation' in navigator) || !window.isSecureContext) throw new Error('sem-gps');
  if (!pedir && (await permissaoLocal()) !== 'granted') throw new Error('sem-permissao');
  if (ultima && Date.now() - ultima.quando < 5 * 60e3) return ultima;

  const pos = await new Promise((ok, erro) => {
    navigator.geolocation.getCurrentPosition(ok, (e) => erro(new Error(ERROS[e.code] || 'sem-sinal')), {
      enableHighAccuracy: true, timeout: 20000, maximumAge: 5 * 60e3,
    });
  });
  ultima = {
    lat: pos.coords.latitude,
    lon: pos.coords.longitude,
    precisaoM: Math.round(pos.coords.accuracy || 0),
    quando: Date.now(),
  };
  return ultima;
}

// Frase simples para cada problema
export function textoErroLocal(codigo) {
  return {
    'sem-gps': 'Este navegador não consegue pegar a localização. Abra o app no Chrome, pelo link seguro (https).',
    'sem-permissao': 'Toque no botão para usar a sua localização.',
    negado: 'A localização está bloqueada. Libere a localização para este site no navegador e toque em "Tentar de novo".',
    'sem-sinal': 'O celular não achou onde você está. Ligue a localização (GPS) e tente de novo.',
    demorou: 'A localização demorou demais. Vá para um lugar aberto e tente de novo.',
  }[codigo] || 'Não deu para pegar a sua localização agora. Tente de novo.';
}
