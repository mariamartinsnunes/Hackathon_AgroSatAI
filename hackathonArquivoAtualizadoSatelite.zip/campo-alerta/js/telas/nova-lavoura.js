import { icone } from '../icones.js';
import { DESENHOS } from '../desenhos.js';
import { CULTURAS } from '../crescimento.js';
import { paraISO, somarDias } from '../util.js';
import { horizonte } from './partes.js';

export default {
  titulo: 'Nova lavoura',

  render() {
    const hoje = new Date();
    const hojeISO = paraISO(hoje);
    const minimo = paraISO(somarDias(hoje, -1460));
    return `
    ${horizonte({ titulo: 'O que você plantou?', sub: 'A conta dos dias começa no plantio', voltar: 'lavouras' })}
    <div class="pagina pagina-estreita">

      <section class="passo">
        <h2 class="passo-titulo" data-ler="O que você plantou?">Cultura</h2>
        <div class="culturas" role="radiogroup" aria-label="Cultura">
          ${Object.values(CULTURAS).map((c, i) => `
            <button type="button" role="radio" class="cultura" data-cultura="${c.id}" aria-checked="${i === 0}">
              <span class="cultura-desenho">${DESENHOS[c.id]}</span>
              <span class="cultura-nome">${c.nome}</span>
            </button>`).join('')}
        </div>
        <p class="nota">Soja leva uns 4 meses até a colheita. Café leva uns 2 a 3 anos até a primeira.</p>
      </section>

      <section class="passo">
        <label class="passo-titulo" for="nome-area" data-ler="Qual é a área? Dê um nome.">Qual área?</label>
        <input id="nome-area" class="campo-texto" autocomplete="off" placeholder="Ex.: Talhão do fundo">
        <label class="passo-sub" for="hectares">Tamanho em hectares (se souber)</label>
        <input id="hectares" class="campo-texto" type="number" inputmode="decimal" min="0" step="0.1" placeholder="Ex.: 4,5">
      </section>

      <section class="passo">
        <label class="passo-titulo" for="plantio" data-ler="Que dia você plantou?">Dia do plantio</label>
        <input id="plantio" class="campo-texto" type="date" value="${hojeISO}" min="${minimo}" max="${hojeISO}">
        <p class="nota">Se plantou em outro dia, escolha o dia certo. A conta começa nele.</p>
      </section>

      <p class="nota">O nome da área fica só no seu celular.</p>
      <button type="button" class="botao botao-grande" data-salvar>${icone('ok', 32)} Salvar lavoura</button>
    </div>`;
  },

  montar(el, app) {
    let cultura = Object.keys(CULTURAS)[0];
    el.querySelectorAll('[data-cultura]').forEach((b) => b.addEventListener('click', () => {
      cultura = b.dataset.cultura;
      el.querySelectorAll('[data-cultura]').forEach((o) => o.setAttribute('aria-checked', String(o === b)));
    }));

    el.querySelector('[data-salvar]').addEventListener('click', () => {
      const hojeISO = paraISO(new Date());
      let plantio = el.querySelector('#plantio').value || hojeISO;
      if (plantio > hojeISO) plantio = hojeISO;
      const nova = {
        id: Date.now().toString(36),
        cultura,
        nome: el.querySelector('#nome-area').value.trim() || `${CULTURAS[cultura].nome} ${(app.perfil.lavouras || []).length + 1}`,
        ha: el.querySelector('#hectares').value.trim(),
        plantio,
        ajusteGdd: 0,
        ultimoCheckin: null,
      };
      app.salvar({ lavouras: [...(app.perfil.lavouras || []), nova] });
      app.ir(`lavoura?id=${nova.id}`);
    });
  },
};
