import { CONFIG } from '../config.js';
import { icone } from '../icones.js';
import { diagnosticar } from '../api/index.js';
import { acordarIA } from '../api/ia.js';
import { PROBLEMAS } from '../dados-cafe.js';
import { falar, textoDaTela } from '../voz.js';
import { horizonte } from './partes.js';

const pct = (p) => `${Math.round(p * 100)}%`;

function htmlResultado(hipoteses) {
  const top3 = hipoteses.slice(0, 3);
  const melhor = top3[0];
  const incerto = melhor.prob < 0.5;

  return `
    <h2 class="resultado-titulo" data-ler>${incerto ? 'Não deu para ter certeza. Pode ser:' : 'Pode ser:'}</h2>
    <ol class="hipoteses">
      ${top3.map((h, i) => {
        const pb = PROBLEMAS[h.id] || { nome: h.id, sinal: '' };
        return `<li class="hipotese ${i === 0 ? 'hipotese-primeira' : ''}" data-ler="${pb.nome}, ${pct(h.prob)}">
          <div class="hipotese-topo"><b>${pb.nome}</b><span>${pct(h.prob)}</span></div>
          <div class="barra-prob" aria-hidden="true"><span style="width:${pct(h.prob)}"></span></div>
          ${pb.sinal ? `<p>${pb.sinal}</p>` : ''}
        </li>`;
      }).join('')}
    </ol>
    <p class="aviso-ia" data-ler>A máquina pode errar. Quem dá a palavra final é o técnico.</p>

    <a class="botao botao-grande" href="tel:${CONFIG.tecnico.telefone}">${icone('telefone', 30)} Chamar técnico</a>

    <button type="button" class="botao-texto" data-outra>${icone('camera', 24)} Tirar outra foto</button>`;
}

export default {
  titulo: 'Foto da folha',

  render() {
    return `
    ${horizonte({ titulo: 'Foto da folha', sub: 'Fotografe a folha inteira, na luz do dia' })}
    <div class="pagina pagina-estreita">
      <label class="foto-alvo" data-alvo>
        <input type="file" accept="image/*" capture="environment" class="visualmente-oculto" data-arquivo>
        <span class="foto-alvo-icone">${icone('camera', 64)}</span>
        <span class="foto-alvo-texto" data-ler="Toque para tirar a foto da folha">Tirar foto</span>
      </label>
      <img class="foto-previa" alt="Foto da folha" data-previa hidden>
      <p class="pensando" role="status" data-pensando hidden>${icone('folha', 28)} Olhando a folha…</p>
      <section class="resultado" data-resultado aria-live="polite"></section>
    </div>`;
  },

  montar(el) {
    acordarIA(); // acorda o servidor da IA enquanto a pessoa ainda está tirando a foto
    const arquivo = el.querySelector('[data-arquivo]');
    const previa = el.querySelector('[data-previa]');
    const alvo = el.querySelector('[data-alvo]');
    const pensando = el.querySelector('[data-pensando]');
    const resultado = el.querySelector('[data-resultado]');

    arquivo.addEventListener('change', async () => {
      const f = arquivo.files?.[0];
      if (!f) return;
      previa.src = URL.createObjectURL(f);
      await previa.decode().catch(() => {});
      previa.hidden = false; alvo.hidden = true; pensando.hidden = false; resultado.innerHTML = '';
      const textoPensando = pensando.lastChild;
      textoPensando.textContent = ' Olhando a folha…';
      // Servidor gratuito acordando: avisa para a pessoa não achar que travou
      const demorando = setTimeout(() => { textoPensando.textContent = ' A IA está acordando. A primeira análise pode levar até 1 minuto…'; }, 5000);

      try {
        const hipoteses = await diagnosticar(previa);
        resultado.innerHTML = htmlResultado(hipoteses);
        falar(textoDaTela(resultado));
      } catch {
        resultado.innerHTML = `
          <p class="erro-linha" data-ler>Não consegui analisar a foto agora. Confira a internet e tente de novo, ou chame o técnico.</p>
          <a class="botao botao-grande" href="tel:${CONFIG.tecnico.telefone}">${icone('telefone', 30)} Chamar técnico</a>
          <button type="button" class="botao-texto" data-outra>${icone('camera', 24)} Tentar de novo</button>`;
      }
      clearTimeout(demorando);
      pensando.hidden = true;

      resultado.querySelector('[data-outra]')?.addEventListener('click', () => {
        arquivo.value = ''; previa.hidden = true; alvo.hidden = false; resultado.innerHTML = '';
        arquivo.click();
      });
    });
  },
};
