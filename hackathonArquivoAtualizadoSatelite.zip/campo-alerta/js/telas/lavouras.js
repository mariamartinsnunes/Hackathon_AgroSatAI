import { icone } from '../icones.js';
import { esc } from '../util.js';
import { desenharPlanta } from '../planta.js';
import { horizonte, etiquetaExemplo } from './partes.js';

const SATELITE = {
  ok: 'Satélite: no ritmo',
  atencao: 'Satélite: atenção',
  alerta: 'Satélite: alerta',
  'sem-dado': 'Satélite: sem dado',
  velho: 'Satélite: imagem antiga',
};

function cartao(a) {
  const { lavoura, sim, comp } = a;
  if (!sim) {
    return `
    <a class="cartao lavoura-cartao" href="#/lavoura?id=${esc(lavoura.id)}" data-ler="${esc(`${lavoura.nome}: sem o clima agora, não deu para calcular.`)}">
      <div class="lavoura-info">
        <h2 class="lavoura-nome">${esc(lavoura.nome)}</h2>
        <p class="lavoura-fase">Sem informação agora</p>
        <p class="lavoura-colheita">O clima desde o plantio não chegou. Confira a internet.</p>
      </div>
    </a>`;
  }
  const ha = lavoura.ha ? `, ${esc(String(lavoura.ha).replace('.', ','))} ha` : '';
  const leitura = `${lavoura.nome}, ${sim.def.nome}: ${sim.fase.nome}. ${sim.colheita.titulo}. ${comp.titulo}.`;
  return `
    <a class="cartao lavoura-cartao" href="#/lavoura?id=${esc(lavoura.id)}" data-ler="${esc(leitura)}">
      <div class="lavoura-mini">${desenharPlanta(sim)}</div>
      <div class="lavoura-info">
        <h2 class="lavoura-nome">${esc(lavoura.nome)}</h2>
        <p class="lavoura-sub">${sim.def.nome}${ha}. Dia ${sim.dias} desde o plantio</p>
        <p class="lavoura-fase">${sim.fase.nome}</p>
        <div class="barra-prob" aria-hidden="true"><span style="width:${Math.round(sim.progressoTotal * 100)}%"></span></div>
        <p class="lavoura-colheita">${esc(sim.colheita.titulo)}</p>
        <span class="chip" data-estado="${comp.estado}">${icone('satelite', 18)} ${SATELITE[comp.estado]}</span>
      </div>
    </a>`;
}

export default {
  titulo: 'Minhas lavouras',

  async render(app) {
    const todas = await app.lavouras(); // mesma conta do início: abre na hora
    const lista = app.perfil.lavouras || [];

    if (!lista.length) {
      return `
      ${horizonte({ titulo: 'Minhas lavouras', sub: 'Veja a planta crescendo' })}
      <div class="pagina pagina-estreita">
        <section class="lavoura-vazia">
          <div class="lavoura-vazia-desenho">${icone('planta', 72)}</div>
          <h2 data-ler>Plantou hoje? Cadastre aqui.</h2>
          <p data-ler>O Campo Alerta conta os dias, acompanha o clima e mostra a planta crescendo. Quando chegar a época de colher, ele avisa.</p>
        </section>
        <a class="botao botao-grande" href="#/nova-lavoura">${icone('mais', 30)} Cadastrar lavoura</a>
      </div>`;
    }

    return `
    ${horizonte({ titulo: 'Minhas lavouras', sub: `${lista.length} ${lista.length === 1 ? 'lavoura' : 'lavouras'}` })}
    <div class="pagina">
      <div class="lavoura-grade">${todas.map(cartao).join('')}</div>
      <a class="botao botao-contorno lavoura-nova" href="#/nova-lavoura">${icone('mais', 28)} Nova lavoura</a>
      ${etiquetaExemplo(todas.some((a) => a.exemplo), todas.find((a) => a.fontes)?.fontes)}
    </div>`;
  },
};
