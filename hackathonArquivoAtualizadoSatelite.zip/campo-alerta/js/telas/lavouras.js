import { icone } from '../icones.js';
import { esc } from '../util.js';
import { DESENHOS } from '../desenhos.js';
import { frasesClima } from '../lavouras.js';
import { horizonte, etiquetaExemplo } from './partes.js';

function cartao(a) {
  const { lavoura, clima } = a;
  const ha = lavoura.ha ? `, ${esc(String(lavoura.ha).replace('.', ','))} ha` : '';
  if (!clima) {
    return `
    <a class="cartao lavoura-cartao" href="#/lavoura?id=${esc(lavoura.id)}" data-ler="${esc(`${lavoura.nome}: sem o clima agora.`)}">
      <div class="lavoura-mini">${DESENHOS.cafe}</div>
      <div class="lavoura-info">
        <h2 class="lavoura-nome">${esc(lavoura.nome)}</h2>
        <p class="lavoura-fase">Sem informação agora</p>
        <p class="lavoura-colheita">O clima desde o plantio não chegou. Confira a internet.</p>
      </div>
    </a>`;
  }
  const f = frasesClima(clima);
  return `
    <a class="cartao lavoura-cartao" href="#/lavoura?id=${esc(lavoura.id)}" data-ler="${esc(`${lavoura.nome}. ${f.dias}. ${f.chuva}. ${f.seca}.`)}">
      <div class="lavoura-mini">${DESENHOS.cafe}</div>
      <div class="lavoura-info">
        <h2 class="lavoura-nome">${esc(lavoura.nome)}</h2>
        <p class="lavoura-sub">Café${ha}. ${f.dias}</p>
        <p class="lavoura-fase">${esc(f.chuva)}</p>
        <p class="lavoura-colheita">${esc(f.seca)}</p>
      </div>
    </a>`;
}

export default {
  titulo: 'Minhas lavouras',

  async render(app) {
    const todas = await app.lavouras(); // mesma conta do início: abre na hora
    const lista = app.perfil.lavouras || [];

    if (!lista.length) {
      return `
      ${horizonte({ titulo: 'Minhas lavouras', sub: 'Dias e chuva desde o plantio' })}
      <div class="pagina pagina-estreita">
        <section class="lavoura-vazia">
          <div class="lavoura-vazia-desenho">${icone('planta', 72)}</div>
          <h2 data-ler>Plantou hoje? Cadastre aqui.</h2>
          <p data-ler>O Agrotech conta os dias e mostra quanto choveu na sua lavoura desde o plantio.</p>
        </section>
        <a class="botao botao-grande" href="#/nova-lavoura">${icone('mais', 30)} Cadastrar lavoura</a>
      </div>`;
    }

    return `
    ${horizonte({ titulo: 'Minhas lavouras', sub: `${lista.length} ${lista.length === 1 ? 'lavoura' : 'lavouras'}` })}
    <div class="pagina">
      <div class="lavoura-grade">${todas.map(cartao).join('')}</div>
      <a class="botao botao-contorno lavoura-nova" href="#/nova-lavoura">${icone('mais', 28)} Nova lavoura</a>
      ${etiquetaExemplo(todas.some((a) => a.exemplo), todas.find((a) => a.fontes)?.fontes)}
    </div>`;
  },
};
