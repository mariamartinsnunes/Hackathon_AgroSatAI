import { CONFIG } from '../config.js';
import { icone } from '../icones.js';
import { esc, parametros, deISO, dataLonga, paraISO, somarDias } from '../util.js';
import { MATURACAO } from '../crescimento.js';
import { analisarLavoura, frasesClima } from '../lavouras.js';
import { contexto } from '../regras.js';
import { horizonte } from './partes.js';

const dataBR = (d) => d.toLocaleDateString('pt-BR');
const milhar = (n) => n.toLocaleString('pt-BR');

// Colheita: estimativa do IAC a partir da florada (só com dado medido). Sem florada: pergunta.
function cartaoColheita(lavoura, a) {
  const m = a?.maturacao;
  const fonte = `<p class="fonte">Estimativa do IAC: soma do calor desde a florada (temperatura base 10,2 °C). Fonte: ${MATURACAO.fonte}. Clima: Open-Meteo. Quem confirma é o técnico.</p>`;
  if (lavoura.florada && m) {
    const linhas = m.alvos.map((c) => {
      const quando = c.pronto ? 'Já juntou o calor da maturação: confira os frutos.'
        : c.data ? `Se o calor seguir como no último mês: perto de ${dataBR(c.data)}.` : 'Ainda sem dados para estimar a data.';
      return `<li data-ler="${esc(`${c.nome}: ${c.pct} por cento. ${quando}`)}"><b>${esc(c.nome)}</b>: ${c.pct}% do calor (${milhar(m.soma)} de ${milhar(c.gd)} graus-dia). ${quando}
        <div class="barra-prob" aria-hidden="true"><span style="width:${c.pct}%"></span></div></li>`;
    }).join('');
    return `<section class="cartao">
      <h2 class="cartao-titulo">${icone('calendario', 26)} Colheita (estimativa)</h2>
      <p class="cartao-frase">Florada em ${dataBR(deISO(lavoura.florada))}, há ${m.desde} dias${MATURACAO.cultivares[lavoura.variedade] ? '' : '. Variedade não informada: mostramos as três'}.</p>
      <ul class="lavoura-fatos">${linhas}</ul>
      ${m.faltamDiasDeDado > 3 ? `<p class="nota nota-alerta">Faltam ${m.faltamDiasDeDado} dias de clima medido: a conta pode estar baixa.</p>` : ''}
      ${fonte}
      <button type="button" class="botao-texto" data-mudar-florada>Mudar florada ou variedade</button>
    </section>`;
  }
  const hoje = new Date();
  return `<section class="cartao" data-form-florada>
    <h2 class="cartao-titulo">${icone('calendario', 26)} Colheita (estimativa)</h2>
    <p class="cartao-frase" data-ler>Já teve florada? Diga quando foi e a variedade, e o app estima a época da colheita.</p>
    <label class="passo-sub" for="florada">Dia da florada principal</label>
    <input id="florada" class="campo-texto" type="date" value="${lavoura.florada || ''}" min="${paraISO(somarDias(hoje, -400))}" max="${paraISO(hoje)}">
    <label class="passo-sub" for="variedade">Variedade</label>
    <select id="variedade" class="campo-texto">
      ${Object.entries(MATURACAO.cultivares).map(([id, c]) => `<option value="${id}" ${lavoura.variedade === id ? 'selected' : ''}>${c.nome}</option>`).join('')}
      <option value="" ${lavoura.variedade ? '' : 'selected'}>Não sei</option>
    </select>
    <button type="button" class="botao" data-salvar-florada>${icone('ok', 26)} Calcular</button>
    <p class="nota">Lavoura nova, que ainda não deu florada, não tem estimativa.</p>
    ${fonte}
  </section>`;
}

export default {
  titulo: 'Lavoura',

  async render(app) {
    const lavoura = (app.perfil.lavouras || []).find((l) => l.id === parametros().get('id'));
    if (!lavoura) {
      return `<section class="erro"><h1>Lavoura não encontrada</h1><a class="botao" href="#/lavouras">Ver minhas lavouras</a></section>`;
    }
    this._lavoura = lavoura;
    const sub = `Café, plantado em ${dataLonga(deISO(lavoura.plantio))}`;

    let a;
    try {
      a = await analisarLavoura(lavoura, contexto(app.perfil));
    } catch {
      a = null; // sem o clima desde o plantio: não mostra conta nenhuma
    }
    const f = a ? frasesClima(a.clima) : null;
    const seca = a && a.clima.semChuva >= 10;

    const dias = Math.max(Math.round((Date.now() - deISO(lavoura.plantio)) / 864e5), 0);
    const linhas = f ? [
      ['chuva', f.chuva],
      ['gota', f.seca],
      ...(f.calor ? [['calor', f.calor]] : []),
    ] : [];

    return `
    ${horizonte({ titulo: esc(lavoura.nome), sub: esc(sub), voltar: 'lavouras', ceu: seca ? 'fogo' : 'sol' })}
    <div class="pagina pagina-estreita">
      <section class="cartao" data-ler="${esc(`Dia ${dias} desde o plantio.${f ? ' ' + linhas.map((l) => l[1]).join('. ') + '.' : ''}`)}">
        <p class="lavoura-fase-grande">Dia ${dias}</p>
        <p class="cartao-frase" style="text-align:center">desde o plantio${lavoura.ha ? `, ${esc(String(lavoura.ha).replace('.', ','))} ha` : ''}</p>
        ${f ? `<ul class="lavoura-fatos">${linhas.map(([ic, t]) => `<li>${icone(ic, 24)} ${esc(t)}</li>`).join('')}</ul>`
          : '<p class="cartao-frase">O clima não chegou agora. Confira a internet.</p>'}
        ${seca ? `<p class="nota nota-alerta">${icone('gota', 20)} Muitos dias sem chuva: mudas novas sofrem. Fale com o técnico.</p>` : ''}
        <p class="fonte">Fonte: clima medido (Open-Meteo), perto do seu município.</p>
      </section>

      ${cartaoColheita(lavoura, a)}
      <a class="botao" href="#/foto">${icone('camera', 28)} Tirar foto da folha</a>
      <a class="botao botao-contorno" href="tel:${CONFIG.tecnico.telefone}">${icone('telefone', 26)} Chamar técnico</a>
      <button type="button" class="botao-texto" data-apagar>Apagar esta lavoura</button>
    </div>`;
  },

  montar(el, app) {
    const lavoura = this._lavoura;
    const salvarLavoura = (mudancas) => {
      app.salvar({ lavouras: app.perfil.lavouras.map((l) => (l.id === lavoura.id ? { ...l, ...mudancas } : l)) });
      window.dispatchEvent(new HashChangeEvent('hashchange'));
    };
    el.querySelector('[data-salvar-florada]')?.addEventListener('click', () => {
      const florada = el.querySelector('#florada').value;
      if (!florada || florada > paraISO(new Date())) { el.querySelector('#florada').focus(); return; }
      salvarLavoura({ florada, variedade: el.querySelector('#variedade').value || null });
    });
    el.querySelector('[data-mudar-florada]')?.addEventListener('click', () => salvarLavoura({ florada: null }));

    const apagar = el.querySelector('[data-apagar]');
    if (!apagar) return;
    // Apagar pede um segundo toque (sem janela de confirmação, que trava a tela)
    apagar.addEventListener('click', () => {
      if (!apagar.dataset.certeza) {
        apagar.dataset.certeza = '1';
        apagar.textContent = 'Toque de novo para apagar (não tem volta)';
        return;
      }
      app.salvar({ lavouras: app.perfil.lavouras.filter((l) => l.id !== lavoura.id) });
      app.ir('lavouras');
    });
  },
};
