import { icone } from '../icones.js';
import { esc, parametros, deISO, dataLonga, paraISO } from '../util.js';
import { analisarLavoura } from '../lavouras.js';
import { ndviEsperado, ajusteParaCheckin } from '../crescimento.js';
import { desenharPlanta } from '../planta.js';
import { contexto } from '../regras.js';
import { horizonte, etiquetaExemplo } from './partes.js';

const virgula = (n) => String(n).replace('.', ',');

function grafico(a) {
  const { sim, comp } = a;
  const L = 320, A = 150, esq = 30, base = 22, topo = 8;
  const total = Math.max(sim.serie.length - 1, 10);
  const x = (i) => esq + (i / total) * (L - esq - 8);
  const y = (v) => topo + (1 - v) * (A - topo - base);
  const passo = Math.max(Math.floor(sim.serie.length / 40), 1);
  const indice = new Map(sim.serie.map((s, i) => [s.data, i]));

  const pontos = [];
  sim.serie.forEach((s, i) => {
    if (i % passo === 0 || i === sim.serie.length - 1) pontos.push(`${x(i).toFixed(1)},${y(ndviEsperado(sim.cultura, s.gdd)).toFixed(1)}`);
  });
  const medidos = comp.pontos.filter((p) => indice.has(p.data));

  return `
  <svg class="grafico" viewBox="0 0 ${L} ${A}" role="img" aria-label="Gráfico do verde da lavoura: linha tracejada é o esperado, bolinhas são o que o satélite viu">
    ${[0, 0.5, 1].map((v) => `<line class="g-eixo" x1="${esq}" x2="${L - 8}" y1="${y(v)}" y2="${y(v)}"/><text class="g-txt" x="${esq - 6}" y="${y(v) + 4}" text-anchor="end">${virgula(v)}</text>`).join('')}
    <polyline class="g-esp" points="${pontos.join(' ')}"/>
    ${medidos.map((p, i) => `<circle class="${i === medidos.length - 1 ? 'g-obs g-obs-ult' : 'g-obs'}" cx="${x(indice.get(p.data)).toFixed(1)}" cy="${y(p.ndvi).toFixed(1)}" r="${i === medidos.length - 1 ? 6 : 4}"/>`).join('')}
    <text class="g-txt" x="${esq}" y="${A - 4}">plantio</text>
    <text class="g-txt" x="${L - 8}" y="${A - 4}" text-anchor="end">hoje</text>
  </svg>`;
}

function zonas(a) {
  const zs = a.sat.zonas;
  if (!zs?.length) return '';
  const esp = a.comp.esp ?? a.comp.obs;
  const cor = (v) => (v - esp >= -0.04 ? 'verde' : v - esp >= -0.12 ? 'amarelo' : 'vermelho');
  return `
    <h3 class="sub-titulo">Mapa da lavoura</h3>
    <div class="zonas" role="img" aria-label="Mapa em 9 zonas. Verde saudável, amarelo atenção, vermelho crítico">
      ${zs.map((z) => `<div class="zona ${a.comp.zonaFraca === z.id ? 'zona-pior' : ''}" data-cor="${cor(z.ndvi)}">${z.id}</div>`).join('')}
    </div>
    <p class="nota">Verde: saudável. Amarelo: atenção. Vermelho: crítico.</p>`;
}

export default {
  titulo: 'Lavoura',

  async render(app) {
    const lavoura = (app.perfil.lavouras || []).find((l) => l.id === parametros().get('id'));
    if (!lavoura) {
      return `<section class="erro"><h1>Lavoura não encontrada</h1><a class="botao" href="#/lavouras">Ver minhas lavouras</a></section>`;
    }

    let a;
    try {
      a = await analisarLavoura(lavoura, contexto(app.perfil));
    } catch {
      this._a = null; // sem o clima desde o plantio: não calcula nada (nada de conta inventada)
      return `
      ${horizonte({ titulo: esc(lavoura.nome), sub: 'Sem informação agora', voltar: 'lavouras' })}
      <div class="pagina pagina-estreita">
        <p class="erro-linha" data-ler>O clima desde o plantio não chegou, então não deu para calcular esta lavoura. Confira a internet e abra de novo.</p>
        <a class="botao" href="#/lavouras">Voltar</a>
      </div>`;
    }
    this._a = a;
    const { sim, comp } = a;
    const fases = sim.def.fases;
    const ceu = comp.estado === 'alerta' ? 'fogo' : 'sol';
    const sub = `${sim.def.nome}, plantada em ${dataLonga(deISO(lavoura.plantio))}`;

    const prox = sim.faseIndex < fases.length - 1 ? fases[sim.faseIndex + 1] : null;
    const ante = sim.faseIndex > 0 ? fases[sim.faseIndex - 1] : null;

    return `
    ${horizonte({ titulo: esc(lavoura.nome), sub: esc(sub), voltar: 'lavouras', ceu })}
    <div class="pagina">
      <div class="lavoura-detalhe">

        <section class="cartao" data-ler="${esc(`${lavoura.nome}. Dia ${sim.dias}. ${sim.fase.nome}.`)}">
          <h2 class="cartao-titulo">${icone('planta', 26)} Como está a planta</h2>
          <div class="planta-caixa">${desenharPlanta(sim)}</div>
          <p class="lavoura-fase-grande">${sim.fase.nome}</p>
          <p class="cartao-frase">Dia ${sim.dias} desde o plantio</p>
          <div class="barra-prob grossa" role="img" aria-label="${Math.round(sim.progressoTotal * 100)} por cento do caminho até a colheita"><span style="width:${Math.round(sim.progressoTotal * 100)}%"></span></div>
          <ol class="fases">
            ${fases.map((f, i) => `<li class="fase ${i < sim.faseIndex ? 'fase-feita' : ''} ${i === sim.faseIndex ? 'fase-atual' : ''}" ${i === sim.faseIndex ? 'aria-current="step"' : ''}>${f.nome}</li>`).join('')}
          </ol>
        </section>

        <div class="lavoura-coluna">
          <section class="cartao cartao-colheita" data-estado="${sim.colheita.estado}" data-ler="${esc(`${sim.colheita.titulo}. ${sim.colheita.detalhe}`)}">
            <h2 class="cartao-titulo">${icone('calendario', 26)} Colheita</h2>
            <p class="destaque">${esc(sim.colheita.titulo)}</p>
            <p class="cartao-frase">${esc(sim.colheita.detalhe)}</p>
          </section>

          <section class="cartao cartao-satelite" data-estado="${comp.estado}" data-ler="${esc(`${comp.titulo}. ${comp.detalhe}`)}">
            <h2 class="cartao-titulo">${icone('satelite', 26)} Visto do satélite</h2>
            <p class="destaque">${esc(comp.titulo)}</p>
            <p class="cartao-frase">${esc(comp.detalhe)}</p>
            ${comp.pontos.length ? grafico(a) : ''}
            ${comp.pontos.length ? `<p class="nota">Linha tracejada: o esperado. Bolinhas: o que o satélite viu (a cada 5 dias, quando não tem nuvem).</p>` : ''}
            ${zonas(a)}
            ${comp.estado === 'atencao' || comp.estado === 'alerta' ? `<a class="botao botao-contorno" href="#/foto">${icone('camera', 28)} Tirar foto da folha</a>` : ''}
          </section>

          <section class="cartao">
            <h2 class="cartao-titulo">${icone('ok', 26)} Confere com a sua lavoura?</h2>
            <p class="cartao-frase" data-ler="${esc(`A simulação diz: ${sim.fase.nome}. Confere com a sua lavoura?`)}">A simulação diz: ${sim.fase.nome}.</p>
            <div class="checkin">
              <button type="button" class="botao botao-contorno" data-checkin="confere">Confere</button>
              ${ante ? `<button type="button" class="botao botao-contorno" data-checkin="antes">Ainda está em: ${ante.nome}</button>` : ''}
              ${prox ? `<button type="button" class="botao botao-contorno" data-checkin="depois">Já está em: ${prox.nome}</button>` : ''}
            </div>
            <p class="nota">${lavoura.ultimoCheckin ? `Última conferida: ${dataLonga(deISO(lavoura.ultimoCheckin))}. ` : ''}Sua resposta corrige a simulação.</p>
          </section>
        </div>
      </div>

      <p class="aviso-ia" data-ler>É uma estimativa feita com o clima e o satélite. Quem dá a palavra final é o técnico.</p>
      <button type="button" class="botao-texto" data-apagar>Apagar esta lavoura</button>
      ${etiquetaExemplo(a.exemplo, a.fontes)}
    </div>`;
  },

  montar(el, app) {
    if (!this._a) return;
    const { lavoura, sim } = this._a;

    el.querySelectorAll('[data-checkin]').forEach((b) => b.addEventListener('click', () => {
      const ajuste = ajusteParaCheckin(sim, b.dataset.checkin);
      const lavouras = app.perfil.lavouras.map((l) => (l.id === lavoura.id
        ? { ...l, ajusteGdd: ajuste ?? l.ajusteGdd ?? 0, ultimoCheckin: paraISO(new Date()) }
        : l));
      app.salvar({ lavouras });
      window.dispatchEvent(new HashChangeEvent('hashchange'));
    }));

    // Apagar pede um segundo toque (sem janela de confirmação, que trava a tela)
    const apagar = el.querySelector('[data-apagar]');
    apagar.addEventListener('click', () => {
      if (!apagar.dataset.certeza) {
        apagar.dataset.certeza = '1';
        apagar.textContent = 'Toque de novo para apagar (não tem volta)';
        return;
      }
      app.salvar({ lavouras: app.perfil.lavouras.filter((l) => l.id !== lavoura.id) });
      app.ir('lavouras');
    });
  },
};
