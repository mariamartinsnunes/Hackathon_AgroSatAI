import { icone } from '../icones.js';
import { esc } from '../util.js';
import { gerarAvisos } from '../regras.js';
import { horizonte, fontesDados } from './partes.js';

export default {
  titulo: 'Avisos',

  async render(app) {
    const d = await app.dados();
    const [principal, ...outros] = gerarAvisos(app.perfil, d);
    if (!principal) return `${horizonte({ titulo: 'Avisos', sub: 'O mais importante aparece primeiro' })}<div class="pagina"><p class="nota">Nenhum aviso agora.</p></div>`;

    return `
    ${horizonte({ titulo: 'Avisos', sub: 'O mais importante aparece primeiro' })}
    <div class="pagina">
      <div class="avisos-grade">
        <article class="aviso-dia" data-cor="${principal.cor}">
          <span class="aviso-dia-icone">${icone(principal.icone, 56)}</span>
          <h2 data-ler>${esc(principal.titulo)}</h2>
          <p data-ler>${esc(principal.detalhe)}</p>
          ${d.plantio?.motivo === 'elnino' && principal.icone === 'calendario' ? '<span class="selo">Por causa do El Niño</span>' : ''}
          <button type="button" class="botao botao-ouvir-grande" data-acao="ouvir">${icone('som', 30)} Ouvir</button>
        </article>

        <ul class="avisos-lista">
          ${outros.map((a) => `
            <li class="aviso" data-cor="${a.cor}">
              <span class="aviso-icone">${icone(a.icone, 34)}</span>
              <div>
                <h3 data-ler>${esc(a.titulo)}</h3>
                <p data-ler>${esc(a.detalhe)}</p>
              </div>
              ${a.icone === 'fogo' ? '<a class="aviso-193" href="tel:193" aria-label="Ligar para os bombeiros, 193">193</a>' : ''}
            </li>`).join('')}
        </ul>
      </div>
      ${fontesDados([['Tempo', d.clima], ['Plantio', d.plantioBruto], ['Fogo', d.fogoBruto]])}
    </div>`;
  },
};
