import { icone } from '../icones.js';
import { ouvir, falar, entender, podeOuvir } from '../voz.js';
import { gerarAvisos } from '../regras.js';
import { esc } from '../util.js';
import { frasesClima } from '../lavouras.js';

// Respostas faladas para cada intenção
async function responder(intencao, app) {
  const d = await app.dados();
  const h = d.clima?.hoje;
  const chuva = d.clima?.dias.find((x) => x.chuvaMm >= 5);
  switch (intencao) {
    case 'tempo':
      if (!h) return { texto: 'A previsão do tempo não chegou agora. Confira a internet e pergunte de novo.' };
      return { texto: `Hoje o dia é ${h.frase.toLowerCase()}, com máxima de ${h.max} graus. ${chuva ? `A chuva deve chegar ${['sábado', 'domingo'].includes(chuva.nome) ? 'no' : 'na'} ${chuva.nome}.` : 'Nos próximos dias, nada de chuva forte.'}` };
    case 'plantio':
      return { texto: d.plantio ? d.plantio.fala : 'Não consegui o dado do plantio agora.' };
    case 'fogo':
      if (d.semFogo) return { texto: 'Não consegui ver o fogo agora: o satélite do INPE não respondeu. Se vir fumaça, ligue 193.' };
      return { texto: d.fogo ? `Atenção: o satélite viu fogo a ${d.fogo.kmTexto}, para os lados do ${d.fogo.direcao}. Se ele chegar perto, ligue 193.` : 'Pode ficar tranquilo: não tem fogo perto da sua plantação.' };
    case 'avisos': {
      const a = gerarAvisos(app.perfil, d)[0];
      return { texto: `${a.titulo}. ${a.detalhe}`, ir: 'avisos' };
    }
    case 'saude': {
      const s = await app.saude().catch(() => null);
      return s?.resumo
        ? { texto: `O satélite olhou em volta de você. ${s.resumo.titulo}. ${s.resumo.detalhe}`, ir: 'saude' }
        : { texto: 'Vou abrir o satélite. Deixe o app usar a sua localização.', ir: 'saude' };
    }
    case 'lavouras': {
      const [a] = await app.lavouras().catch(() => []);
      if (!a) return { texto: 'Você ainda não cadastrou o que plantou. Vamos cadastrar agora.', ir: 'nova-lavoura' };
      if (!a.clima) return { texto: `${a.lavoura.nome}: o clima não chegou agora.`, ir: 'lavouras' };
      const f = frasesClima(a.clima);
      return { texto: `${a.lavoura.nome}: ${f.dias}. ${f.chuva}. ${f.seca}.`, ir: `lavoura?id=${a.lavoura.id}` };
    }
    case 'foto': return { texto: 'Vamos ver essa folha. Tire uma foto dela.', ir: 'foto' };
    case 'radio': return { texto: 'Vou abrir o boletim da rádio.', ir: 'radio' };
    case 'inicio': return { texto: 'Voltando para o início.', ir: 'painel' };
    default:
      return { texto: 'Desculpe, não entendi. Você pode perguntar: vai chover? Posso plantar? Tem fogo perto?' };
  }
}

const EXEMPLOS = [
  { frase: 'Vai chover?', icone: 'chuva' },
  { frase: 'Posso plantar?', icone: 'calendario' },
  { frase: 'Tem fogo perto?', icone: 'fogo' },
  { frase: 'Minha folha tá doente', icone: 'folha' },
];

export default {
  titulo: 'Falar',

  render() {
    return `
    <section class="voz">
      <a class="voz-fechar" href="#/painel">${icone('x', 26)} Fechar</a>
      <h1 class="voz-titulo" data-estado>Toque e pergunte</h1>
      <button type="button" class="voz-mic" data-mic aria-label="Tocar para falar">
        <span class="voz-onda"></span><span class="voz-onda"></span>
        <span class="voz-mic-centro">${icone('mic', 72)}</span>
      </button>
      <p class="voz-ouvido" data-ouvido aria-live="polite"></p>
      <div class="voz-resposta" data-resposta hidden></div>
      <div class="voz-exemplos">
        ${EXEMPLOS.map((e) => `<button type="button" class="voz-exemplo" data-frase="${e.frase}">${icone(e.icone, 26)}<span>${e.frase}</span></button>`).join('')}
      </div>
    </section>`;
  },

  montar(el, app) {
    const estado = el.querySelector('[data-estado]');
    const ouvido = el.querySelector('[data-ouvido]');
    const caixa = el.querySelector('[data-resposta]');

    async function tratar(frases) {
      ouvido.textContent = `“${frases[0]}”`;
      const { ir } = entender(frases);
      const r = await responder(ir, app);
      caixa.hidden = false;
      caixa.innerHTML = `<p>${esc(r.texto)}</p>`;
      estado.textContent = 'Toque e pergunte';
      await falar(r.texto);
      if (r.ir) app.ir(r.ir);
    }

    el.querySelector('[data-mic]').addEventListener('click', async () => {
      if (!podeOuvir()) {
        estado.textContent = 'Toque numa pergunta';
        return falar('Este navegador não consegue ouvir. Toque numa das perguntas.');
      }
      estado.textContent = 'Ouvindo…';
      try { await tratar(await ouvir()); }
      catch (e) {
        estado.textContent = 'Toque e fale';
        if (e.message === 'not-allowed') falar('Libere o microfone para eu ouvir.');
        else falar('Não ouvi. Toque e fale de novo.');
      }
    });

    // Os exemplos funcionam como se a pessoa tivesse falado (ótimo para a demo)
    el.querySelectorAll('[data-frase]').forEach((b) =>
      b.addEventListener('click', () => tratar([b.dataset.frase.toLowerCase()])));
  },
};
