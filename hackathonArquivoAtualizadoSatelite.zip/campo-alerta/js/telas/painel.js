import { CONFIG } from '../config.js';
import { icone } from '../icones.js';
import { DESENHOS } from '../desenhos.js';
import { frasesClima } from '../lavouras.js';
import { saudacao, esc } from '../util.js';
import { horizonte, fontesDados } from './partes.js';
import { LARGURA, ALTURA, desenharFoto, desenharPassagem } from '../satelite.js';

// Mapa simples: a plantação no meio, o fogo no rumo e distância certos
export function miniMapa(fogo) {
  const R = 84; // raio do desenho = CONFIG.raioFogoKm
  let ponto = '';
  if (fogo) {
    const r = Math.min(fogo.km / CONFIG.raioFogoKm, 1) * R;
    const a = (fogo.graus * Math.PI) / 180;
    const x = 100 + r * Math.sin(a), y = 100 - r * Math.cos(a);
    ponto = `<line x1="100" y1="100" x2="${x.toFixed(1)}" y2="${y.toFixed(1)}" class="mapa-linha"/>
      <circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="13" class="mapa-fogo-halo"/>
      <circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="7" class="mapa-fogo"/>`;
  }
  return `<svg class="mini-mapa" viewBox="0 0 200 200" role="img" aria-label="${fogo ? `Fogo a ${fogo.kmTexto} para o ${fogo.direcao}` : 'Nenhum fogo perto'}">
    <circle cx="100" cy="100" r="${R}" class="mapa-anel"/>
    <circle cx="100" cy="100" r="${R / 2}" class="mapa-anel"/>
    <text x="100" y="12" class="mapa-n">N</text>
    <text x="${100 + R / 2 + 4}" y="96" class="mapa-km">${CONFIG.raioFogoKm / 2} km</text>
    ${ponto}
    <path d="M90 104 L100 94 L110 104 V112 H90Z" class="mapa-casa"/>
  </svg>`;
}

// Cartão do satélite real: aparece na hora com "olhando..." e se completa quando o satélite responder
function cartaoSaude(r) {
  if (!r) {
    return `<a href="#/saude" class="cartao cartao-saude" data-cartao-saude>
      <h2 class="cartao-titulo">${icone('satelite', 26)} Satélite</h2>
      <div class="saude-linha">
        <div class="saude-mini saude-mini-vazia" aria-hidden="true"></div>
        <p class="saude-titulo">Olhando sua lavoura pelo satélite…</p>
      </div>
    </a>`;
  }
  return `<a href="#/saude" class="cartao cartao-saude ${r.alerta || r.atencao ? 'tem-alerta' : ''}" data-cartao-saude data-ler="Em volta de você, visto do satélite: ${esc(r.titulo)}.">
    <h2 class="cartao-titulo">${icone('satelite', 26)} Satélite</h2>
    <div class="saude-linha">
      <canvas class="saude-mini" width="${LARGURA}" height="${ALTURA}" data-mini aria-hidden="true"></canvas>
      <div>
        <p class="saude-titulo">${esc(r.titulo)}</p>
        <p class="ver-satelite">${icone('satelite', 22)} Ver no satélite</p>
      </div>
    </div>
  </a>`;
}

// Cartão "Minha lavoura": a planta desenhada na fase em que está (cadastrada pelo produtor)
function cartaoPlanta(lista) {
  if (!lista) {
    return `<a href="#/lavouras" class="cartao cartao-lavoura" data-cartao-planta>
      <h2 class="cartao-titulo">${icone('planta', 26)} Minha lavoura</h2>
      <p class="saude-titulo">Contando os dias da sua lavoura…</p>
    </a>`;
  }
  const a = lista[0];
  if (!a) {
    return `<a href="#/nova-lavoura" class="cartao cartao-lavoura" data-cartao-planta data-ler="Cadastre o que você plantou e acompanhe os dias e a chuva.">
      <h2 class="cartao-titulo">${icone('planta', 26)} Minha lavoura</h2>
      <p class="fogo-titulo">Plantou?</p>
      <p class="cartao-frase">Cadastre e acompanhe os dias e a chuva</p>
    </a>`;
  }
  const mais = lista.length > 1 ? ` e mais ${lista.length - 1}` : '';
  if (!a.clima) {
    return `<a href="#/lavouras" class="cartao cartao-lavoura" data-cartao-planta>
      <h2 class="cartao-titulo">${icone('planta', 26)} ${esc(a.lavoura.nome)}${mais}</h2>
      <p class="saude-titulo">Sem o clima agora</p>
    </a>`;
  }
  const f = frasesClima(a.clima);
  return `<a href="#/lavoura?id=${esc(a.lavoura.id)}" class="cartao cartao-lavoura cartao-lavoura-cheio" data-cartao-planta
      data-ler="${esc(`${a.lavoura.nome}: ${f.dias}. ${f.chuva}. ${f.seca}.`)}">
    <div class="lavoura-mini">${DESENHOS.cafe}</div>
    <div>
      <h2 class="cartao-titulo">${icone('planta', 26)} ${esc(a.lavoura.nome)}${mais}</h2>
      <p class="fogo-titulo">${esc(f.dias)}</p>
      <p class="cartao-frase">${esc(f.chuva)}. ${esc(f.seca)}.</p>
    </div>
  </a>`;
}

function semaforo(cor) {
  return `<div class="semaforo" data-cor="${cor}" aria-hidden="true">
    <span class="luz luz-vermelho"></span><span class="luz luz-amarelo"></span><span class="luz luz-verde"></span>
  </div>`;
}

// Cartão do tempo. Sem previsão: diz que não tem (nunca mostra número inventado)
function cartaoHoje(d) {
  const h = d.clima?.hoje;
  if (!h) {
    return `<a href="#/avisos" class="cartao cartao-hoje" data-ler="Tempo: sem informação agora.">
      <h2 class="cartao-titulo">${icone('sol', 26)} Hoje</h2>
      <p class="fogo-titulo">Sem informação do tempo</p>
      <p class="cartao-frase">A previsão não chegou. Confira a internet.</p>
    </a>`;
  }
  return `<a href="#/avisos" class="cartao cartao-hoje" data-ler="Hoje: ${esc(h.frase)}, ${h.max} graus.${h.umidade < 30 ? ' Ar muito seco.' : ''}">
    <h2 class="cartao-titulo">${icone('sol', 26)} Hoje</h2>
    <div class="hoje-grande">
      ${icone(h.ceu, 64, 'hoje-icone')}
      <span class="hoje-temp">${h.max}°</span>
    </div>
    <p class="cartao-frase">${esc(h.frase)}${h.agora != null ? `, agora ${h.agora}°` : ''}</p>
    ${h.umidade != null ? `
    <ul class="hoje-extra">
      <li class="${h.umidade < 30 ? 'seco' : ''}">${icone('gota', 22)} Umidade ${h.umidade}%</li>
      <li>${icone('vento', 22)} Vento ${h.ventoKmh} km/h</li>
    </ul>` : ''}
    <ul class="dias" aria-label="Próximos dias">
      ${d.clima.dias.slice(0, 4).map((x) => `
        <li><span>${x.nome.slice(0, 3)}</span>${icone(x.ceu, 26)}<b>${x.max}°</b></li>`).join('')}
    </ul>
  </a>`;
}

// Cartão do plantio (ZARC do MAPA)
function cartaoPlantio(d) {
  if (!d.plantio) {
    const semCafe = d.erros?.plantio?.startsWith('ZARC sem café');
    return `<a href="#/avisos" class="cartao cartao-plantio" data-ler="Plantio do café: sem informação.">
      <h2 class="cartao-titulo">${icone('calendario', 26)} Plantio</h2>
      <p class="plantio-titulo">Sem dado do plantio</p>
      <p class="cartao-frase">${semCafe ? `O ZARC do MAPA não indica café para ${esc(d.ctx.municipio.nome)}.` : 'Não deu para ler o ZARC agora.'}</p>
    </a>`;
  }
  return `<a href="#/avisos" class="cartao cartao-plantio" data-cor="${d.plantio.cor}" data-ler="Plantio do café: ${esc(d.plantio.titulo)}. ${esc(d.plantio.detalhe)}.">
    <h2 class="cartao-titulo">${icone('calendario', 26)} Plantio</h2>
    <div class="plantio-linha">
      ${semaforo(d.plantio.cor)}
      <div>
        <p class="plantio-titulo">${esc(d.plantio.titulo)}</p>
        <p class="cartao-frase">${esc(d.plantio.detalhe)}</p>
        ${d.plantioBruto.exemplo ? '' : '<p class="selo-oficial">Dado oficial do MAPA · ZARC</p>'}
      </div>
    </div>
  </a>`;
}

// Cartão do fogo. "Sem informação" é diferente de "nenhum fogo": nunca diz que não tem fogo sem saber.
function cartaoFogo(d) {
  if (d.semFogo) {
    return `<a href="#/avisos" class="cartao cartao-fogo" data-ler="Fogo: sem informação agora. Se vir fumaça, ligue 193.">
      <h2 class="cartao-titulo">${icone('fogo', 26)} Alerta</h2>
      <p class="fogo-titulo">Sem informação do fogo</p>
      <p class="cartao-frase">O satélite do INPE não respondeu. Se vir fumaça, ligue 193.</p>
    </a>`;
  }
  return `<a href="#/avisos" class="cartao cartao-fogo ${d.fogo ? 'tem-fogo' : ''}"
     data-ler="${d.fogo ? `Atenção: o satélite viu fogo a ${d.fogo.kmTexto}, para os lados do ${d.fogo.direcao}.` : 'Nenhum fogo perto da sua plantação.'}">
    <h2 class="cartao-titulo">${icone('fogo', 26)} Alerta</h2>
    <div class="fogo-linha">
      <div>
        <p class="fogo-titulo">${d.fogo ? `Fogo a ${d.fogo.kmTexto}` : 'Nenhum fogo por perto'}</p>
        <p class="cartao-frase">${d.fogo
          ? `Para o ${d.fogo.direcao}${d.fogo.vistoEm ? `. Visto pelo satélite em ${d.fogo.vistoEm}` : ''}${d.fogo.total > 1 ? `. ${d.fogo.total} focos no raio de ${CONFIG.raioFogoKm} km` : ''}`
          : `Num raio de ${CONFIG.raioFogoKm} km, nas últimas 24 a 48 horas`}</p>
        <p class="nota">INPE Queimadas: junta vários satélites e atualiza ao longo do dia.</p>
      </div>
      ${miniMapa(d.fogo)}
    </div>
  </a>`;
}

export default {
  titulo: 'Início',

  async render(app) {
    const d = await app.dados();
    const p = app.perfil;
    const m = d.ctx.municipio;
    const h = d.clima?.hoje;
    const nome = p.nome ? `, ${esc(p.nome.split(' ')[0])}` : '';
    const ceu = d.fogo && d.fogo.km <= 10 ? 'fogo' : h?.ceu || 'sol';

    return `
    ${horizonte({ titulo: `${saudacao()}${nome}`, sub: `Seu café em ${esc(m.nome)} – ${m.uf}`, ceu })}
    <div class="pagina">
      <div class="painel-grade">

        ${cartaoHoje(d)}
        ${cartaoPlantio(d)}
        ${cartaoFogo(d)}
        ${cartaoPlanta(app.lavourasProntas)}
        ${cartaoSaude(app.saudePronta?.resumo)}
      </div>

      <a class="faixa-ligar" href="#/radio">${icone('radio', 26)} Boletim para a rádio</a>
      ${fontesDados([['Tempo', d.clima], ['Plantio', d.plantioBruto], ['Fogo', d.fogoBruto]])}
    </div>`;
  },

  async montar(el, app, ehAtual) {
    // As duas partes lentas chegam em paralelo e cada uma completa o seu cartão
    await Promise.allSettled([preencherPlanta(el, app, ehAtual), preencherSaude(el, app, ehAtual)]);
  },
};

async function preencherPlanta(el, app, ehAtual) {
  if (app.lavourasProntas) return; // já veio pronto no render
  const lista = await app.lavouras().catch(() => []);
  const cartao = el.querySelector('[data-cartao-planta]');
  if (!ehAtual() || !cartao) return;
  cartao.outerHTML = cartaoPlanta(lista);
}

async function preencherSaude(el, app, ehAtual) {
  let s;
  const cartao = el.querySelector('[data-cartao-saude]');
  let erro = null;
  try { s = await app.saude(); } catch (e) { s = null; erro = e.message; }
  if (!ehAtual() || !cartao) return;
  if (!s?.resumo) { // o cartão nunca some: avisa e continua levando para a tela do satélite
    const semLocal = ['sem-permissao', 'negado', 'sem-gps', 'sem-sinal', 'demorou'].includes(erro);
    cartao.querySelector('.saude-titulo').textContent = semLocal
      ? 'Toque para ver a sua plantação pelo satélite'
      : erro ? 'O satélite não respondeu agora' : 'Sem foto limpa do satélite nos últimos dias';
    cartao.querySelector('.saude-mini-vazia')?.classList.remove('saude-mini-vazia');
    return;
  }
  if (!cartao.querySelector('[data-mini]')) {
    cartao.outerHTML = cartaoSaude(s.resumo);
  }
  const ctx = el.querySelector('[data-mini]').getContext('2d');
  // Já desenhada antes? Copia na hora (voltar ao início fica instantâneo)
  if (miniPronta?.de === s) { ctx.drawImage(miniPronta.tela, 0, 0); return; }
  await desenharFoto(ctx, s.bruta);
  try { await desenharPassagem(ctx, s.bruta, s.resumo.ultima, 0.8); } catch { /* sem imagem */ }
  if (s.resumo.destaque) {
    const q = s.resumo.destaque.caixa;
    ctx.strokeStyle = '#fff'; ctx.lineWidth = 12;
    ctx.strokeRect(q[0] * LARGURA, q[1] * ALTURA, q[2] * LARGURA, q[3] * ALTURA);
  }
  const copia = document.createElement('canvas');
  copia.width = ctx.canvas.width; copia.height = ctx.canvas.height;
  copia.getContext('2d').drawImage(ctx.canvas, 0, 0);
  miniPronta = { de: s, tela: copia };
}
let miniPronta = null;
