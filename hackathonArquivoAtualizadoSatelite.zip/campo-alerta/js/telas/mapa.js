// SATÉLITE: a região da roça vista do espaço + os focos de fogo do INPE.
// Imagem: NASA GIBS (MODIS Terra, cor real, 250 m, uma por dia, sem chave).
// Mostra a fumaça e as queimadas grandes da região. Não dá para ver o pé de café:
// para isso, o próximo passo é o índice de verde (NDVI) do SATVeg/Embrapa.
//
// Privacidade: o mapa abre centrado na roça SÓ no aparelho. O servidor de imagens
// recebe pedidos de "quadradinhos" de ~40 km, que não revelam a propriedade.
import { CONFIG } from '../config.js';
import { icone } from '../icones.js';
import { esc } from '../util.js';
import { horizonte, etiquetaExemplo } from './partes.js';
import { miniMapa } from './painel.js';

const LEAFLET_JS = 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.js';
const LEAFLET_CSS = 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.css';

// Uma carga só, mesmo se for chamada várias vezes (o app.js já pede quando o celular está à toa)
let leaflet = null;
export function carregarLeaflet() {
  if (window.L) return Promise.resolve();
  if (!leaflet) {
    const l = document.createElement('link');
    l.rel = 'stylesheet'; l.href = LEAFLET_CSS;
    document.head.appendChild(l);
    leaflet = new Promise((ok, erro) => {
      const s = document.createElement('script');
      s.src = LEAFLET_JS; s.onload = ok;
      s.onerror = () => { leaflet = null; s.remove(); erro(new Error('Mapa não carregou (sem internet?)')); };
      document.head.appendChild(s);
    });
  }
  return leaflet;
}

// Imagem de ONTEM: a de hoje às vezes ainda não foi processada
function dataImagem() {
  const d = new Date(Date.now() - 864e5);
  return d.toISOString().slice(0, 10);
}
const dataBR = (iso) => iso.split('-').reverse().join('/');

export default {
  titulo: 'Satélite',

  async render(app) {
    const d = await app.dados();
    this._d = d;
    const frase = d.semFogo
      ? 'Não consegui ver os focos de fogo agora: o satélite do INPE não respondeu.'
      : d.fogo
      ? `O satélite viu ${d.fogo.total > 1 ? `${d.fogo.total} focos de fogo` : 'fogo'} perto. O mais perto está a ${d.fogo.kmTexto}, para o ${d.fogo.direcao}.`
      : `O satélite não viu fogo a menos de ${CONFIG.raioFogoKm} km da sua roça.`;

    return `
    ${horizonte({ titulo: 'Visto do satélite', sub: 'Sua região, vista do espaço', ceu: d.fogo ? 'fogo' : 'sol', voltar: 'painel' })}
    <div class="pagina">
      <div class="satelite-grade">
        <div class="mapa-sat" data-mapa role="img" aria-label="${esc(frase)}"></div>

        <div class="satelite-lado">
          <p class="satelite-frase ${d.fogo ? 'tem-fogo' : ''}" data-ler>${esc(frase)}</p>
          <ul class="legenda-mapa">
            <li><span class="leg leg-casa"></span> Sua roça</li>
            <li><span class="leg leg-fogo"></span> Fogo (INPE)</li>
            <li><span class="leg leg-raio"></span> ${CONFIG.raioFogoKm} km em volta</li>
          </ul>
          ${d.fogo ? `<a class="botao botao-fogo" href="tel:193">${icone('telefone', 28)} Fogo chegando? Ligue 193</a>` : ''}
          <p class="nota" data-ler="A imagem mostra fumaça e queimadas grandes da região.">A imagem mostra fumaça e queimadas grandes. Foto do satélite de ${dataBR(dataImagem())}.</p>
          ${d.fogoBruto ? etiquetaExemplo(d.fogoBruto.exemplo, d.fogoBruto.fonte) : '<p class="fonte">Fogo: sem informação agora</p>'}
        </div>
      </div>
      <p class="credito-mapa">Imagem: NASA GIBS, MODIS Terra. Mapa: Leaflet.</p>
    </div>`;
  },

  async montar(el, app, ehAtual) {
    const d = this._d;
    const caixa = el.querySelector('[data-mapa]');
    const centro = d.ctx.centro;

    try {
      await carregarLeaflet();
    } catch {
      // Sem internet: mostra o mapinha desenhado no lugar
      caixa.classList.add('mapa-sat-off');
      caixa.innerHTML = d.semFogo ? '' : miniMapa(d.fogo);
      return;
    }
    if (!ehAtual()) return;
    const L = window.L;
    const mapa = L.map(caixa, { zoomControl: true, attributionControl: true }).setView([centro.lat, centro.lon], 10);

    L.tileLayer(
      `https://gibs.earthdata.nasa.gov/wmts/epsg3857/best/MODIS_Terra_CorrectedReflectance_TrueColor/default/${dataImagem()}/GoogleMapsCompatible_Level9/{z}/{y}/{x}.jpg`,
      { maxNativeZoom: 9, maxZoom: 12, minZoom: 6, attribution: 'NASA GIBS / MODIS Terra' },
    ).addTo(mapa);

    // Raio de alerta
    L.circle([centro.lat, centro.lon], {
      radius: CONFIG.raioFogoKm * 1000, color: '#F2B705', weight: 3, fill: false, dashArray: '8 8',
    }).addTo(mapa);

    // Focos de fogo
    (d.fogoBruto?.focos || []).forEach((f) => {
      L.circleMarker([f.lat, f.lon], { radius: 9, color: '#fff', weight: 2, fillColor: '#B3261E', fillOpacity: 1 })
        .bindPopup(`Fogo visto ${esc(f.quando || '')}`)
        .addTo(mapa);
    });

    // Roça
    L.marker([centro.lat, centro.lon], {
      icon: L.divIcon({ className: 'marca-roca', html: icone('casa', 26), iconSize: [44, 44], iconAnchor: [22, 22] }),
      title: 'Sua roça',
    }).addTo(mapa);

    setTimeout(() => mapa.invalidateSize(), 50);
  },
};
