import { icone } from '../icones.js';
import { ouvir, falar, podeOuvir } from '../voz.js';
import { MESES } from '../util.js';
import { horizonte } from './partes.js';

const CURTO = ['jan', 'fev', 'mar', 'abr', 'mai', 'jun', 'jul', 'ago', 'set', 'out', 'nov', 'dez'];
const semAcento = (t) => t.normalize('NFD').replace(/[̀-ͯ]/g, '');

export default {
  titulo: 'Quando você planta',

  render(app) {
    const atual = app.perfil.mesTradicional;
    return `
    ${horizonte({ titulo: 'Quando você costuma plantar?', sub: 'Do jeito que você sempre fez', voltar: 'cadastro' })}
    <div class="pagina pagina-estreita">
      <div class="meses" role="radiogroup" aria-label="Mês">
        ${CURTO.map((m, i) => `
          <button type="button" role="radio" class="mes" data-mes="${i + 1}" aria-checked="${atual === i + 1}" aria-label="${MESES[i]}">${m}</button>`).join('')}
      </div>
      <button type="button" class="botao botao-contorno" data-falar-mes>${icone('mic', 30)} Falar o mês</button>
      <p class="nota" data-ler="A gente junta o que você sabe com o clima deste ano.">A gente junta o que você sabe com o clima deste ano.</p>
      <button type="button" class="botao botao-grande" data-salvar>${icone('ok', 32)} Continuar</button>
      <button type="button" class="botao-texto" data-pular>Pular esta pergunta</button>
    </div>`;
  },

  montar(el, app) {
    let escolhido = app.perfil.mesTradicional;
    const marcar = (n) => {
      escolhido = n;
      el.querySelectorAll('.mes').forEach((b) => b.setAttribute('aria-checked', String(+b.dataset.mes === n)));
    };
    el.querySelectorAll('.mes').forEach((b) => b.addEventListener('click', () => marcar(+b.dataset.mes)));

    el.querySelector('[data-falar-mes]').addEventListener('click', async () => {
      if (!podeOuvir()) return falar('Este navegador não consegue ouvir. Toque no mês.');
      await falar('Pode falar o mês');
      try {
        const frases = (await ouvir()).map(semAcento);
        const i = MESES.findIndex((m) => frases.some((f) => f.includes(semAcento(m))));
        if (i >= 0) { marcar(i + 1); falar(MESES[i]); } else falar('Não entendi o mês. Pode tocar nele na tela.');
      } catch { falar('Não consegui ouvir. Toque e fale de novo.'); }
    });

    const terminar = () => { app.salvar({ mesTradicional: escolhido, pronto: true }); app.ir('painel'); };
    el.querySelector('[data-salvar]').addEventListener('click', terminar);
    el.querySelector('[data-pular]').addEventListener('click', () => { escolhido = null; terminar(); });
  },
};
