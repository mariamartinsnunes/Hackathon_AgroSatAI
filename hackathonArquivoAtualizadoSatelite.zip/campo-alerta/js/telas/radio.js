import { icone } from '../icones.js';
import { esc } from '../util.js';
import { CONFIG } from '../config.js';
import { gerarBoletim } from '../regras.js';
import { falar, pararDeFalar } from '../voz.js';
import { horizonte, fontesDados } from './partes.js';

export default {
  titulo: 'Rádio',

  async render(app) {
    const d = await app.dados();
    const b = gerarBoletim(d);
    this._texto = b.texto;
    return `
    ${horizonte({ titulo: 'Boletim da rádio', sub: 'Para quem não tem celular ouvir também' })}
    <div class="pagina">
      <div class="radio-grade">
        <section class="radio-tocar">
          <button type="button" class="radio-play" data-tocar aria-label="Tocar boletim">${icone('play', 64)}</button>
          <p class="radio-duracao">Cerca de 1 minuto</p>
          <p class="radio-quando">A cada 3 dias. Todo dia se tiver alerta.</p>
          ${CONFIG.vozIA?.ativa ? `<p class="radio-ia">${CONFIG.vozIA.aviso}</p>` : ''}
        </section>

        <section class="radio-texto">
          <h2>${icone('radio', 26)} Texto do locutor</h2>
          <p class="locutor">${esc(b.texto)}</p>
          <p class="nota">${b.palavras} palavras</p>
        </section>
      </div>

      <div class="radio-acoes">
        <button type="button" class="botao botao-grande" data-mandar>${icone('enviar', 30)} Mandar pra rádio</button>
        <button type="button" class="botao botao-contorno" data-baixar>${icone('baixar', 28)} Baixar texto</button>
        <button type="button" class="botao botao-contorno" data-copiar>${icone('copiar', 28)} Copiar texto</button>
      </div>
      ${fontesDados([['Tempo', d.clima], ['Plantio', d.plantioBruto], ['Fogo', d.fogoBruto]])}
    </div>`;
  },

  montar(el) {
    const texto = this._texto;
    const play = el.querySelector('[data-tocar]');

    play.addEventListener('click', async () => {
      if (document.body.classList.contains('falando')) { pararDeFalar(); return; }
      play.innerHTML = '<svg class="ic" viewBox="0 0 24 24" width="64" height="64" aria-hidden="true"><rect x="6" y="6" width="12" height="12" rx="2" fill="currentColor"/></svg>';
      await falar(texto);
      play.innerHTML = '<svg class="ic" viewBox="0 0 24 24" width="64" height="64" aria-hidden="true"><path d="M7 4v16l13-8z" fill="currentColor"/></svg>';
    });

    const copiar = el.querySelector('[data-copiar]');
    copiar.addEventListener('click', async () => {
      try { await navigator.clipboard.writeText(texto); copiar.lastChild.textContent = ' Copiado'; } catch { /* sem permissão */ }
    });

    el.querySelector('[data-baixar]').addEventListener('click', () => {
      const a = document.createElement('a');
      a.href = URL.createObjectURL(new Blob([texto], { type: 'text/plain;charset=utf-8' }));
      a.download = `boletim-campo-alerta-${new Date().toISOString().slice(0, 10)}.txt`;
      a.click();
    });

    // Hoje: compartilha o texto (WhatsApp da rádio). Depois: MP3 gerado com a voz Piper.
    el.querySelector('[data-mandar]').addEventListener('click', async () => {
      if (navigator.share) { try { await navigator.share({ title: 'Boletim Campo Alerta', text: texto }); return; } catch { /* cancelou */ } }
      window.open(`https://wa.me/?text=${encodeURIComponent(texto)}`, '_blank', 'noopener');
    });
  },
};
