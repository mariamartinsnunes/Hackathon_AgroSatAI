import { CONFIG } from '../config.js';
import { icone, aplicarIcones } from '../icones.js';
import { esc } from '../util.js';
import { resumoLavoura } from '../regras.js';
import { falar } from '../voz.js';
import { permissaoLocal, pegarLocal, textoErroLocal } from '../local.js';
import { LARGURA, ALTURA, desenharFoto, desenharPassagem, desenharNuvens, mediaPassagem, estadoNdvi, nomeCurto } from '../satelite.js';
import { horizonte } from './partes.js';

const dataCurta = (iso) => { const [, m, d] = iso.split('-'); return `${d}/${m}`; };
const ERROS_LOCAL = ['sem-gps', 'sem-permissao', 'negado', 'sem-sinal', 'demorou'];
const SIMBOLO = { verde: '✓', amarelo: '!', vermelho: '!', cinza: '?' };

const EXPLICA_LOCAL = 'O app olha a área de 800 x 600 metros em volta de onde você está agora. A sua posição fica no celular: para o satélite vai só um quadrado arredondado de uns 2,5 km.';

// Lista falada dos pontos: "Preocupação: o canto de baixo, à esquerda. Saudável: o meio, ..."
function listaPontos(pontos) {
  const grupos = [
    ['vermelho', 'Preocupação'],
    ['amarelo', 'Atenção'],
    ['verde', 'Saudável'],
    ['cinza', 'Sem dado (nuvem ou água)'],
  ];
  return grupos.map(([cor, rotulo]) => {
    const deste = pontos.filter((p) => p.cor === cor);
    if (!deste.length) return '';
    const nomes = deste.map((p) => nomeCurto(p.nome).toLowerCase()).join('; ');
    return `<li data-cor="${cor}"><span class="lav-ponto-mini" data-cor="${cor}" aria-hidden="true">${SIMBOLO[cor]}</span>
      <div><b>${rotulo}</b><p data-ler="${esc(`${rotulo}: ${nomes}`)}">${esc(nomes.charAt(0).toUpperCase() + nomes.slice(1))}</p></div></li>`;
  }).join('');
}

export default {
  titulo: 'Satélite',

  // Abre NA HORA. Se o satélite ainda não veio, mostra o quadro de espera e completa depois.
  render(app) {
    if (!app.saudePronta) {
      this._lav = null;
      return `
      ${horizonte({ titulo: 'Saúde da lavoura', sub: 'Em volta de onde você está', voltar: 'painel' })}
      <div class="pagina pagina-estreita">
        <div class="lav-quadro lav-quadro-esperando" role="status">
          ${icone('satelite', 56)}
          <p data-ler data-esperando>Vendo se dá para usar a sua localização…</p>
          <button type="button" class="botao" data-usar-local hidden>${icone('local', 28)} Usar minha localização</button>
        </div>
        <p class="nota lav-explica-local">${icone('info', 20)} ${EXPLICA_LOCAL}</p>
      </div>`;
    }
    return this.desenho(app.saudePronta);
  },

  desenho(l) {
    const lav = l.bruta;
    this._lav = lav;
    // Abre na foto mais recente SEM nuvem
    const limpa = lav.passagens.map((x) => !x.nuvem).lastIndexOf(true);
    const ultima = limpa >= 0 ? limpa : lav.passagens.length - 1; // tudo nublado: abre na mais nova
    this._inicio = ultima;
    const precisao = lav.area?.precisaoM;

    return `
    ${horizonte({ titulo: 'Saúde da lavoura', sub: 'Em volta de onde você está', voltar: 'painel' })}
    <div class="pagina">
      <div class="lav-grade">

        <div class="lav-coluna-mapa">
          <div class="lav-quadro" data-quadro>
            <canvas class="lav-foto" width="${LARGURA}" height="${ALTURA}" data-foto aria-hidden="true"></canvas>
            <canvas class="lav-ndvi" width="${LARGURA}" height="${ALTURA}" data-ndvi aria-hidden="true"></canvas>
            <div class="lav-pontos-mapa" data-pontos aria-hidden="true"></div>
            <span class="lav-voce" aria-hidden="true"><span></span>Você</span>
            <span class="lav-pin" data-pin hidden>${icone('local', 22)} Olhe aqui</span>
            <span class="lav-nuvem" data-nuvem hidden>${icone('nuvem', 40)}<b>Nublado neste dia</b><span>As nuvens taparam a área</span></span>
            <span class="lav-simulado">Satélite real · 800 x 600 m</span>
          </div>

          <div class="lav-modo" role="radiogroup" aria-label="O que mostrar">
            <button type="button" role="radio" aria-checked="false" data-modo="foto">${icone('camera', 24)} Foto</button>
            <button type="button" role="radio" aria-checked="true" data-modo="saude">${icone('folha', 24)} Saúde</button>
          </div>
        </div>

        <div class="lav-coluna-info">
          <article class="lav-aviso" data-aviso aria-live="polite"></article>

          <section class="lav-pontos-lista" data-lista-pontos-caixa>
            <h2>Pontos da área</h2>
            <ul data-lista-pontos></ul>
          </section>

          <section class="lav-tempo">
            <h2>Fotos do satélite</h2>
            <div class="lav-datas" role="radiogroup" aria-label="Data da foto" style="grid-template-columns: repeat(${Math.max(lav.passagens.length, 1)}, 1fr)">
              ${lav.passagens.map((p, i) => {
                const m = mediaPassagem(lav, p);
                const est = m == null ? null : estadoNdvi(m);
                return `<button type="button" role="radio" class="lav-data" data-i="${i}" aria-checked="${i === ultima}"
                  aria-label="${dataCurta(p.data)}${p.nuvem ? ', nuvem' : est ? `, ${est.nome}` : ''}">
                  ${p.nuvem || !est ? icone('nuvem', 22) : `<span class="lav-bolinha" data-cor="${est.cor}"></span>`}
                  <span>${dataCurta(p.data)}</span>
                </button>`;
              }).join('')}
            </div>
            ${lav.passou ? `<p class="nota">${icone('satelite', 20)} Nos últimos 80 dias o satélite passou ${lav.passou.vezes} vezes aqui${lav.passou.menorIntervalo ? `, com ${lav.passou.menorIntervalo} a ${lav.passou.maiorIntervalo} dias entre uma e outra` : ''}. A mais recente foi em ${dataCurta(lav.passou.ultima)}. Dia nublado não dá para ver a plantação.</p>
            <p class="nota">Satélites: ${esc(lav.passou.satelites)} (Copernicus).</p>` : ''}
          </section>

          <ul class="lav-legenda" aria-label="Legenda das cores">
            <li><span data-cor="verde"></span>Saudável</li>
            <li><span data-cor="amarelo"></span>Atenção</li>
            <li><span data-cor="vermelho"></span>Preocupação</li>
          </ul>
          <p class="nota">O satélite mede o verde de tudo: estrada, casa, pasto seco e terra sem planta também ficam vermelhos. Olhe onde tem café.</p>

          <details class="lav-explica">
            <summary>${icone('info', 22)} Como o satélite sabe?</summary>
            <p>O satélite mede o verde das folhas com uma luz que o nosso olho não enxerga. Folha saudável brilha muito nessa luz; folha amarela ou doente brilha pouco. Cada quadradinho da cor tem 10 x 10 metros: ele enxerga a lavoura, mas não cada pé. Por isso, quando algo muda, pedimos uma foto da folha.</p>
            <p>${EXPLICA_LOCAL}</p>
          </details>

          ${precisao > 100 ? `<p class="nota nota-alerta">${icone('local', 20)} A sua localização tem erro de uns ${precisao >= 1000 ? `${Math.round(precisao / 1000)} km` : `${precisao} m`}. No celular, com o GPS ligado, fica mais certa.</p>` : ''}
          <p class="fonte">${esc(lav.credito || 'Fonte: ' + lav.fonte)}</p>
        </div>
      </div>
    </div>`;
  },

  async montar(el, app, ehAtual) {
    if (this._lav) return this.ligar(el, app, ehAtual);

    const texto = el.querySelector('[data-esperando]');
    const botao = el.querySelector('[data-usar-local]');
    const pedirToque = (msg, rotulo = 'Usar minha localização') => {
      texto.textContent = msg;
      botao.lastChild.textContent = ` ${rotulo}`;
      botao.hidden = false;
    };

    const carregar = async () => {
      botao.hidden = true;
      texto.textContent = 'Procurando onde você está…';
      try {
        await pegarLocal({ pedir: true });
        if (!ehAtual()) return;
        texto.textContent = 'Buscando as fotos do satélite…';
        const l = await app.saude({ pedir: true });
        if (!ehAtual()) return;
        el.innerHTML = this.desenho(l);
        aplicarIcones(el);
        this.ligar(el, app, ehAtual);
      } catch (e) {
        if (!ehAtual()) return;
        console.warn('[satélite]', e.message);
        if (ERROS_LOCAL.includes(e.message)) pedirToque(textoErroLocal(e.message), 'Tentar de novo');
        else if (/^(Nenhuma foto|As fotos do satélite)/.test(e.message)) pedirToque(`${e.message}.`, 'Tentar de novo');
        else pedirToque('O satélite não respondeu agora. Confira a internet e tente de novo daqui a pouco.', 'Tentar de novo');
      }
    };
    botao.addEventListener('click', carregar);

    // Já carregando (o início pediu)? Espera. Já deixou a localização? Vai direto. Senão, pede com um toque.
    if (app._saude) { carregar(); return; }
    const estado = await permissaoLocal();
    if (!ehAtual()) return;
    if (estado === 'granted') carregar();
    else if (estado === 'denied') pedirToque(textoErroLocal('negado'), 'Tentar de novo');
    else if (estado === 'sem-gps') { texto.textContent = textoErroLocal('sem-gps'); }
    else pedirToque('Para ver a sua plantação pelo satélite, toque no botão e deixe o app usar a sua localização.');
  },

  ligar(el, app, ehAtual) {
    const lav = this._lav;
    const fotoCtx = el.querySelector('[data-foto]').getContext('2d');
    const ndvi = el.querySelector('[data-ndvi]');
    const nctx = ndvi.getContext('2d');
    const pin = el.querySelector('[data-pin]');
    const nuvemMsg = el.querySelector('[data-nuvem]');
    const aviso = el.querySelector('[data-aviso]');
    const camadaPontos = el.querySelector('[data-pontos]');
    const lista = el.querySelector('[data-lista-pontos]');
    const caixaLista = el.querySelector('[data-lista-pontos-caixa]');
    let indice = this._inicio;
    let modo = 'saude';

    desenharFoto(fotoCtx, lav); // foto aérea real (Esri)

    function desenhar() {
      const p = lav.passagens[indice];
      const r = p.nuvem ? null : resumoLavoura(lav, indice);
      nctx.clearRect(0, 0, LARGURA, ALTURA);
      nuvemMsg.hidden = !p.nuvem;
      pin.hidden = true;
      camadaPontos.innerHTML = '';
      const verSaude = modo === 'saude';

      if (p.nuvem) {
        desenharNuvens(nctx);
      } else {
        desenharPassagem(nctx, lav, p);
        if (r) {
          // linhas das 9 partes
          nctx.save();
          nctx.strokeStyle = 'rgba(255,255,255,.6)'; nctx.lineWidth = 2; nctx.setLineDash([8, 8]);
          r.pontos.forEach((q) => nctx.strokeRect(q.caixa[0] * LARGURA, q.caixa[1] * ALTURA, q.caixa[2] * LARGURA, q.caixa[3] * ALTURA));
          nctx.restore();
          // um ponto colorido no meio de cada parte
          camadaPontos.innerHTML = r.pontos.map((q) => `<span class="lav-ponto" data-cor="${q.cor}"
            style="left:${(q.caixa[0] + q.caixa[2] * 0.3) * 100}%;top:${(q.caixa[1] + q.caixa[3] * 0.7) * 100}%">${SIMBOLO[q.cor]}</span>`).join('');
          if (r.destaque) {
            const c = r.destaque.caixa;
            nctx.save();
            nctx.strokeStyle = '#fff'; nctx.lineWidth = 6;
            nctx.strokeRect(c[0] * LARGURA, c[1] * ALTURA, c[2] * LARGURA, c[3] * ALTURA);
            nctx.restore();
            pin.style.left = `${(c[0] + c[2] * 0.3) * 100}%`;
            pin.style.top = `${(c[1] + c[3] * 0.7) * 100 - 3}%`; // aponta para o ponto da parte (fora do "Você", no meio)
            pin.hidden = !verSaude;
          }
        }
      }
      ndvi.classList.toggle('lav-ndvi-off', !verSaude && !p.nuvem);
      camadaPontos.hidden = !verSaude;

      // Lista de pontos
      caixaLista.hidden = !r;
      lista.innerHTML = r ? listaPontos(r.pontos) : '';

      // Aviso
      if (p.nuvem) {
        aviso.dataset.cor = 'ceu';
        aviso.innerHTML = `<span class="lav-aviso-icone">${icone('nuvem', 34)}</span>
          <div><h2 data-ler>Nublado no dia ${dataCurta(p.data)}</h2><p data-ler>As nuvens taparam a área. Veja outra data.</p></div>`;
      } else if (!r) {
        aviso.dataset.cor = 'ceu';
        aviso.innerHTML = `<span class="lav-aviso-icone">${icone('info', 34)}</span>
          <div><h2 data-ler>Sem dado neste dia</h2><p data-ler>Nesta foto não deu para medir o verde da área.</p></div>`;
      } else {
        const preocupa = r.alerta || r.atencao;
        aviso.dataset.cor = preocupa ? 'grao' : 'folha';
        aviso.innerHTML = `<span class="lav-aviso-icone">${icone(preocupa ? 'satelite' : 'ok', 34)}</span>
          <div><h2 data-ler>${esc(r.titulo)}</h2><p data-ler>${esc(r.detalhe)}</p></div>
          ${preocupa ? `<div class="lav-aviso-botoes">
            <a class="botao" href="#/foto">${icone('camera', 26)} Tirar foto da folha</a>
            <a class="botao botao-contorno" href="tel:${CONFIG.tecnico.telefone}">${icone('telefone', 26)} Chamar técnico</a>
          </div>` : ''}`;
      }
    }

    el.querySelectorAll('[data-i]').forEach((b) => b.addEventListener('click', () => {
      indice = +b.dataset.i;
      el.querySelectorAll('[data-i]').forEach((x) => x.setAttribute('aria-checked', String(x === b)));
      desenhar();
    }));
    el.querySelectorAll('[data-modo]').forEach((b) => b.addEventListener('click', () => {
      modo = b.dataset.modo;
      el.querySelectorAll('[data-modo]').forEach((x) => x.setAttribute('aria-checked', String(x === b)));
      desenhar();
      if (modo === 'saude') falar('Verde é saudável. Amarelo é atenção. Vermelho é preocupação.');
    }));

    desenhar();
  },
};
