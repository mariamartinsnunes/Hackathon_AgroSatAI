// Desenhos simples das culturas (para quem não lê, a figura diz)
export const DESENHOS = {
  cafe: `<svg viewBox="0 0 64 64" aria-hidden="true">
    <path d="M10 52 C24 40 38 30 56 12" stroke="#5A3A22" stroke-width="3" fill="none" stroke-linecap="round"/>
    <path d="M24 40 C14 38 8 30 10 22 C20 24 26 30 24 40Z" fill="#2F5B27"/>
    <path d="M40 26 C44 16 52 12 60 14 C58 24 50 28 40 26Z" fill="#2F5B27"/>
    <path d="M34 34 C40 40 40 50 34 56 C28 50 28 40 34 34Z" fill="#4E9A3C"/>
    <circle cx="22" cy="47" r="5.5" fill="#B3261E"/><circle cx="31" cy="44" r="5.5" fill="#C8372B"/>
    <circle cx="44" cy="31" r="5" fill="#B3261E"/><circle cx="26" cy="54" r="4.5" fill="#E0A21B"/>
  </svg>`,
  soja: `<svg viewBox="0 0 64 64" aria-hidden="true">
    <path d="M32 58V18" stroke="#7AB05E" stroke-width="3" stroke-linecap="round"/>
    <ellipse cx="22" cy="22" rx="10" ry="6" fill="#4E9A3C" transform="rotate(-25 22 22)"/>
    <ellipse cx="42" cy="20" rx="10" ry="6" fill="#2F5B27" transform="rotate(25 42 20)"/>
    <ellipse cx="21" cy="36" rx="9" ry="5" fill="#2F5B27" transform="rotate(-20 21 36)"/>
    <ellipse cx="43" cy="38" rx="3.5" ry="9" fill="#B5895A"/>
    <ellipse cx="48" cy="46" rx="3" ry="8" fill="#C9A06B"/>
  </svg>`,
  milho: `<svg viewBox="0 0 64 64" aria-hidden="true">
    <path d="M32 6 C42 14 44 34 32 54 C20 34 22 14 32 6Z" fill="#F2B705"/>
    <path d="M28 18h8M27 26h10M27 34h10M28 42h8" stroke="#C98F00" stroke-width="2.5" stroke-linecap="round"/>
    <path d="M32 58 C22 52 14 40 16 26 C24 34 28 44 32 58Z M32 58 C42 52 50 40 48 26 C40 34 36 44 32 58Z" fill="#4E9A3C"/>
  </svg>`,
  mandioca: `<svg viewBox="0 0 64 64" aria-hidden="true">
    <path d="M30 14 C40 22 44 40 38 58 C30 52 24 34 30 14Z" fill="#8A5A3B"/>
    <path d="M30 14 C22 20 16 36 18 52 C26 46 32 30 30 14Z" fill="#A06B45"/>
    <path d="M30 14 L24 4 M30 14 L34 3 M30 14 L40 6" stroke="#2F5B27" stroke-width="3" stroke-linecap="round"/>
  </svg>`,
  feijao: `<svg viewBox="0 0 64 64" aria-hidden="true">
    <ellipse cx="22" cy="28" rx="11" ry="8" fill="#6B2E1F" transform="rotate(-20 22 28)"/>
    <ellipse cx="42" cy="24" rx="11" ry="8" fill="#7E3A26" transform="rotate(15 42 24)"/>
    <ellipse cx="32" cy="44" rx="11" ry="8" fill="#6B2E1F" transform="rotate(-5 32 44)"/>
  </svg>`,
};
