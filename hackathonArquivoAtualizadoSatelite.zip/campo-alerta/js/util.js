export const MESES = ['janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho', 'julho',
  'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'];
export const DIAS = ['domingo', 'segunda', 'terça', 'quarta', 'quinta', 'sexta', 'sábado'];

// Decêndio do ano (1 a 36) — é assim que o ZARC divide o calendário
export function decendio(data = new Date()) {
  const d = data.getDate();
  return data.getMonth() * 3 + (d <= 10 ? 1 : d <= 20 ? 2 : 3);
}
export function mesDoDecendio(dec) { return MESES[Math.floor((dec - 1) / 3)]; }

// Distância em km entre dois pontos
export function distanciaKm(a, b) {
  const R = 6371, rad = (g) => (g * Math.PI) / 180;
  const dLat = rad(b.lat - a.lat), dLon = rad(b.lon - a.lon);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(rad(a.lat)) * Math.cos(rad(b.lat)) * Math.sin(dLon / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}

// Direção de A para B em graus (0 = norte)
export function rumo(a, b) {
  const rad = (g) => (g * Math.PI) / 180;
  const y = Math.sin(rad(b.lon - a.lon)) * Math.cos(rad(b.lat));
  const x = Math.cos(rad(a.lat)) * Math.sin(rad(b.lat)) - Math.sin(rad(a.lat)) * Math.cos(rad(b.lat)) * Math.cos(rad(b.lon - a.lon));
  return ((Math.atan2(y, x) * 180) / Math.PI + 360) % 360;
}
export function rumoEmPalavras(g) {
  return ['norte', 'nordeste', 'leste', 'sudeste', 'sul', 'sudoeste', 'oeste', 'noroeste'][Math.round(g / 45) % 8];
}

// Localização "grossa" (~11 km). É o máximo que mandamos pro servidor.
export function arredondar(v) { return Math.round(v * 10) / 10; }

export function saudacao(d = new Date()) {
  const h = d.getHours();
  return h < 12 ? 'Bom dia' : h < 18 ? 'Boa tarde' : 'Boa noite';
}

export function esc(t) {
  return String(t ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

// ---------- Datas (usadas pelas lavouras) ----------
export function parametros() {
  return new URLSearchParams(location.hash.split('?')[1] || '');
}

export function paraISO(d) {
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}

export function deISO(s) {
  const [a, m, d] = String(s).split('-').map(Number);
  return new Date(a, m - 1, d);
}

export function somarDias(d, n) {
  const x = new Date(d.getFullYear(), d.getMonth(), d.getDate());
  x.setDate(x.getDate() + n);
  return x;
}

export function diasEntre(a, b) {
  return Math.round((Date.UTC(b.getFullYear(), b.getMonth(), b.getDate()) - Date.UTC(a.getFullYear(), a.getMonth(), a.getDate())) / 864e5);
}

export function dataCurta(d, ref) {
  const ano = ref && d.getFullYear() !== ref.getFullYear() ? ` ${d.getFullYear()}` : '';
  return `${d.getDate()} ${MESES[d.getMonth()].slice(0, 3)}${ano}`;
}

export function dataLonga(d) {
  return `${d.getDate()} de ${MESES[d.getMonth()]} de ${d.getFullYear()}`;
}

// Número entre 0 e 1 sempre igual para o mesmo texto (dados de exemplo estáveis)
export function aleatorioDe(texto) {
  let h = 2166136261;
  for (let i = 0; i < texto.length; i++) {
    h ^= texto.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return (h >>> 0) / 4294967296;
}
