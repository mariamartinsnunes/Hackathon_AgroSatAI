# Campo Alerta

App (celular e computador) que avisa o pequeno produtor de café sobre tempo, plantio, fogo e doença na folha, por voz. Tem também um boletim de 1 minuto para a rádio.

> **Regra do app: nada de dado inventado.** Se um serviço não responde e não tem valor guardado no aparelho, a tela diz "sem informação agora". Os provedores `mock` existem só para testar sem internet e não são usados.
Feito para o Hackathon de Dados Abertos (IFSP Araraquara, 2026).

## Rodar no VS Code

1. Abra esta pasta no VS Code (Arquivo > Abrir pasta).
2. Instale a extensão **Live Server** e clique em **Go Live** (canto de baixo).
   Ou rode no terminal: `npm run dev`. Depois abra http://localhost:3000
3. Use o **Chrome ou o Edge**. São os navegadores que ouvem a voz.

> Não abra o `index.html` com dois cliques: os módulos JS precisam de um servidor.

## Onde mexer

| Quero... | Arquivo |
|---|---|
| Trocar de API | `js/config.js` |
| Mudar textos dos avisos, semáforo, boletim | `js/regras.js` |
| Mudar uma tela | `js/telas/<tela>.js` |
| Mudar cores e tamanhos | `css/estilo.css` (topo: `:root`) |
| Palavras que a voz entende | `js/voz.js` (lista `INTENCOES`) |
| Fases, graus-dia e colheita das lavouras | `js/crescimento.js` |

## APIs: como trocar sem quebrar nada

Cada serviço tem vários **provedores**, e todos devolvem **o mesmo formato**. As telas nunca chamam uma API direto: elas chamam `js/api/index.js`.

```js
// js/config.js
provedores: {
  clima: 'openmeteo',   // tempo (Open-Meteo)
  fogo: 'inpe',         // INPE Queimadas (Vercel ou direto do INPE)
  plantio: 'zarc',      // ZARC do MAPA, dado REAL já incluído
  produtos: 'agrofit',  // Agrofit do MAPA (a tela da foto não mostra mais)
  ia: 'api',            // IA da folha do time
  saude: 'planetary',   // satélite real, na localização ATUAL do aparelho
  historico: 'openmeteo', // clima medido desde o plantio (Minhas lavouras)
  ndvi: 'nenhum',       // lavoura sem contorno: não mostra satélite (não inventa)
}
```

- Se o provedor real falhar, o app usa o **último valor bom guardado no aparelho** (com etiqueta). Se não tiver, mostra **"sem informação agora"**. Nunca cai em exemplo (`usarMockSeFalhar: false`).
- Para testar outra API: crie mais uma função em `js/api/<servico>.js` que devolva o mesmo formato e coloque o nome dela no `config.js`.
- **Open-Meteo** (tempo) é chamado direto do navegador: aceita CORS e não pede chave. Manda só a localização arredondada (~11 km). Traz temperatura agora, umidade, vento, chuva e previsão de 5 dias. É grátis para uso não comercial.
- **INMET** passa pela função do Vercel (`api/clima.js`).
- **INPE (fogo)**: publicado no Vercel, passa por `api/fogo.js`. No Live Server, o app baixa direto o CSV do INPE (aceita CORS, testado em 02/10) e filtra no celular. Junta o arquivo de hoje e o de ontem (últimas 24 a 48 h): o de hoje começa vazio às 21h de Brasília. O CSV do Brasil todo tem uns 3 MB na seca.
- **ZARC e Agrofit (dados.agricultura.gov.br) já estão ligados com dado real**, em JSON pequeno dentro de `dados/`:
  - `dados/zarc-cafe.json`: Tábua de Risco do ZARC, arquivo *Perene, Olerícola e Sem Safra* (535 MB, 2,3 milhões de linhas). Ficou só **Café Arábica Implantação, sequeiro**, nos **640 municípios de SP** com café zoneado (73 deles só têm canéfora). Portarias 582/2021 (arábica) e 07/2024 (canéfora). Usado no **semáforo de plantio** (início, avisos, rádio, telefone e voz).
  - `dados/agrofit-cafe.json`: Agrofit, *Produto Formulado* (392 MB), com a contagem de produtos por doença. **Saiu da tela da foto em 02/10** (decisão do time); o arquivo e o script continuam no projeto.
  - `dados/municipios.json`: os **645 municípios de SP** (código IBGE + sede), da lista pública kelvins/municipios-brasileiros. O cadastro escolhe no celular o município mais perto e cruza com o ZARC (os 640 municípios do ZARC estão todos na lista).
  - Na tela de início aparece "Dado oficial do MAPA · ZARC" e, no rodapé, a fonte de cada informação.
- Para refazer com um arquivo mais novo, os scripts continuam valendo:
  ```
  python scripts/gerar_zarc.py "dados-abertos-tabua-de-risco-safra-perene-olericola-sem-safra.csv"
  python scripts/gerar_agrofit.py "Produto Formulado.CSV"
  ```
  Os scripts mostram os nomes das colunas. Se não acharem alguma, ajustem o nome no script.
- **IA da folha**: veja `modelo/LEIA.md` (Teachable Machine).

## IA da folha (API de vocês)

O app manda a foto da folha para `https://fastapi-ml-7fcy.onrender.com/predict` (FastAPI, MobileNetV2 treinado com DigiPathos). Código em `js/api/ia.js`, `ia: 'api'` no `config.js`.

- A foto é **reduzida para 512 px** antes de enviar (fica ~20 KB, rápido até no 3G).
- A API reconhece 6 doenças: ferrugem, cercosporiose (olho-pardo), bicho-mineiro, mancha-aureolada, mancha-manteigosa e phoma. O app mostra as 3 mais prováveis.
- **Ela não tem a classe "folha sadia"**: sempre aponta uma doença. (O aviso na tela foi tirado em 02/10, a pedido do time; falem isso no pitch.) Vale treinar essa classe.
- **Servidor gratuito do Render dorme** depois de um tempo parado e leva até 1 minuto para acordar. O app já "acorda" a API ao abrir e ao entrar na tela da foto, e avisa a pessoa se demorar. **Antes do pitch, abram a tela da foto uma vez.**
- Se a IA falhar, o app **não inventa diagnóstico**: mostra "Não consegui analisar" com o botão do técnico.

**CORS:** liberado na API (testado em 02/10): o app chama direto, inclusive no Live Server. Se um dia voltar a bloquear, publicado no Vercel o app passa pela função `api/folha.js`, que repassa a foto.

## Voz: como funciona

**O app fala (lê a tela).** Todo texto que deve ser lido tem o atributo `data-ler`:

```html
<h2 data-ler>Espere</h2>                       <!-- lê o texto -->
<a data-ler="Fogo a 4 quilômetros">…</a>        <!-- lê o que está no atributo -->
```

O botão **Ouvir** junta, em ordem, tudo que tem `data-ler` e fala com `speechSynthesis` (voz pt-BR do sistema, funciona sem internet). Tela nova = é só marcar o que deve ser lido.

**O app ouve (comandos).** O botão **Falar** usa `SpeechRecognition` (Chrome/Edge, precisa de internet e HTTPS; `localhost` também vale). O que a pessoa fala passa por `entender()` em `js/voz.js`, que procura palavras-chave:

| Fala | Faz |
|---|---|
| "vai chover?", "tempo", "calor" | responde o tempo |
| "posso plantar?", "muda" | responde o semáforo do plantio |
| "tem fogo?", "queimada" | responde o fogo mais perto |
| "folha doente", "mancha", "ferrugem" | abre a foto da folha |
| "aviso", "rádio", "voltar" | abre a tela |

Os 4 botões de exemplo na tela Falar funcionam como se a pessoa tivesse falado. Se o microfone falhar no pitch, toque neles.

## Minhas lavouras: crescimento simulado + satélite

O produtor cadastra o que plantou (soja ou café), a área e o dia do plantio. O app conta os dias, soma o calor de cada dia (graus-dia) e mostra a planta crescendo por fases. Quando chega a época, avisa.

| Quero... | Arquivo |
|---|---|
| Mudar fases, graus-dia e curva de NDVI de uma cultura | `js/crescimento.js` (objeto `CULTURAS`) |
| Mudar os desenhos da planta | `js/planta.js` |
| Trocar a fonte de temperatura e chuva | `js/config.js` → `historico: 'openmeteo' \| 'nasa'` |
| Trocar a fonte do satélite | `js/config.js` → `ndvi: 'nenhum' \| 'arquivo'` |
| Mudar os textos de atraso e colheita | `js/crescimento.js` (`comparar`, `textoColheita`) |

**Como funciona**
- Cada dia soma `(Tmax + Tmin) / 2 - Tbase`. Cada fase acontece quando a soma chega a um valor. A janela de colheita vem do ritmo recente de calor (soja: últimos 21 dias; café: último ano).
- O satélite entrega NDVI (verde da vegetação) a cada ~5 dias. O app compara com o NDVI esperado para aquele ponto da simulação. Se está abaixo, diz quantos dias de atraso e cruza com os dias sem chuva (pode ser água) ou sugere olhar praga, solo e falha de plantio.
- O mapa 3x3 mostra a zona mais fraca ("comece pela C1").
- O check-in ("Confere com a sua lavoura?") ajusta a simulação com o que o produtor vê.

**O que é real e o que é estimativa**
- Clima desde o plantio: **real**, Open-Meteo (arquivo ERA5 + últimos 14 dias), localização arredondada (~11 km). Sem internet: "sem informação agora".
- Fase, colheita: **estimativa** feita com esse clima (graus-dia). Os valores e as curvas são aproximações: confiram com a Embrapa ou um agrônomo.
- Satélite de cada lavoura: **não aparece** (`ndvi: 'nenhum'`), porque a lavoura ainda não tem contorno no mapa. O satélite de verdade está na tela Satélite, em volta de onde a pessoa está.
- Lavouras ficam só no aparelho (localStorage).

## Satélite: saúde da lavoura em volta de você (tela `#/saude`)

**Dado real, na localização ATUAL do aparelho.** Nada de cafezal pré-definido e nada de simulação.

1. A tela pede a localização (botão "Usar minha localização"; se já foi liberada, vai direto).
2. A área é um retângulo de **800 x 600 m com a pessoa no meio**.
3. O app busca as passagens do **Sentinel-2 dos últimos 80 dias** (Microsoft Planetary Computer, sem chave), uma por dia, e usa as 5 mais recentes.
4. Para cada data, baixa o mapa de classes (SCL) e o **NDVI** e recorta a área no celular. Nuvem, sombra de nuvem e água ficam de fora. Mais de 10% de nuvem: a data aparece como "Nublado".
5. A área é dividida em **9 pontos** (3 x 3). Cada um ganha uma cor: **verde = saudável** (NDVI ≥ 0,66), **amarelo = atenção**, **vermelho = preocupação** (NDVI < 0,5 ou perdeu 0,08 desde a primeira foto). O pior ganha o "Olhe aqui".
6. Foto de fundo: Esri World Imagery (pode ser antiga). Cada quadradinho de cor tem 10 x 10 m.

**Privacidade:** a posição exata fica no celular. Para o Planetary Computer vai só um quadrado de ~2,5 km em volta de um ponto **arredondado** (grade de 0,01°, ~1 km); o recorte é feito no aparelho. Para a Esri vão os quadradinhos da foto (uns 12, como qualquer mapa).

**Limites (falem no pitch):** o satélite mede o verde de tudo: estrada, casa, pasto seco e terra sem planta também ficam vermelhos. No computador, a localização vem do Wi-Fi e pode errar por quilômetros (a tela mostra o erro). No IFSP, a área vai ser o campus, não um cafezal.

## Tela Satélite (fogo)

A tela Satélite abre ao tocar no cartão **Alerta**. Ela mostra:
- a imagem de ontem do satélite **MODIS Terra** (NASA GIBS, sem chave), que deixa ver fumaça e queimadas grandes;
- a roça, o raio de 30 km e os focos de fogo do INPE.

O mapa usa **Leaflet** (cdnjs). Sem internet, aparece o mapinha desenhado no lugar.

Próximo passo: o índice de verde da lavoura (NDVI) pelo **SATVeg/Embrapa** (AgroAPI), para mostrar "sua lavoura está mais seca que o normal".

## Voz clonada (ElevenLabs)

O app fala com a voz clonada quando está publicado no Vercel. Rodando no Live Server, ele usa a voz do navegador sozinho.

1. Na ElevenLabs, clone a voz e copie o **Voice ID**. Gere uma **API key**.
2. No Vercel: **Settings > Environment Variables**. Crie `ELEVENLABS_API_KEY` e `ELEVENLABS_VOICE_ID` (veja `.env.example`). Depois faça **Redeploy**.
3. Pronto: o botão Ouvir, a tela Falar e a rádio passam a usar a voz clonada (`api/voz.js`).

- **A chave nunca vai no código do app nem no GitHub**: quem abre o site veria a chave e gastaria seus créditos.
- Cada frase nova gasta crédito. O app guarda o áudio já gerado e o Vercel também.
- Para gerar o MP3 do boletim para o pitch: `python scripts/gerar_audio.py boletim.txt boletim.mp3`.
- Só clone a voz de alguém que **autorizou**. O app mostra "Voz gerada por IA" na rádio.

## Ética e privacidade (critério eliminatório)

- Nome e localização exata ficam **só no aparelho** (localStorage). Para o servidor vai só o município, ou a localização arredondada (~11 km) no caso do tempo. O fogo, sem o Vercel, nem manda localização (baixa o arquivo do Brasil).
- **Satélite:** vai só um quadrado de ~2,5 km em volta de um ponto arredondado (~1 km). O recorte da área é feito no celular.
- **Nada de dado inventado:** sem resposta, a tela diz "sem informação agora".
- A distância até o fogo é calculada **no celular**.
- A foto da folha vai **reduzida (512 px)** para a API da IA só para ser analisada. O app não guarda a foto nem manda nome ou localização junto.
- A IA mostra sempre **3 possibilidades**, nunca certeza, e o botão **Chamar técnico**.

## Publicar (Vercel)

```
npm i -g vercel
vercel        # na pasta do projeto
```

Pronto: o app fica em HTTPS (a voz funciona) e as funções `/api/clima` e `/api/fogo` passam a existir.

## Velocidade e visual

- **Troca de tela instantânea:** nenhuma tela espera a internet para abrir. O satélite abre com o quadro vazio e se completa sozinho.
- **Resultado guardado no aparelho** (`js/api/index.js`): tempo e fogo valem 30 min, plantio e produtos 7 dias, satélite 6 h. Sem internet, mostra o último valor salvo (com aviso). Nada sai do celular.
- **Tempo máximo por API:** tempo 6 s, fogo 20 s, satélite 40 s. Passou disso, usa o último valor salvo ou diz "sem informação agora".
- **Visual:** verde #006633, **títulos em Poppins e todo o resto em Cambria**, botões de canto 10 px com sombra, menu com o item atual em pílula verde. A Cambria vem no Windows; no celular (que não tem Cambria) entra a **Caladea**, fonte livre com as mesmas medidas. As cores ficam em `:root` no começo de `css/estilo.css`.

## Fontes de dados

ZARC (MAPA, dados.agricultura.gov.br) · Sentinel-2 (Copernicus, via Microsoft Planetary Computer) · Open-Meteo · INPE Queimadas · IBGE (municípios) · INMET · NASA POWER/FIRMS (reserva). Fontes de letra: Poppins (títulos) e Caladea (no lugar da Cambria, quando o aparelho não tem), licença OFL, em `fontes/`.
