"""
Gera um MP3 com a VOZ CLONADA da ElevenLabs (ex.: o boletim da rádio para tocar no pitch).

1) Na tela Rádio do app, clique em "Baixar texto" (salva o boletim .txt).
2) No terminal (a chave NÃO vai para o código, fica só na variável de ambiente):
     Windows (PowerShell):
       $env:ELEVENLABS_API_KEY="sua-chave"
       $env:ELEVENLABS_VOICE_ID="id-da-voz"
       python scripts/gerar_audio.py boletim.txt boletim.mp3
3) Pronto: boletim.mp3 tem a voz clonada lendo o boletim.

Também aceita o texto direto:  python scripts/gerar_audio.py "Bom dia, produtor!" teste.mp3
"""
import json, os, sys, urllib.request

if len(sys.argv) < 3:
    sys.exit('Uso: python scripts/gerar_audio.py "texto ou arquivo.txt" saida.mp3')

chave = os.environ.get("ELEVENLABS_API_KEY")
voz = os.environ.get("ELEVENLABS_VOICE_ID")
if not chave or not voz:
    sys.exit("Defina ELEVENLABS_API_KEY e ELEVENLABS_VOICE_ID (veja o topo deste arquivo).")

entrada = sys.argv[1]
texto = open(entrada, encoding="utf-8").read() if os.path.isfile(entrada) else entrada

req = urllib.request.Request(
    f"https://api.elevenlabs.io/v1/text-to-speech/{voz}?output_format=mp3_44100_128",
    data=json.dumps({
        "text": texto.strip(),
        "model_id": os.environ.get("ELEVENLABS_MODEL", "eleven_multilingual_v2"),
        "voice_settings": {"stability": 0.5, "similarity_boost": 0.8},
    }).encode("utf-8"),
    headers={"xi-api-key": chave, "Content-Type": "application/json", "Accept": "audio/mpeg"},
    method="POST",
)
with urllib.request.urlopen(req) as r, open(sys.argv[2], "wb") as f:
    f.write(r.read())
print(f"OK: {sys.argv[2]} ({len(texto)} caracteres)")
