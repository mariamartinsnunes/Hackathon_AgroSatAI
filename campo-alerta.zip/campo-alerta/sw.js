// Guarda as telas para abrir sem internet (dados ficam no último valor buscado)
const CACHE = 'campo-alerta-v1';
const ARQUIVOS = ['./', 'index.html', 'css/estilo.css', 'js/app.js', 'img/icone.svg'];
self.addEventListener('install', (e) => e.waitUntil(caches.open(CACHE).then((c) => c.addAll(ARQUIVOS))));
self.addEventListener('fetch', (e) => {
  if (e.request.method !== 'GET' || new URL(e.request.url).pathname.startsWith('/api/')) return;
  e.respondWith(
    fetch(e.request).then((r) => { const copia = r.clone(); caches.open(CACHE).then((c) => c.put(e.request, copia)); return r; })
      .catch(() => caches.match(e.request))
  );
});
