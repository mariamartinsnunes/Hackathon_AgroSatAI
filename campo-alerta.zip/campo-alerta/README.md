# Campo Alerta

App (celular e computador) que avisa o pequeno produtor de café sobre tempo, plantio, fogo e doença na folha, por voz. Tem também um boletim de 1 minuto para a rádio e um "0800" para celular de botão.
Feito para o Hackathon de Dados Abertos (IFSP Araraquara, 2026).

## Rodar no VS Code

1. Abra esta pasta no VS Code (Arquivo > Abrir pasta).
2. Instale a extensão **Live Server** e clique em **Go Live** (canto de baixo).
   Ou rode no terminal: `npm run dev`. Depois abra http://localhost:3000
3. Use o **Chrome ou o Edge**. São os navegadores que ouvem a voz.

> Não abra o `index.html` com dois cliques: os módulos JS precisam de um servidor.

## Onde mexer

| Quero... | Arquivo |
|---|---|
| Trocar de API (mock → real) | `js/config.js` |
| Mudar textos dos avisos, semáforo, boletim | `js/regras.js` |
| Mudar uma tela | `js/telas/<tela>.js` |
| Mudar cores e tamanhos | `css/estilo.css` (topo: `:root`) |
| Palavras que a voz entende | `js/voz.js` (lista `INTENCOES`) |

## APIs: como trocar sem quebrar nada

Cada serviço tem vários **provedores**, e todos devolvem **o mesmo formato**. As telas nunca chamam uma API direto: elas chamam `js/api/index.js`.

```js
// js/config.js
provedores: {
  clima: 'mock',     // 'inmet' | 'nasa'
  fogo: 'mock',      // 'inpe'  | 'firms'
  plantio: 'mock',   // 'zarc'
  produtos: 'mock',  // 'agrofit'
  ia: 'mock',        // 'teachable'
}
```

- Se o provedor real falhar, o app usa o **mock** e mostra a etiqueta "Dados de exemplo". Assim a demo nunca fica em branco.
- Para testar outra API: crie mais uma função em `js/api/<servico>.js` que devolva o mesmo formato e coloque o nome dela no `config.js`.
- **INMET e INPE** passam pelas funções do Vercel (`api/clima.js` e `api/fogo.js`), por causa de CORS. Elas só funcionam com o projeto publicado no Vercel (ou rodando `vercel dev`).
- **ZARC e Agrofit** viram JSON pequenos, gerados pelos scripts:
  ```
  python scripts/gerar_zarc.py "dados-abertos-tabua-de-risco-safra-perene-olericola-sem-safra.csv"
  python scripts/gerar_agrofit.py "Produto Formulado.CSV"
  ```
  Os scripts mostram os nomes das colunas. Se não acharem alguma, ajustem o nome no script.
- **IA da folha**: veja `modelo/LEIA.md` (Teachable Machine).

## Voz: como funciona

**O app fala (lê a tela).** Todo texto que deve ser lido tem o atributo `data-ler`:

```html
<h2 data-ler>Espere</h2>                       <!-- lê o texto -->
<a data-ler="Fogo a 4 quilômetros">…</a>        <!-- lê o que está no atributo -->
```

O botão amarelo **Ouvir** junta, em ordem, tudo que tem `data-ler` e fala com `speechSynthesis` (voz pt-BR do sistema, funciona sem internet). Tela nova = é só marcar o que deve ser lido.

**O app ouve (comandos).** O botão **Falar** usa `SpeechRecognition` (Chrome/Edge, precisa de internet e HTTPS; `localhost` também vale). O que a pessoa fala passa por `entender()` em `js/voz.js`, que procura palavras-chave:

| Fala | Faz |
|---|---|
| "vai chover?", "tempo", "calor" | responde o tempo |
| "posso plantar?", "muda" | responde o semáforo do plantio |
| "tem fogo?", "queimada" | responde o fogo mais perto |
| "folha doente", "mancha", "ferrugem" | abre a foto da folha |
| "aviso", "rádio", "ligar", "voltar" | abre a tela |

Os 4 botões de exemplo na tela Falar funcionam como se a pessoa tivesse falado. Se o microfone falhar no pitch, toque neles.

## Ética e privacidade (critério eliminatório)

- Nome e localização exata ficam **só no aparelho** (localStorage). Para o servidor vai só o município, ou a localização arredondada (~11 km) no caso do fogo.
- A distância até o fogo é calculada **no celular**.
- A foto da folha **não sai do celular**: o modelo roda no navegador.
- A IA mostra sempre **3 possibilidades**, nunca certeza, e o botão **Chamar técnico**.
- Agrofit: só **contagem** de produtos registrados. Nunca nome com dose. Aviso de receituário agronômico.

## Publicar (Vercel)

```
npm i -g vercel
vercel        # na pasta do projeto
```

Pronto: o app fica em HTTPS (a voz funciona) e as funções `/api/clima` e `/api/fogo` passam a existir.

## Fontes de dados

ZARC e Agrofit (MAPA, dados.agricultura.gov.br) · INPE Queimadas · INMET · NASA POWER/FIRMS (reserva). Fontes de letra: Bricolage Grotesque e Atkinson Hyperlegible (licença OFL).
