// Função do Vercel: /api/clima?fonte=inmet&geocodigo=3503208
//                   /api/clima?fonte=nasa&lat=-21.8&lon=-48.2
// Devolve sempre o MESMO formato (ver js/api/clima.js).

const DIAS = ['domingo', 'segunda', 'terça', 'quarta', 'quinta', 'sexta', 'sábado'];

function ceuDoTexto(t = '') {
  if (/chuv|pancad|tempest|garoa/i.test(t)) return 'chuva';
  if (/nubl|nuve|encobert/i.test(t)) return 'nuvem';
  return 'sol';
}
const frase = (ceu, max) => (ceu === 'chuva' ? 'Chuva' : ceu === 'nuvem' ? 'Nublado' : max >= 33 ? 'Sol forte' : 'Sol');

// INMET — previsão por município (código IBGE).
// ATENÇÃO: conferir o formato real da resposta no hackathon (abrir a URL no navegador).
// A previsão do INMET não traz milímetros: dia com "chuva" no texto conta como 5 mm.
async function inmet(geocodigo) {
  const r = await fetch(`https://apiprevmet3.inmet.gov.br/previsao/${geocodigo}`);
  if (!r.ok) throw new Error('INMET respondeu ' + r.status);
  const j = await r.json();
  const porData = j[geocodigo] || Object.values(j)[0];
  const dias = Object.entries(porData).map(([data, v]) => {
    const o = v.tarde || v.manha || v.noite || v;   // dias próximos vêm por período
    const max = Number(o.temp_max), min = Number(o.temp_min);
    const ceu = ceuDoTexto(o.resumo);
    const [dd, mm, aa] = data.split('/').map(Number);
    return { nome: DIAS[new Date(aa, mm - 1, dd).getDay()], ceu, max, min, chuvaMm: ceu === 'chuva' ? 5 : 0, resumo: o.resumo };
  });
  const [h, ...prox] = dias;
  return { hoje: { max: h.max, min: h.min, chuvaMm: h.chuvaMm, ceu: h.ceu, frase: frase(h.ceu, h.max) }, dias: prox, fonte: 'INMET' };
}

// NASA POWER — dados dos últimos dias (não é previsão). Usado só como reserva.
async function nasa(lat, lon) {
  const fim = new Date(), ini = new Date(Date.now() - 10 * 864e5);
  const f = (d) => d.toISOString().slice(0, 10).replace(/-/g, '');
  const url = `https://power.larc.nasa.gov/api/temporal/daily/point?parameters=T2M_MAX,T2M_MIN,PRECTOTCORR&community=AG&latitude=${lat}&longitude=${lon}&start=${f(ini)}&end=${f(fim)}&format=JSON`;
  const r = await fetch(url);
  if (!r.ok) throw new Error('NASA POWER respondeu ' + r.status);
  const p = (await r.json()).properties.parameter;
  const datas = Object.keys(p.T2M_MAX).filter((d) => p.T2M_MAX[d] > -900).sort();
  const ult = datas.at(-1);
  const max = Math.round(p.T2M_MAX[ult]), min = Math.round(p.T2M_MIN[ult]), chuvaMm = Math.round(p.PRECTOTCORR[ult]);
  const ceu = chuvaMm >= 2 ? 'chuva' : 'sol';
  return { hoje: { max, min, chuvaMm, ceu, frase: frase(ceu, max) }, dias: [], fonte: 'NASA POWER (último dia medido)' };
}

export default async function handler(req, res) {
  try {
    const { fonte = 'inmet', geocodigo, lat, lon } = req.query;
    const dados = fonte === 'nasa' ? await nasa(Number(lat), Number(lon)) : await inmet(String(geocodigo));
    res.setHeader('Cache-Control', 's-maxage=3600, stale-while-revalidate=7200');
    res.status(200).json(dados);
  } catch (e) {
    res.status(502).json({ erro: e.message });
  }
}
