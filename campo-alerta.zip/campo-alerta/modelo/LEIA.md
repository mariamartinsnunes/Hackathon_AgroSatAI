# Modelo da IA (Teachable Machine)

1. Abra teachablemachine.withgoogle.com > Projeto de imagem > Modelo padrão.
2. Crie 4 classes com ESTES nomes: ferrugem, cercosporiose, bicho-mineiro, saudavel
3. Coloque as fotos (Digipathos/Embrapa e fotos de vocês). Treine.
4. Exportar > TensorFlow.js > Baixar. Coloque model.json, metadata.json e weights.bin nesta pasta.
5. No js/config.js troque  ia: 'mock'  por  ia: 'teachable'.
