// FOGO VISTO POR SATÉLITE — todo provedor devolve:
// { focos: [{ lat, lon, quando }], fonte }
// A distância até a roça é calculada NO APARELHO (a localização exata não sai dele).
import { CONFIG } from '../config.js';
import { arredondar } from '../util.js';

export const provedores = {
  async mock({ centro }) {
    // Um foco a ~4 km a nordeste e outro mais longe, só para a demo
    return {
      focos: [
        { lat: centro.lat + 0.026, lon: centro.lon + 0.026, quando: 'hoje cedo' },
        { lat: centro.lat - 0.15, lon: centro.lon - 0.12, quando: 'ontem' },
      ],
      fonte: 'Exemplo',
    };
  },

  // INPE Queimadas — CSV diário, sem chave. Passa por /api/fogo (CORS).
  async inpe({ centro }) {
    const q = `lat=${arredondar(centro.lat)}&lon=${arredondar(centro.lon)}&raio=${CONFIG.raioFogoKm + 15}`;
    const r = await fetch(`${CONFIG.baseApi}/api/fogo?fonte=inpe&${q}`);
    if (!r.ok) throw new Error('INPE fora do ar');
    return r.json();
  },

  // NASA FIRMS — reserva. Precisa de chave grátis (CONFIG.firmsKey).
  async firms({ centro }) {
    const q = `lat=${arredondar(centro.lat)}&lon=${arredondar(centro.lon)}&raio=${CONFIG.raioFogoKm + 15}&key=${CONFIG.firmsKey}`;
    const r = await fetch(`${CONFIG.baseApi}/api/fogo?fonte=firms&${q}`);
    if (!r.ok) throw new Error('FIRMS fora do ar');
    return r.json();
  },
};
