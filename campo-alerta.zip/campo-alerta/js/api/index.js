// Porta única de dados. As telas só chamam estas funções —
// nunca uma API direto. Para trocar de API, mude js/config.js.
import { CONFIG } from '../config.js';
import * as clima from './clima.js';
import * as fogo from './fogo.js';
import * as plantio from './plantio.js';
import * as produtos from './produtos.js';
import * as ia from './ia.js';

const SERVICOS = { clima, fogo, plantio, produtos, ia };
const cache = new Map();

async function chamar(servico, ctx, { guardar = true } = {}) {
  const nome = CONFIG.provedores[servico] || 'mock';
  const chave = `${servico}:${nome}:${ctx?.municipio?.geocodigo || ''}`;
  if (guardar && cache.has(chave)) return cache.get(chave);

  const lista = SERVICOS[servico].provedores;
  let resultado;
  try {
    resultado = await lista[nome](ctx);
    if (Array.isArray(resultado)) resultado = { itens: resultado };
    resultado.exemplo = nome === 'mock';
  } catch (erro) {
    if (!CONFIG.usarMockSeFalhar || nome === 'mock') throw erro;
    console.warn(`[${servico}] ${nome} falhou, usando exemplo:`, erro.message);
    resultado = await lista.mock(ctx);
    if (Array.isArray(resultado)) resultado = { itens: resultado };
    resultado.exemplo = true;
  }
  if (guardar) cache.set(chave, resultado);
  return resultado;
}

// ctx = { municipio, centro } — centro é a localização da roça (só usada no aparelho)
export const buscarClima = (ctx) => chamar('clima', ctx);
export const buscarFogo = (ctx) => chamar('fogo', ctx);
export const buscarPlantio = (ctx) => chamar('plantio', ctx);
export const buscarProdutos = (ctx) => chamar('produtos', ctx);
export const diagnosticar = async (imagem) => (await chamar('ia', { imagem }, { guardar: false })).itens;

export function limparCache() { cache.clear(); }
