// IA DA FOLHA — todo provedor recebe uma <img> e devolve
// [{ id, prob }] em ordem (a maior primeiro). A foto NÃO sai do celular.
import { CONFIG } from '../config.js';

function carregarScript(src) {
  return new Promise((ok, erro) => {
    if (document.querySelector(`script[src="${src}"]`)) return ok();
    const s = document.createElement('script');
    s.src = src; s.onload = ok; s.onerror = () => erro(new Error('Não carregou ' + src));
    document.head.appendChild(s);
  });
}

let modelo = null;

export const provedores = {
  async mock() {
    await new Promise((r) => setTimeout(r, 1200)); // finge que está pensando
    return [
      { id: 'ferrugem', prob: 0.62 },
      { id: 'cercosporiose', prob: 0.24 },
      { id: 'bicho-mineiro', prob: 0.09 },
      { id: 'saudavel', prob: 0.05 },
    ];
  },

  // Teachable Machine (imagem). Exportem como "TensorFlow.js" e coloquem
  // model.json, metadata.json e weights.bin em /modelo (ou usem o link do upload).
  // Os nomes das classes precisam ser: ferrugem, cercosporiose, bicho-mineiro, saudavel
  async teachable({ imagem }) {
    if (!modelo) {
      await carregarScript('https://cdn.jsdelivr.net/npm/@tensorflow/tfjs@1.3.1/dist/tf.min.js');
      await carregarScript('https://cdn.jsdelivr.net/npm/@teachablemachine/image@0.8/dist/teachablemachine-image.min.js');
      const url = CONFIG.modeloIA.endsWith('/') ? CONFIG.modeloIA : CONFIG.modeloIA + '/';
      modelo = await window.tmImage.load(url + 'model.json', url + 'metadata.json');
    }
    const saida = await modelo.predict(imagem);
    return saida
      .map((c) => ({ id: c.className.trim().toLowerCase(), prob: c.probability }))
      .sort((a, b) => b.prob - a.prob);
  },
};
