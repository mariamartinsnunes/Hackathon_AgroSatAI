// PLANTIO (ZARC / MAPA) — todo provedor devolve:
// { riscos: [36 números], fonte }
// Um número por decêndio do ano: 20 = risco baixo, 30 = médio, 40 = alto, 0 = não indicado.
// Para café (perene) o ZARC indica a época de plantar as MUDAS.

export const provedores = {
  async mock() {
    const riscos = Array.from({ length: 36 }, (_, i) => {
      const dec = i + 1;
      if (dec >= 28 || dec <= 3) return 20;  // out a jan: boa época (chuvas)
      if (dec === 27 || dec === 4) return 30;
      return 0;
    });
    return { riscos, fonte: 'Exemplo' };
  },

  // Lê o JSON gerado pelo script scripts/gerar_zarc.py
  async zarc({ municipio }) {
    const r = await fetch('dados/zarc-cafe.json');
    if (!r.ok) throw new Error('Arquivo do ZARC não encontrado');
    const tabela = await r.json();
    const riscos = tabela.municipios?.[municipio.geocodigo];
    if (!riscos) throw new Error(`ZARC sem café para ${municipio.nome}`);
    return { riscos, fonte: `ZARC/MAPA ${tabela.safra || ''}`.trim() };
  },
};
