// PRODUTOS REGISTRADOS (Agrofit / MAPA) — todo provedor devolve:
// { porPraga: { 'Hemileia vastatrix': { total, organicos, biologicos } }, fonte }
// Regra de ética: NUNCA mostrar dose nem recomendar produto. Só contagem + "fale com o técnico".

export const provedores = {
  async mock() {
    return {
      porPraga: {
        'Hemileia vastatrix': { total: 40, organicos: 6, biologicos: 5 },
        'Cercospora coffeicola': { total: 30, organicos: 4, biologicos: 3 },
        'Leucoptera coffeella': { total: 50, organicos: 7, biologicos: 6 },
      },
      fonte: 'Exemplo',
    };
  },

  // Lê o JSON gerado pelo script scripts/gerar_agrofit.py
  async agrofit() {
    const r = await fetch('dados/agrofit-cafe.json');
    if (!r.ok) throw new Error('Arquivo do Agrofit não encontrado');
    const d = await r.json();
    return { porPraga: d.porPraga, fonte: `Agrofit/MAPA ${d.atualizado || ''}`.trim() };
  },
};
