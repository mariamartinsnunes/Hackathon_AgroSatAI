// CLIMA — todo provedor devolve o MESMO formato:
// { hoje: { max, min, chuvaMm, ceu: 'sol'|'nuvem'|'chuva', frase },
//   dias: [{ nome, ceu, max, chuvaMm }],  // próximos dias
//   fonte }
import { CONFIG } from '../config.js';
import { DIAS } from '../util.js';

function proximosNomes(n) {
  const hoje = new Date().getDay();
  return Array.from({ length: n }, (_, i) => DIAS[(hoje + i + 1) % 7]);
}

export const provedores = {
  async mock() {
    const nomes = proximosNomes(5);
    return {
      hoje: { max: 34, min: 19, chuvaMm: 0, ceu: 'sol', frase: 'Sol forte' },
      dias: [
        { nome: nomes[0], ceu: 'sol', max: 35, chuvaMm: 0 },
        { nome: nomes[1], ceu: 'nuvem', max: 33, chuvaMm: 0 },
        { nome: nomes[2], ceu: 'chuva', max: 27, chuvaMm: 8 },
        { nome: nomes[3], ceu: 'nuvem', max: 29, chuvaMm: 2 },
        { nome: nomes[4], ceu: 'chuva', max: 26, chuvaMm: 6 },
      ],
      fonte: 'Exemplo',
    };
  },

  // INMET (governo) — passa pela função /api/clima por causa de CORS.
  // Só manda o código do município, nunca a localização exata.
  async inmet({ municipio }) {
    const r = await fetch(`${CONFIG.baseApi}/api/clima?fonte=inmet&geocodigo=${municipio.geocodigo}`);
    if (!r.ok) throw new Error('INMET fora do ar');
    return r.json();
  },

  // NASA POWER — reserva. Usa localização grossa (~11 km).
  async nasa({ municipio }) {
    const r = await fetch(`${CONFIG.baseApi}/api/clima?fonte=nasa&lat=${municipio.lat}&lon=${municipio.lon}`);
    if (!r.ok) throw new Error('NASA POWER fora do ar');
    return r.json();
  },
};
