// O que a IA da folha sabe reconhecer (mesmos nomes das classes do Teachable Machine)
export const PROBLEMAS = {
  ferrugem: {
    nome: 'Ferrugem', cientifico: 'Hemileia vastatrix',
    sinal: 'Pó alaranjado embaixo da folha',
  },
  cercosporiose: {
    nome: 'Olho-pardo', cientifico: 'Cercospora coffeicola',
    sinal: 'Mancha marrom com centro claro',
  },
  'bicho-mineiro': {
    nome: 'Bicho-mineiro', cientifico: 'Leucoptera coffeella',
    sinal: 'Mancha seca que descasca',
  },
  saudavel: {
    nome: 'Folha saudável', cientifico: '',
    sinal: 'Não vimos problema',
  },
};
