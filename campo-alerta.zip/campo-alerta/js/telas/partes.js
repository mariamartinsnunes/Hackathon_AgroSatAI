// Pedaços de tela usados em todo lugar
import { icone } from '../icones.js';
import { esc } from '../util.js';

export function botaoOuvir(texto = 'Ouvir') {
  return `<button type="button" class="ouvir" data-acao="ouvir" aria-label="Ouvir esta tela">
    ${icone('som', 28)}<span>${texto}</span></button>`;
}

// Cabeçalho "horizonte": faixa verde com o morro da roça embaixo.
// ceu: 'sol' | 'nuvem' | 'chuva' | 'fogo' — muda o desenho do céu.
export function horizonte({ titulo, sub = '', ceu = 'sol', voltar = null, lerTitulo = true }) {
  return `
  <header class="horizonte" data-ceu="${ceu}">
    <div class="horizonte-topo">
      ${voltar ? `<a class="voltar" href="#/${voltar}" aria-label="Voltar">${icone('voltar', 28)}</a>` : ''}
      <div class="horizonte-texto">
        <h1 ${lerTitulo ? 'data-ler' : ''}>${titulo}</h1>
        ${sub ? `<p>${sub}</p>` : ''}
      </div>
      ${botaoOuvir()}
    </div>
    <svg class="morro" viewBox="0 0 400 60" preserveAspectRatio="none" aria-hidden="true">
      <path class="morro-fundo" d="M0 38 C60 18 120 22 180 34 C240 46 300 20 400 26 L400 60 L0 60Z"/>
      <path class="morro-frente" d="M0 50 C80 34 150 40 220 50 C290 60 340 42 400 44 L400 60 L0 60Z"/>
    </svg>
  </header>`;
}

export function etiquetaExemplo(exemplo, fonte) {
  if (exemplo) return `<p class="fonte fonte-exemplo">${icone('info', 18)} Dados de exemplo</p>`;
  return fonte ? `<p class="fonte">Fonte: ${esc(fonte)}</p>` : '';
}
