import { icone } from '../icones.js';
import { falar, pararDeFalar } from '../voz.js';
import { gerarBoletim } from '../regras.js';
import { horizonte } from './partes.js';

// SIMULAÇÃO da URA ("aperte 1 para..."). No produto real isto roda numa
// central telefônica (ex.: Twilio/Zenvia) e toca o mesmo texto/áudio.
const MENU = 'Olá! Aqui é o Campo Alerta. Aperte 1 para o tempo. Aperte 2 para o plantio do café. Aperte 3 para alerta de fogo. Aperte 4 para o boletim completo.';

export default {
  titulo: 'Ligar',

  render() {
    const teclas = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '*', '0', '#'];
    return `
    ${horizonte({ titulo: 'Ouvir pelo telefone', sub: 'Para celular de botão' })}
    <div class="pagina pagina-estreita">
      <div class="celular-botao">
        <div class="celular-tela" aria-live="polite">
          <span class="celular-numero" data-visor>0800 Campo Alerta</span>
          <span class="celular-status" data-status>Toque em ligar</span>
        </div>
        <div class="teclado">
          ${teclas.map((t) => `<button type="button" class="tecla" data-tecla="${t}">${t}</button>`).join('')}
        </div>
        <div class="celular-chamada">
          <button type="button" class="chamar" data-ligar aria-label="Ligar">${icone('telefone', 34)}</button>
          <button type="button" class="desligar" data-desligar aria-label="Desligar">${icone('telefone', 34)}</button>
        </div>
      </div>
      <p class="nota" data-ler="No produto real, o produtor dá um toque e desliga. O Campo Alerta liga de volta, de graça.">
        Simulação. No produto real, o produtor dá um toque e desliga: o Campo Alerta liga de volta, de graça.
      </p>
    </div>`;
  },

  montar(el, app) {
    const status = el.querySelector('[data-status]');
    let naLinha = false;

    el.querySelector('[data-ligar]').addEventListener('click', async () => {
      naLinha = true;
      status.textContent = 'Chamando…';
      await new Promise((r) => setTimeout(r, 700));
      if (!naLinha) return;
      status.textContent = 'Em ligação';
      falar(MENU);
    });

    el.querySelector('[data-desligar]').addEventListener('click', () => {
      naLinha = false; pararDeFalar(); status.textContent = 'Ligação encerrada';
    });

    el.querySelectorAll('[data-tecla]').forEach((b) => b.addEventListener('click', async () => {
      if (!naLinha) { status.textContent = 'Toque em ligar primeiro'; return; }
      const d = await app.dados();
      const h = d.clima.hoje;
      const chuva = d.clima.dias.find((x) => x.chuvaMm >= 5);
      const respostas = {
        1: `Tempo: ${h.frase.toLowerCase()}, ${h.max} graus. ${chuva ? `Chuva na ${chuva.nome}.` : 'Sem chuva forte nos próximos dias.'}`,
        2: `Café: ${d.plantio.titulo.toLowerCase()}. ${d.plantio.detalhe}.`,
        3: d.fogo ? `Atenção: fogo a ${d.fogo.kmTexto}, para o ${d.fogo.direcao}. Viu fogo? Ligue 193.` : 'Nenhum fogo perto.',
        4: gerarBoletim(d).texto,
      };
      status.textContent = `Você apertou ${b.dataset.tecla}`;
      falar(respostas[b.dataset.tecla] || MENU);
    }));
  },
};
