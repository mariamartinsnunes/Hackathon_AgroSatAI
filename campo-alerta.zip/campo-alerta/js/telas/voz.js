import { icone } from '../icones.js';
import { ouvir, falar, entender, podeOuvir } from '../voz.js';
import { gerarAvisos } from '../regras.js';
import { esc } from '../util.js';

// Respostas faladas para cada intenção
async function responder(intencao, app) {
  const d = await app.dados();
  const h = d.clima.hoje;
  const chuva = d.clima.dias.find((x) => x.chuvaMm >= 5);
  switch (intencao) {
    case 'tempo':
      return { texto: `Hoje: ${h.frase.toLowerCase()}, ${h.max} graus. ${chuva ? `Chuva na ${chuva.nome}.` : 'Sem chuva forte nos próximos dias.'}` };
    case 'plantio':
      return { texto: `Café: ${d.plantio.titulo.toLowerCase()}. ${d.plantio.detalhe}.` };
    case 'fogo':
      return { texto: d.fogo ? `Atenção. Fogo a ${d.fogo.kmTexto}, para o ${d.fogo.direcao}. Se chegar perto, ligue 193.` : 'Nenhum fogo perto da sua roça.' };
    case 'avisos': {
      const a = gerarAvisos(app.perfil, d)[0];
      return { texto: `${a.titulo}. ${a.detalhe}`, ir: 'avisos' };
    }
    case 'foto': return { texto: 'Vamos tirar a foto da folha.', ir: 'foto' };
    case 'radio': return { texto: 'Abrindo o boletim da rádio.', ir: 'radio' };
    case 'ligar': return { texto: 'Abrindo o telefone.', ir: 'ligar' };
    case 'inicio': return { texto: 'Voltando ao início.', ir: 'painel' };
    default:
      return { texto: 'Não entendi. Fale: vai chover, posso plantar, tem fogo, ou foto da folha.' };
  }
}

const EXEMPLOS = [
  { frase: 'Vai chover?', icone: 'chuva' },
  { frase: 'Posso plantar?', icone: 'calendario' },
  { frase: 'Tem fogo perto?', icone: 'fogo' },
  { frase: 'Minha folha tá doente', icone: 'folha' },
];

export default {
  titulo: 'Falar',

  render() {
    return `
    <section class="voz">
      <a class="voz-fechar" href="#/painel">${icone('x', 26)} Fechar</a>
      <h1 class="voz-titulo" data-estado>Toque e fale</h1>
      <button type="button" class="voz-mic" data-mic aria-label="Tocar para falar">
        <span class="voz-onda"></span><span class="voz-onda"></span>
        <span class="voz-mic-centro">${icone('mic', 72)}</span>
      </button>
      <p class="voz-ouvido" data-ouvido aria-live="polite"></p>
      <div class="voz-resposta" data-resposta hidden></div>
      <div class="voz-exemplos">
        ${EXEMPLOS.map((e) => `<button type="button" class="voz-exemplo" data-frase="${e.frase}">${icone(e.icone, 26)}<span>${e.frase}</span></button>`).join('')}
      </div>
    </section>`;
  },

  montar(el, app) {
    const estado = el.querySelector('[data-estado]');
    const ouvido = el.querySelector('[data-ouvido]');
    const caixa = el.querySelector('[data-resposta]');

    async function tratar(frases) {
      ouvido.textContent = `“${frases[0]}”`;
      const { ir } = entender(frases);
      const r = await responder(ir, app);
      caixa.hidden = false;
      caixa.innerHTML = `<p>${esc(r.texto)}</p>`;
      estado.textContent = 'Toque e fale';
      await falar(r.texto);
      if (r.ir) app.ir(r.ir);
    }

    el.querySelector('[data-mic]').addEventListener('click', async () => {
      if (!podeOuvir()) {
        estado.textContent = 'Toque numa pergunta';
        return falar('Este navegador não consegue ouvir. Toque numa das perguntas.');
      }
      estado.textContent = 'Ouvindo…';
      try { await tratar(await ouvir()); }
      catch (e) {
        estado.textContent = 'Toque e fale';
        if (e.message === 'not-allowed') falar('Libere o microfone para eu ouvir.');
        else falar('Não ouvi. Toque e fale de novo.');
      }
    });

    // Os exemplos funcionam como se a pessoa tivesse falado (ótimo para a demo)
    el.querySelectorAll('[data-frase]').forEach((b) =>
      b.addEventListener('click', () => tratar([b.dataset.frase.toLowerCase()])));
  },
};
