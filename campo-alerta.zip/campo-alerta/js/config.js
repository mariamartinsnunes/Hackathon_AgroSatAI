// ============================================================
//  CONFIGURAÇÃO — o único arquivo que vocês precisam mexer
//  para trocar de API. Cada serviço tem vários "provedores".
//  'mock' = dados de exemplo (funciona sem internet, bom pra demo).
// ============================================================

export const CONFIG = {
  provedores: {
    clima: 'mock',     // 'mock' | 'inmet' | 'nasa'
    fogo: 'mock',      // 'mock' | 'inpe'  | 'firms'
    plantio: 'mock',   // 'mock' | 'zarc'   (lê dados/zarc-cafe.json)
    produtos: 'mock',  // 'mock' | 'agrofit' (lê dados/agrofit-cafe.json)
    ia: 'mock',        // 'mock' | 'teachable'
  },

  // Se um provedor real falhar, o app cai automaticamente no 'mock'
  // e mostra a etiqueta "dados de exemplo". Nunca fica tela em branco.
  usarMockSeFalhar: true,

  // Endereço das funções do Vercel (pasta /api). Em produção fica ''.
  // Rodando local com Live Server, as funções não existem: use mock.
  baseApi: '',

  // Teachable Machine: cole aqui o link do modelo exportado
  // (ou deixe './modelo/' se colocar os arquivos na pasta modelo).
  modeloIA: './modelo/',

  // NASA FIRMS (reserva do fogo). Chave grátis: firms.modaps.eosdis.nasa.gov/api/map_key
  firmsKey: '',

  // Raio (km) para avisar fogo perto da roça
  raioFogoKm: 30,

  // El Niño 2026/27 ativo: deixa os avisos de plantio mais cautelosos
  elNino: true,

  // Contato do técnico (Emater / Casa da Agricultura / cooperativa)
  tecnico: { nome: 'Casa da Agricultura', telefone: '+5516999999999' },

  // Município usado quando a pessoa não libera a localização
  municipioPadrao: { nome: 'Araraquara', uf: 'SP', geocodigo: '3503208', lat: -21.79, lon: -48.18 },

  culturas: [
    { id: 'cafe', nome: 'Café', ativo: true },
    { id: 'milho', nome: 'Milho', ativo: false },
    { id: 'mandioca', nome: 'Mandioca', ativo: false },
    { id: 'feijao', nome: 'Feijão', ativo: false },
  ],
};
