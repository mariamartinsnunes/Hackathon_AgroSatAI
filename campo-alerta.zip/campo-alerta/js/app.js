import { lerPerfil, salvarPerfil } from './estado.js';
import { carregarTudo } from './regras.js';
import { icone, aplicarIcones } from './icones.js';
import { lerTela, pararDeFalar } from './voz.js';

import cadastro from './telas/cadastro.js';
import saber from './telas/saber.js';
import painel from './telas/painel.js';
import foto from './telas/foto.js';
import avisos from './telas/avisos.js';
import voz from './telas/voz.js';
import radio from './telas/radio.js';
import ligar from './telas/ligar.js';

const TELAS = { cadastro, saber, painel, foto, avisos, voz, radio, ligar };
const LIVRES = ['cadastro', 'saber']; // telas que abrem sem cadastro pronto

// Menus (celular embaixo, computador do lado)
const MENU_BARRA = [
  { rota: 'painel', nome: 'Início', icone: 'casa' },
  { rota: 'foto', nome: 'Foto', icone: 'camera' },
  { rota: 'voz', nome: 'Falar', icone: 'mic', central: true },
  { rota: 'avisos', nome: 'Avisos', icone: 'sino' },
  { rota: 'radio', nome: 'Rádio', icone: 'radio' },
];
const MENU_LATERAL = [
  { rota: 'painel', nome: 'Início', icone: 'casa' },
  { rota: 'foto', nome: 'Foto da folha', icone: 'camera' },
  { rota: 'avisos', nome: 'Avisos', icone: 'sino' },
  { rota: 'radio', nome: 'Rádio', icone: 'radio' },
  { rota: 'ligar', nome: 'Ligar', icone: 'telefone' },
];

const main = document.querySelector('#conteudo');

// Objeto compartilhado com todas as telas
export const app = {
  perfil: lerPerfil(),
  _dados: null,
  // Busca clima + fogo + plantio uma vez e reaproveita entre as telas
  dados() {
    if (!this._dados) this._dados = carregarTudo(this.perfil);
    return this._dados;
  },
  salvar(mudancas) {
    this.perfil = salvarPerfil(mudancas);
    this._dados = null;
  },
  ir(rota) { location.hash = '#/' + rota; },
};

function montarMenus(atual) {
  const barra = document.querySelector('[data-barra]');
  barra.innerHTML = MENU_BARRA.map((m) => `
    <a href="#/${m.rota}" class="${m.central ? 'barra-falar' : ''}" ${m.rota === atual ? 'aria-current="page"' : ''}>
      ${icone(m.icone, m.central ? 34 : 28)}<span>${m.nome}</span>
    </a>`).join('');

  document.querySelector('[data-menu]').innerHTML = MENU_LATERAL.map((m) => `
    <a href="#/${m.rota}" ${m.rota === atual ? 'aria-current="page"' : ''}>${icone(m.icone, 28)}<span>${m.nome}</span></a>`).join('');

  const semMenu = LIVRES.includes(atual) || atual === 'voz';
  document.body.classList.toggle('sem-menu', semMenu);
}

async function mostrar() {
  pararDeFalar();
  let rota = (location.hash.replace(/^#\/?/, '') || 'painel').split('?')[0];
  if (!TELAS[rota]) rota = 'painel';
  if (!app.perfil.pronto && !LIVRES.includes(rota)) rota = 'cadastro';

  const tela = TELAS[rota];
  document.title = `${tela.titulo} · Campo Alerta`;
  montarMenus(rota);
  main.dataset.tela = rota;
  main.innerHTML = '<div class="carregando" role="status">Carregando…</div>';

  try {
    main.innerHTML = await tela.render(app);
    aplicarIcones(main);
    await tela.montar?.(main, app);
  } catch (erro) {
    console.error(erro);
    main.innerHTML = `
      <section class="erro">
        <h1>Não deu para abrir esta tela</h1>
        <p>${erro.message}</p>
        <a class="botao" href="#/painel">Voltar ao início</a>
      </section>`;
  }
  main.focus({ preventScroll: true });
  window.scrollTo(0, 0);
}

// Botão "Ouvir" de qualquer tela: lê tudo que tem data-ler (ou para, se já estiver falando)
document.addEventListener('click', (e) => {
  const b = e.target.closest('[data-acao="ouvir"]');
  if (!b) return;
  if (document.body.classList.contains('falando')) pararDeFalar();
  else lerTela();
});

aplicarIcones(document);
window.addEventListener('hashchange', mostrar);
mostrar();

// Funciona offline depois da primeira visita (PWA)
if ('serviceWorker' in navigator && location.protocol === 'https:') {
  navigator.serviceWorker.register('sw.js').catch(() => {});
}
