"""
Gera dados/agrofit-cafe.json a partir do Agrofit (MAPA).

1) Baixe "Produto Formulado.CSV" em dados.agricultura.gov.br -> Agrofit
2) Rode:  python scripts/gerar_agrofit.py "caminho/Produto Formulado.CSV"
3) No js/config.js troque  produtos: 'mock'  por  produtos: 'agrofit'

Ética: guardamos SÓ contagens (total, orgânicos, biológicos).
Nada de nome comercial nem dose — quem indica é o técnico.
"""
import json, sys, datetime
import pandas as pd

PRAGAS = ["Hemileia vastatrix", "Cercospora coffeicola", "Leucoptera coffeella"]

if len(sys.argv) < 2:
    sys.exit('Uso: python scripts/gerar_agrofit.py "Produto Formulado.CSV"')

df = None
for enc in ("utf-8", "latin-1"):
    for sep in (";", ","):
        try:
            t = pd.read_csv(sys.argv[1], sep=sep, encoding=enc, low_memory=False, dtype=str)
            if t.shape[1] > 3:
                df = t; break
        except (UnicodeDecodeError, pd.errors.ParserError):
            continue
    if df is not None:
        break
print("Colunas encontradas:", list(df.columns))

def achar(*pedacos):
    for c in df.columns:
        if all(p in c.lower() for p in pedacos):
            return c
    return None

col_cultura = achar("cultura")
col_praga = achar("praga", "cient") or achar("cientif") or achar("praga")
col_registro = achar("registro") or achar("produto")
col_organico = achar("organ")
col_biologico = achar("biol") or achar("classe")

print("Cultura:", col_cultura, "| Praga:", col_praga, "| Registro:", col_registro,
      "| Orgânico:", col_organico, "| Biológico/classe:", col_biologico)
if not (col_cultura and col_praga):
    sys.exit("Não achei cultura/praga. Ajuste os nomes acima no script.")

cafe = df[df[col_cultura].str.contains("caf", case=False, na=False)]

def sim(serie):
    return serie.fillna("").str.strip().str.lower().isin(["sim", "s", "true", "1", "x"])

por_praga = {}
for praga in PRAGAS:
    linhas = cafe[cafe[col_praga].str.contains(praga, case=False, na=False)]
    # um produto pode aparecer várias vezes (várias pragas/culturas): conta registro único
    unico = linhas.drop_duplicates(subset=[col_registro]) if col_registro else linhas
    info = {"total": int(len(unico))}
    if col_organico:
        info["organicos"] = int(sim(unico[col_organico]).sum())
    if col_biologico:
        info["biologicos"] = int(unico[col_biologico].str.contains("biol", case=False, na=False).sum())
    por_praga[praga] = info
    print(praga, info)

with open("dados/agrofit-cafe.json", "w", encoding="utf-8") as f:
    json.dump({"fonte": "Agrofit (MAPA), dados.agricultura.gov.br",
               "atualizado": datetime.date.today().isoformat(),
               "porPraga": por_praga}, f, ensure_ascii=False, indent=2)
print("OK -> dados/agrofit-cafe.json")
