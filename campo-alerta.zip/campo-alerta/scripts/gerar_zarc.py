"""
Gera dados/zarc-cafe.json a partir da Tábua de Risco do ZARC (MAPA).

1) Baixe em dados.agricultura.gov.br -> "Zoneamento Agrícola de Risco Climático"
   o arquivo de culturas PERENES (café está nele), algo como:
   dados-abertos-tabua-de-risco-safra-perene-olericola-sem-safra.csv
2) Rode:  python scripts/gerar_zarc.py caminho/do/arquivo.csv
3) No js/config.js troque  plantio: 'mock'  por  plantio: 'zarc'

O script descobre as colunas sozinho e imprime o que achou.
Se algo der errado, ele mostra os nomes das colunas para vocês ajustarem.
"""
import json, re, sys
import pandas as pd

if len(sys.argv) < 2:
    sys.exit("Uso: python scripts/gerar_zarc.py ARQUIVO.csv")

df = None
for enc in ("utf-8", "latin-1"):
    try:
        df = pd.read_csv(sys.argv[1], sep=";", encoding=enc, low_memory=False)
        break
    except UnicodeDecodeError:
        continue
print("Colunas encontradas:", list(df.columns))

def achar(*pedacos):
    for c in df.columns:
        if all(p in c.lower() for p in pedacos):
            return c
    return None

col_cultura = achar("cultura") or achar("nome_cultura")
col_geo = achar("geocod") or achar("cod_ibge") or achar("ibge")
col_safra = achar("safra")
col_decs = sorted([c for c in df.columns if re.fullmatch(r"dec_?\s*\d{1,2}", c.strip().lower())],
                  key=lambda c: int(re.findall(r"\d+", c)[0]))

print("Cultura:", col_cultura, "| Município:", col_geo, "| Decêndios:", len(col_decs))
if not (col_cultura and col_geo and len(col_decs) == 36):
    sys.exit("Não achei as colunas. Ajuste os nomes acima no script.")

cafe = df[df[col_cultura].astype(str).str.contains("caf", case=False, na=False)].copy()
print("Linhas de café:", len(cafe))

# Vários solos/ciclos por município: ficamos com o MENOR risco de cada decêndio
# (o melhor caso). 0 ou vazio = não indicado.
cafe[col_decs] = cafe[col_decs].apply(pd.to_numeric, errors="coerce").fillna(0)
def melhor(serie):
    validos = [v for v in serie if v > 0]
    return int(min(validos)) if validos else 0

municipios = {}
for geo, grupo in cafe.groupby(col_geo):
    municipios[str(int(geo))] = [melhor(grupo[c]) for c in col_decs]

saida = {
    "fonte": "ZARC - Tábua de Risco (MAPA), dados.agricultura.gov.br",
    "safra": str(cafe[col_safra].iloc[0]) if col_safra and len(cafe) else "",
    "legenda": "20 = risco baixo, 30 = médio, 40 = alto, 0 = não indicado",
    "municipios": municipios,
}
with open("dados/zarc-cafe.json", "w", encoding="utf-8") as f:
    json.dump(saida, f, ensure_ascii=False)

print(f"OK: {len(municipios)} municípios com café -> dados/zarc-cafe.json")
print("Araraquara (3503208) tem café?", "3503208" in municipios)
