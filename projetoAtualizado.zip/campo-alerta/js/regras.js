// Transforma dados das APIs em frases curtas para o produtor.
// Todas as telas, a voz e o boletim da rádio usam estas mesmas regras.
import { CONFIG } from './config.js';
import { decendio, mesDoDecendio, distanciaKm, rumo, rumoEmPalavras, MESES } from './util.js';
import { buscarClima, buscarFogo, buscarPlantio, buscarLavoura } from './api/index.js';
import { compararPartes } from './satelite.js';

export function contexto(perfil) {
  const municipio = perfil.municipio || CONFIG.municipioPadrao;
  const centro = perfil.lat != null ? { lat: perfil.lat, lon: perfil.lon } : { lat: municipio.lat, lon: municipio.lon };
  return { municipio, centro };
}

export async function carregarTudo(perfil) {
  const ctx = contexto(perfil);
  const [clima, fogo, plantio, lavouraBruta] = await Promise.all([buscarClima(ctx), buscarFogo(ctx), buscarPlantio(ctx), buscarLavoura(ctx)]);
  return {
    ctx, clima, fogoBruto: fogo, plantioBruto: plantio, lavouraBruta,
    lavoura: resumoLavoura(lavouraBruta),
    plantio: semaforoPlantio(plantio, clima),
    fogo: fogoPerto(fogo, ctx.centro),
    exemplo: clima.exemplo || fogo.exemplo || plantio.exemplo,
  };
}

// ---------- Plantio: semáforo ----------
export function semaforoPlantio(plantio, clima, hoje = new Date()) {
  const r = plantio.riscos;
  const dec = decendio(hoje);
  const risco = r[dec - 1];
  const chuvaSemana = (clima.dias || []).reduce((s, d) => s + (d.chuvaMm || 0), 0);

  let proximo = null;
  for (let i = 1; i <= 36; i++) {
    const d = ((dec - 1 + i) % 36) + 1;
    if (r[d - 1] === 20) { proximo = d; break; }
  }
  const mesBom = proximo ? mesDoDecendio(proximo) : null;

  if (!risco || risco >= 40) {
    return { cor: 'vermelho', titulo: 'Não plante agora', detalhe: mesBom ? `Plante em ${mesBom}` : 'Fale com o técnico', mesBom };
  }
  if (CONFIG.elNino && chuvaSemana < 20) {
    return { cor: 'amarelo', titulo: 'Espere', detalhe: 'Falta chuva firme para as mudas', mesBom: MESES[hoje.getMonth()], motivo: 'elnino' };
  }
  if (risco === 30) {
    return { cor: 'amarelo', titulo: 'Plante com cuidado', detalhe: 'Risco médio de perda', mesBom };
  }
  return { cor: 'verde', titulo: 'Pode plantar', detalhe: 'Boa época para as mudas', mesBom: MESES[hoje.getMonth()] };
}

// ---------- Lavoura: compara a foto mais nova com a mais antiga (sem nuvem) ----------
export function resumoLavoura(lav, ate = lav.passagens.length - 1) {
  const validas = lav.passagens.map((p, i) => ({ ...p, i })).filter((p) => !p.nuvem && p.i <= ate);
  if (validas.length < 2) return null;
  const primeira = validas[0], ultima = validas.at(-1);
  const analise = compararPartes(lav, primeira, ultima);
  const dias = Math.round((new Date(ultima.data) - new Date(primeira.data)) / 864e5);
  const semanas = Math.max(1, Math.round(dias / 7));
  const alerta = analise.pior.queda >= 0.08;
  return {
    primeira, ultima, analise, alerta, semanas,
    titulo: alerta ? `A parte ${analise.pior.nome} perdeu verde` : 'Lavoura verde por igual',
    detalhe: alerta ? `Em ${semanas} semanas. Vá lá e tire foto de uma folha.` : `Sem mudança forte em ${semanas} semanas.`,
  };
}

// ---------- Fogo: o mais perto da roça ----------
export function fogoPerto(fogo, centro) {
  const perto = (fogo.focos || [])
    .map((f) => ({ ...f, km: distanciaKm(centro, f), graus: rumo(centro, f) }))
    .filter((f) => f.km <= CONFIG.raioFogoKm)
    .sort((a, b) => a.km - b.km);
  if (!perto.length) return null;
  const f = perto[0];
  return { ...f, kmTexto: f.km < 1 ? 'menos de 1 km' : `${Math.round(f.km)} km`, direcao: rumoEmPalavras(f.graus), total: perto.length };
}

// ---------- Avisos personalizados (no máximo 1 "do dia" + extras) ----------
export function gerarAvisos(perfil, d) {
  const avisos = [];
  const nome = perfil.nome ? perfil.nome.split(' ')[0] : '';

  if (d.fogo) {
    avisos.push({ cor: 'cereja', icone: 'fogo', prioridade: d.fogo.km <= 10 ? 0 : 3,
      titulo: `Fogo a ${d.fogo.kmTexto}`, detalhe: `Para o ${d.fogo.direcao}. Visto por satélite. Se chegar perto, ligue 193.` });
  }

  const p = d.plantio;
  if (p.cor !== 'verde') {
    let detalhe = p.detalhe;
    if (perfil.mesTradicional && p.motivo === 'elnino') {
      detalhe = `Você costuma plantar em ${MESES[perfil.mesTradicional - 1]}. Este ano, com El Niño, espere a chuva firmar.`;
    }
    avisos.push({ cor: 'folha', icone: 'calendario', prioridade: 1,
      titulo: `${nome ? nome + ', e' : 'E'}spere para plantar`, detalhe });
  } else {
    avisos.push({ cor: 'folha', icone: 'calendario', prioridade: 1, titulo: 'Pode plantar as mudas', detalhe: p.detalhe });
  }

  if (d.lavoura?.alerta) {
    avisos.push({ cor: 'grao', icone: 'satelite', prioridade: 1.5, titulo: d.lavoura.titulo, detalhe: `Visto pelo satélite. ${d.lavoura.detalhe}` });
  }

  const hoje = d.clima.hoje;
  if (hoje.max >= 33) {
    avisos.push({ cor: 'grao', icone: 'calor', prioridade: 2, titulo: 'Calor forte', detalhe: 'Evite o sol das 11h às 15h. Água para as mudas.' });
  }
  if (hoje.umidade != null && hoje.umidade < 30) {
    avisos.push({ cor: 'cereja', icone: 'gota', prioridade: d.fogo ? 3 : 2, titulo: 'Ar muito seco',
      detalhe: `Umidade ${hoje.umidade}%. Risco de fogo: não queime lixo nem palha.` });
  }
  if (hoje.ventoKmh != null && hoje.ventoKmh > 10) {
    avisos.push({ cor: 'ceu', icone: 'vento', prioridade: 3, titulo: 'Vento forte',
      detalhe: `${hoje.ventoKmh} km/h agora. Não passe produto: o vento leva.` });
  }
  const amanha = d.clima.dias?.[0];
  if (amanha && amanha.chuvaMm >= 5) {
    avisos.push({ cor: 'ceu', icone: 'chuva', prioridade: 2, titulo: 'Chuva amanhã', detalhe: 'Não passe produto hoje: a chuva lava.' });
  } else {
    const dia = (d.clima.dias || []).find((x) => x.chuvaMm >= 5);
    if (dia) avisos.push({ cor: 'ceu', icone: 'chuva', prioridade: 4, titulo: `Chuva ${dia.nome}`, detalhe: `Perto de ${dia.chuvaMm} mm.` });
  }
  return avisos.sort((a, b) => a.prioridade - b.prioridade);
}

// ---------- Boletim da rádio (até 150 palavras ≈ 1 minuto) ----------
export function gerarBoletim(d) {
  const m = d.ctx.municipio;
  const hoje = d.clima.hoje;
  const partes = [
    `Bom dia, produtor e produtora de ${m.nome} e região! Aqui é o Campo Alerta, o boletim da roça.`,
    `Hoje: ${hoje.frase.toLowerCase()}, máxima de ${hoje.max} graus.`,
  ];
  const chuva = (d.clima.dias || []).find((x) => x.chuvaMm >= 5);
  partes.push(chuva ? `Chuva prevista para ${chuva.nome}.` : 'Sem chuva forte nos próximos dias.');
  if (hoje.max >= 33) partes.push('Calor forte: evite o sol das onze às três da tarde.');
  if (d.plantio.cor === 'verde') partes.push('Café: boa época para plantar as mudas.');
  else partes.push(`Café: ${d.plantio.titulo.toLowerCase()}. ${d.plantio.detalhe}.`);
  if (!d.fogo && hoje.umidade != null && hoje.umidade < 30) partes.push('Ar muito seco: não queime lixo nem palha.');
  if (d.fogo) partes.push(`Atenção: o satélite viu fogo na região, para o lado ${d.fogo.direcao}. Não queime lixo nem palha. Viu fogo? Ligue cento e noventa e três.`);
  partes.push('Dúvida na lavoura? Procure a Casa da Agricultura. Este foi o Campo Alerta, com dados abertos do governo.');
  const texto = partes.join(' ');
  return { texto, palavras: texto.split(/\s+/).length };
}
