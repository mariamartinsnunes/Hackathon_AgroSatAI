// ============================================================
//  VOZ — falar (ler a tela) e ouvir (entender comandos)
//  Falar: speechSynthesis — funciona até sem internet.
//  Ouvir: SpeechRecognition — só Chrome/Edge, precisa de internet e HTTPS
//         (no Vercel já é HTTPS; local, "localhost" também vale).
// ============================================================

const legenda = () => document.querySelector('.legenda');
let vozBR = null;
let falaAtual = 0;

function escolherVoz() {
  const vozes = window.speechSynthesis?.getVoices() || [];
  vozBR = vozes.find((v) => v.lang === 'pt-BR' && /google|luciana|francisca|maria/i.test(v.name))
       || vozes.find((v) => v.lang?.startsWith('pt-BR'))
       || vozes.find((v) => v.lang?.startsWith('pt'))
       || null;
}
if ('speechSynthesis' in window) {
  escolherVoz();
  window.speechSynthesis.onvoiceschanged = escolherVoz;
}

function mostrarLegenda(texto, tipo = 'fala') {
  const el = legenda();
  if (!el) return;
  el.textContent = texto;
  el.dataset.tipo = tipo;
  el.hidden = !texto;
}

export const podeFalar = () => 'speechSynthesis' in window;
export const podeOuvir = () => 'SpeechRecognition' in window || 'webkitSpeechRecognition' in window;

// Fala um texto. Devolve uma Promise que termina quando acaba de falar.
export function falar(texto) {
  return new Promise((fim) => {
    if (!podeFalar() || !texto) return fim();
    window.speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(texto);
    u.lang = 'pt-BR';
    u.rate = 0.92;           // um pouco mais devagar: mais fácil de entender
    if (vozBR) u.voice = vozBR;
    const minha = ++falaAtual;
    let acabou = false;
    const terminar = () => {
      if (acabou) return;
      acabou = true;
      if (minha === falaAtual) { mostrarLegenda(''); document.body.classList.remove('falando'); }
      fim();
    };
    u.onend = u.onerror = terminar;
    // Segurança: alguns navegadores nunca avisam que terminou
    setTimeout(terminar, 2500 + texto.split(/\s+/).length * 480);
    mostrarLegenda(texto, 'fala');
    document.body.classList.add('falando');
    window.speechSynthesis.speak(u);
  });
}

export function pararDeFalar() {
  if (podeFalar()) window.speechSynthesis.cancel();
  mostrarLegenda('');
  document.body.classList.remove('falando');
}

// LER A TELA: junta, em ordem, tudo que tem o atributo data-ler.
//   <h2 data-ler>Espere</h2>              -> lê o texto do elemento
//   <div data-ler="Fogo a 4 quilômetros"> -> lê o texto do atributo
export function textoDaTela(raiz = document.querySelector('#conteudo')) {
  return [...raiz.querySelectorAll('[data-ler]')]
    .filter((el) => !el.closest('[hidden]'))
    .map((el) => (el.dataset.ler || el.textContent).replace(/\s+/g, ' ').trim())
    .filter(Boolean)
    .join('. ')
    .replace(/\.\s*\./g, '.')
    .replace(/(\d+)\s?km/g, '$1 quilômetros')
    .replace(/(\d+)°/g, '$1 graus');
}

export function lerTela() { return falar(textoDaTela()); }

// OUVIR: devolve as frases que o reconhecedor entendeu (até 5 alternativas)
export function ouvir() {
  return new Promise((ok, erro) => {
    const R = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!R) return erro(new Error('sem-suporte'));
    pararDeFalar();
    const rec = new R();
    rec.lang = 'pt-BR';
    rec.interimResults = false;
    rec.maxAlternatives = 5;
    let entendeu = false;
    mostrarLegenda('Pode falar…', 'ouvindo');
    document.body.classList.add('ouvindo');
    rec.onresult = (e) => {
      entendeu = true;
      const frases = [...e.results[0]].map((a) => a.transcript.toLowerCase().trim());
      mostrarLegenda(`“${frases[0]}”`, 'ouvindo');
      ok(frases);
    };
    rec.onerror = (e) => erro(new Error(e.error || 'erro'));
    rec.onend = () => {
      document.body.classList.remove('ouvindo');
      if (!entendeu) { mostrarLegenda(''); erro(new Error('silencio')); }
    };
    rec.start();
  });
}

// ENTENDER: transforma o que a pessoa falou numa intenção.
// Palavras do jeito que o produtor fala, sem acento.
const INTENCOES = [
  { ir: 'foto', palavras: ['foto', 'folha', 'doenca', 'doente', 'mancha', 'praga', 'ferrugem', 'bicho', 'amarel', 'furad'] },
  { ir: 'lavoura', palavras: ['lavoura', 'cafezal', 'satelite', 'verde'] },
  { ir: 'plantio', palavras: ['plantar', 'plantio', 'planto', 'muda', 'semente', 'epoca'] },
  { ir: 'fogo', palavras: ['fogo', 'queimada', 'fumaca', 'incendio', 'queimando'] },
  { ir: 'tempo', palavras: ['tempo', 'chuva', 'chover', 'sol', 'calor', 'frio', 'previsao', 'temperatura'] },
  { ir: 'avisos', palavras: ['aviso', 'alerta', 'novidade', 'recado'] },
  { ir: 'radio', palavras: ['radio', 'boletim', 'noticia'] },
  { ir: 'ligar', palavras: ['ligar', 'ligacao', 'telefone', 'tecnico'] },
  { ir: 'ler', palavras: ['ler', 'leia', 'fala ai', 'o que tem', 'repete', 'repetir'] },
  { ir: 'inicio', palavras: ['inicio', 'voltar', 'comeco', 'painel', 'casa'] },
];

const semAcento = (t) => t.normalize('NFD').replace(/[̀-ͯ]/g, '');

export function entender(frases) {
  for (const frase of frases) {
    const f = semAcento(frase);
    for (const it of INTENCOES) {
      if (it.palavras.some((p) => f.includes(p))) return { ir: it.ir, frase };
    }
  }
  return { ir: null, frase: frases[0] };
}
