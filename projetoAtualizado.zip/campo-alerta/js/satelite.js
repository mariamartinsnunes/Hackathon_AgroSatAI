// Desenha a foto aérea SIMULADA da roça e o NDVI por cima.
// Quando tiver foto real (dados.foto), a tela usa a foto e só o NDVI é desenhado.

export const LARGURA = 960, ALTURA = 720;

// ---------- utilidades ----------
function semente(s) { // gerador aleatório com semente (a roça sai igual toda vez)
  return () => { s |= 0; s = (s + 0x6D2B79F5) | 0; let t = Math.imul(s ^ (s >>> 15), 1 | s); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
}
const px = (p) => [p[0] * LARGURA, p[1] * ALTURA];

function caminho(ctx, pontos) {
  ctx.beginPath();
  pontos.forEach((p, i) => { const [x, y] = px(p); i ? ctx.lineTo(x, y) : ctx.moveTo(x, y); });
  ctx.closePath();
}

export function dentro(p, poli) { // ponto dentro do polígono?
  let ok = false;
  for (let i = 0, j = poli.length - 1; i < poli.length; j = i++) {
    const [xi, yi] = poli[i], [xj, yj] = poli[j];
    if ((yi > p[1]) !== (yj > p[1]) && p[0] < ((xj - xi) * (p[1] - yi)) / (yj - yi) + xi) ok = !ok;
  }
  return ok;
}

function manchas(ctx, rnd, n, cores, rMin, rMax, area = [0, 0, LARGURA, ALTURA]) {
  for (let i = 0; i < n; i++) {
    const x = area[0] + rnd() * area[2], y = area[1] + rnd() * area[3], r = rMin + rnd() * (rMax - rMin);
    const g = ctx.createRadialGradient(x, y, 0, x, y, r);
    const c = cores[Math.floor(rnd() * cores.length)];
    g.addColorStop(0, c); g.addColorStop(1, c.replace(/[\d.]+\)$/, '0)'));
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.fill();
  }
}

function linhasDeCultura(ctx, rnd, { espaco, angulo, cores, largura, copa, onda }) {
  ctx.save();
  ctx.translate(LARGURA / 2, ALTURA / 2);
  ctx.rotate(angulo);
  for (let y = -ALTURA; y < ALTURA; y += espaco) {
    for (let x = -LARGURA; x < LARGURA; x += copa * 0.9) {
      const yy = y + Math.sin(x / 160) * onda;
      if (rnd() < 0.04) continue; // falha na linha (planta morta/replantio)
      ctx.fillStyle = cores[Math.floor(rnd() * cores.length)];
      ctx.beginPath();
      ctx.arc(x, yy + (rnd() - 0.5) * 1.2, copa * (0.75 + rnd() * 0.45), 0, Math.PI * 2);
      ctx.fill();
    }
    if (largura) {
      ctx.strokeStyle = 'rgba(20,40,15,.25)'; ctx.lineWidth = largura;
      ctx.beginPath(); ctx.moveTo(-LARGURA, y); ctx.lineTo(LARGURA, y); ctx.stroke();
    }
  }
  ctx.restore();
}

// ---------- foto aérea simulada ----------
let cacheFoto = null;

export function fotoSimulada(talhao) {
  if (cacheFoto) return cacheFoto;
  const c = document.createElement('canvas');
  c.width = LARGURA; c.height = ALTURA;
  const ctx = c.getContext('2d');
  const rnd = semente(42);

  // pasto de fundo
  ctx.fillStyle = '#8E9A5C'; ctx.fillRect(0, 0, LARGURA, ALTURA);
  manchas(ctx, rnd, 90, ['rgba(160,160,96,.55)', 'rgba(118,132,72,.5)', 'rgba(170,150,100,.4)', 'rgba(128,92,60,.35)'], 30, 120);

  // canavial vizinho (embaixo, à direita) — linhas mais claras e largas
  ctx.save();
  ctx.beginPath(); ctx.moveTo(LARGURA * 0.9, ALTURA * 0.62); ctx.lineTo(LARGURA, ALTURA * 0.58); ctx.lineTo(LARGURA, ALTURA); ctx.lineTo(LARGURA * 0.62, ALTURA); ctx.closePath(); ctx.clip();
  ctx.fillStyle = '#9DAA55'; ctx.fillRect(0, 0, LARGURA, ALTURA);
  linhasDeCultura(ctx, rnd, { espaco: 7, angulo: 0.5, cores: ['#A7B85E', '#93A84E', '#B5C26A'], copa: 2.6, onda: 0 });
  ctx.restore();

  // mata ciliar com riacho (em cima, à direita)
  ctx.save();
  ctx.beginPath();
  ctx.moveTo(LARGURA * 0.55, 0); ctx.bezierCurveTo(LARGURA * 0.7, ALTURA * 0.08, LARGURA * 0.86, ALTURA * 0.04, LARGURA, ALTURA * 0.12);
  ctx.lineTo(LARGURA, 0); ctx.closePath(); ctx.clip();
  ctx.fillStyle = '#29401F'; ctx.fillRect(0, 0, LARGURA, ALTURA);
  for (let i = 0; i < 900; i++) {
    const x = LARGURA * 0.5 + rnd() * LARGURA * 0.5, y = rnd() * ALTURA * 0.14, r = 5 + rnd() * 9;
    ctx.fillStyle = ['#2F4B23', '#3A5A2A', '#24391B', '#456A30'][Math.floor(rnd() * 4)];
    ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.fill();
  }
  ctx.restore();

  // estrada de terra
  ctx.strokeStyle = '#C49A6C'; ctx.lineWidth = 13; ctx.lineCap = 'round';
  ctx.beginPath(); ctx.moveTo(-10, ALTURA * 0.95); ctx.bezierCurveTo(LARGURA * 0.3, ALTURA * 0.9, LARGURA * 0.55, ALTURA * 0.99, LARGURA * 0.62, ALTURA + 10); ctx.stroke();
  ctx.strokeStyle = 'rgba(120,80,50,.35)'; ctx.lineWidth = 2; ctx.stroke();

  // casa e terreiro
  ctx.fillStyle = '#D8C7A8'; ctx.fillRect(LARGURA * 0.04, ALTURA * 0.86, 70, 38);
  ctx.fillStyle = '#A8432B'; ctx.fillRect(LARGURA * 0.05, ALTURA * 0.87, 34, 22);
  ctx.fillStyle = '#E9E3D4'; ctx.fillRect(LARGURA * 0.095, ALTURA * 0.875, 20, 16);

  // CAFEZAL: terra roxa entre as linhas + linhas de café
  ctx.save();
  caminho(ctx, talhao); ctx.clip();
  ctx.fillStyle = '#7B3E27'; ctx.fillRect(0, 0, LARGURA, ALTURA);
  manchas(ctx, rnd, 60, ['rgba(140,80,50,.5)', 'rgba(95,48,30,.5)', 'rgba(120,110,60,.35)'], 20, 70);
  linhasDeCultura(ctx, rnd, { espaco: 9, angulo: -0.14, cores: ['#2C5426', '#355F2C', '#24461F', '#3E6A33', '#2F5A2A'], largura: 0, copa: 3.6, onda: 7 });
  ctx.restore();
  // carreador (caminho em volta do talhão)
  caminho(ctx, talhao); ctx.strokeStyle = 'rgba(205,170,125,.9)'; ctx.lineWidth = 7; ctx.stroke();

  // granulado de foto de satélite
  const img = ctx.getImageData(0, 0, LARGURA, ALTURA), d = img.data;
  for (let i = 0; i < d.length; i += 4) { const n = (rnd() - 0.5) * 18; d[i] += n; d[i + 1] += n; d[i + 2] += n; }
  ctx.putImageData(img, 0, 0);

  cacheFoto = c;
  return c;
}

// ---------- NDVI ----------
// 0,30 (vermelho) -> 0,55 (amarelo) -> 0,78 (verde)
const ESCALA = [[0.3, [196, 48, 32]], [0.45, [234, 128, 40]], [0.56, [244, 200, 52]], [0.66, [150, 196, 70]], [0.78, [38, 140, 64]]];
export function corNdvi(v) {
  if (v <= ESCALA[0][0]) return ESCALA[0][1];
  for (let i = 1; i < ESCALA.length; i++) {
    const [a, ca] = ESCALA[i - 1], [b, cb] = ESCALA[i];
    if (v <= b) { const t = (v - a) / (b - a); return ca.map((c, k) => Math.round(c + (cb[k] - c) * t)); }
  }
  return ESCALA[ESCALA.length - 1][1];
}

export function desenharNdvi(ctx, dados, grade, opacidade = 0.72) {
  const { colunas, linhas, talhao } = dados;
  const peq = document.createElement('canvas');
  peq.width = colunas; peq.height = linhas;
  const pc = peq.getContext('2d');
  const img = pc.createImageData(colunas, linhas);
  for (let j = 0; j < linhas; j++) for (let i = 0; i < colunas; i++) {
    const [r, g, b] = corNdvi(grade[j][i]);
    const k = (j * colunas + i) * 4;
    img.data[k] = r; img.data[k + 1] = g; img.data[k + 2] = b; img.data[k + 3] = 255;
  }
  pc.putImageData(img, 0, 0);
  ctx.save();
  caminho(ctx, talhao); ctx.clip();
  ctx.globalAlpha = opacidade;
  ctx.imageSmoothingEnabled = true; ctx.imageSmoothingQuality = 'high';
  ctx.drawImage(peq, 0, 0, LARGURA, ALTURA);
  ctx.restore();
}

export function desenharNuvens(ctx) {
  const rnd = semente(7);
  ctx.save();
  ctx.fillStyle = 'rgba(235,238,240,.55)'; ctx.fillRect(0, 0, LARGURA, ALTURA);
  manchas(ctx, rnd, 40, ['rgba(255,255,255,.85)', 'rgba(230,234,238,.8)'], 80, 200);
  ctx.restore();
}

// ---------- análise por partes (3 x 3) ----------
const NOMES_LINHA = ['de cima', 'do meio', 'de baixo'];
const NOMES_COL = ['à esquerda', 'no centro', 'à direita'];

// As 9 caixas (partes) sobre o retângulo que envolve a lavoura
export function caixasDasPartes(talhao) {
  const xs = talhao.map((p) => p[0]), ys = talhao.map((p) => p[1]);
  const x0 = Math.min(...xs), x1 = Math.max(...xs), y0 = Math.min(...ys), y1 = Math.max(...ys);
  const caixas = [];
  for (let l = 0; l < 3; l++) for (let c = 0; c < 3; c++) {
    caixas.push({
      linha: l, coluna: c,
      nome: l === 1 && c === 1 ? 'do meio' : `${NOMES_LINHA[l]}, ${NOMES_COL[c]},`,
      caixa: [x0 + (c * (x1 - x0)) / 3, y0 + (l * (y1 - y0)) / 3, (x1 - x0) / 3, (y1 - y0) / 3],
    });
  }
  return caixas;
}

// Recorta o contorno da lavoura por uma caixa (algoritmo Sutherland–Hodgman)
export function recortar(poligono, [cx, cy, cw, ch]) {
  const lados = [
    (p) => p[0] >= cx, (p) => p[0] <= cx + cw, (p) => p[1] >= cy, (p) => p[1] <= cy + ch,
  ];
  const cortes = [
    (a, b) => { const t = (cx - a[0]) / (b[0] - a[0]); return [cx, a[1] + t * (b[1] - a[1])]; },
    (a, b) => { const t = (cx + cw - a[0]) / (b[0] - a[0]); return [cx + cw, a[1] + t * (b[1] - a[1])]; },
    (a, b) => { const t = (cy - a[1]) / (b[1] - a[1]); return [a[0] + t * (b[0] - a[0]), cy]; },
    (a, b) => { const t = (cy + ch - a[1]) / (b[1] - a[1]); return [a[0] + t * (b[0] - a[0]), cy + ch]; },
  ];
  let saida = poligono;
  lados.forEach((dentroLado, k) => {
    const entrada = saida; saida = [];
    entrada.forEach((atual, i) => {
      const anterior = entrada[(i + entrada.length - 1) % entrada.length];
      if (dentroLado(atual)) {
        if (!dentroLado(anterior)) saida.push(cortes[k](anterior, atual));
        saida.push(atual);
      } else if (dentroLado(anterior)) saida.push(cortes[k](anterior, atual));
    });
  });
  return saida;
}

// NDVI médio de cada parte numa passagem (real: já vem pronto; simulado: calcula da grade)
export function valoresDasPartes(lav, passagem) {
  if (passagem.partes) return passagem.partes;
  const { colunas, linhas, talhao } = lav;
  return caixasDasPartes(talhao).map(({ caixa: [x0, y0, w, h] }) => {
    let soma = 0, n = 0;
    for (let j = 0; j < linhas; j++) for (let i = 0; i < colunas; i++) {
      const x = (i + 0.5) / colunas, y = (j + 0.5) / linhas;
      if (x < x0 || x >= x0 + w || y < y0 || y >= y0 + h || !dentro([x, y], talhao)) continue;
      soma += passagem.grade[j][i]; n++;
    }
    return n ? soma / n : null;
  });
}

export function compararPartes(lav, antes, agora) {
  const va = valoresDasPartes(lav, antes), vb = valoresDasPartes(lav, agora);
  const partes = caixasDasPartes(lav.talhao)
    .map((q, k) => ({ ...q, antes: va[k], agora: vb[k], queda: va[k] - vb[k] }))
    .filter((q) => q.antes != null && q.agora != null);
  const pior = partes.reduce((a, b) => (b.queda > a.queda ? b : a), partes[0]);
  const media = partes.reduce((s, p) => s + p.agora, 0) / partes.length;
  return { partes, pior, media };
}

// Desenha o NDVI de uma passagem: imagem pronta (dado real) ou grade (simulação)
const imagens = new Map();
function carregarImagem(url, cors = true) {
  if (!imagens.has(url)) {
    imagens.set(url, new Promise((ok, erro) => {
      const img = new Image();
      if (cors) img.crossOrigin = 'anonymous';
      img.onload = () => ok(img); img.onerror = () => erro(new Error('Imagem não carregou'));
      img.src = url;
    }));
  }
  return imagens.get(url);
}

export async function prepararPassagem(passagem) {
  if (passagem.imagem) await carregarImagem(passagem.imagem);
}

export async function desenharPassagem(ctx, lav, passagem, opacidade = 0.72) {
  if (!passagem.imagem) return desenharNdvi(ctx, lav, passagem.grade, opacidade);
  const img = await carregarImagem(passagem.imagem);
  ctx.save();
  caminho(ctx, lav.talhao); ctx.clip();
  ctx.globalAlpha = opacidade;
  ctx.drawImage(img, 0, 0, LARGURA, ALTURA);
  ctx.restore();
}

export async function desenharFoto(ctx, lav) {
  if (!lav.foto) { ctx.drawImage(fotoSimulada(lav.talhao), 0, 0); return; }
  try { ctx.drawImage(await carregarImagem(lav.foto, false), 0, 0, LARGURA, ALTURA); }
  catch { ctx.drawImage(fotoSimulada(lav.talhao), 0, 0); }
}

export function estadoNdvi(v) {
  if (v >= 0.66) return { cor: 'verde', nome: 'Saudável' };
  if (v >= 0.5) return { cor: 'amarelo', nome: 'Atenção' };
  return { cor: 'vermelho', nome: 'Sofrendo' };
}
