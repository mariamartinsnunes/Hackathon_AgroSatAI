import { CONFIG } from '../config.js';
import { icone } from '../icones.js';
import { saudacao, esc } from '../util.js';
import { horizonte, etiquetaExemplo } from './partes.js';
import { LARGURA, ALTURA, desenharFoto, desenharPassagem } from '../satelite.js';

// Mapa simples: a roça no meio, o fogo no rumo e distância certos
export function miniMapa(fogo) {
  const R = 84; // raio do desenho = CONFIG.raioFogoKm
  let ponto = '';
  if (fogo) {
    const r = Math.min(fogo.km / CONFIG.raioFogoKm, 1) * R;
    const a = (fogo.graus * Math.PI) / 180;
    const x = 100 + r * Math.sin(a), y = 100 - r * Math.cos(a);
    ponto = `<line x1="100" y1="100" x2="${x.toFixed(1)}" y2="${y.toFixed(1)}" class="mapa-linha"/>
      <circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="13" class="mapa-fogo-halo"/>
      <circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="7" class="mapa-fogo"/>`;
  }
  return `<svg class="mini-mapa" viewBox="0 0 200 200" role="img" aria-label="${fogo ? `Fogo a ${fogo.kmTexto} para o ${fogo.direcao}` : 'Nenhum fogo perto'}">
    <circle cx="100" cy="100" r="${R}" class="mapa-anel"/>
    <circle cx="100" cy="100" r="${R / 2}" class="mapa-anel"/>
    <text x="100" y="12" class="mapa-n">N</text>
    <text x="${100 + R / 2 + 4}" y="96" class="mapa-km">${CONFIG.raioFogoKm / 2} km</text>
    ${ponto}
    <path d="M90 104 L100 94 L110 104 V112 H90Z" class="mapa-casa"/>
  </svg>`;
}

function semaforo(cor) {
  return `<div class="semaforo" data-cor="${cor}" aria-hidden="true">
    <span class="luz luz-vermelho"></span><span class="luz luz-amarelo"></span><span class="luz luz-verde"></span>
  </div>`;
}

export default {
  titulo: 'Início',

  async render(app) {
    const d = await app.dados();
    const p = app.perfil;
    const m = d.ctx.municipio;
    const h = d.clima.hoje;
    const nome = p.nome ? `, ${esc(p.nome.split(' ')[0])}` : '';
    const ceu = d.fogo && d.fogo.km <= 10 ? 'fogo' : h.ceu;

    return `
    ${horizonte({ titulo: `${saudacao()}${nome}`, sub: `Café em ${esc(m.nome)} – ${m.uf}`, ceu })}
    <div class="pagina">
      <div class="painel-grade">

        <a href="#/avisos" class="cartao cartao-hoje" data-ler="Hoje: ${esc(h.frase)}, ${h.max} graus.${h.umidade < 30 ? ' Ar muito seco.' : ''}">
          <h2 class="cartao-titulo">${icone('sol', 26)} Hoje</h2>
          <div class="hoje-grande">
            ${icone(h.ceu, 64, 'hoje-icone')}
            <span class="hoje-temp">${h.max}°</span>
          </div>
          <p class="cartao-frase">${esc(h.frase)}${h.agora != null ? `, agora ${h.agora}°` : ''}</p>
          ${h.umidade != null ? `
          <ul class="hoje-extra">
            <li class="${h.umidade < 30 ? 'seco' : ''}">${icone('gota', 22)} Umidade ${h.umidade}%</li>
            <li>${icone('vento', 22)} Vento ${h.ventoKmh} km/h</li>
          </ul>` : ''}
          <ul class="dias" aria-label="Próximos dias">
            ${d.clima.dias.slice(0, 4).map((x) => `
              <li><span>${x.nome.slice(0, 3)}</span>${icone(x.ceu, 26)}<b>${x.max}°</b></li>`).join('')}
          </ul>
        </a>

        <a href="#/avisos" class="cartao cartao-plantio" data-cor="${d.plantio.cor}" data-ler="Plantio do café: ${esc(d.plantio.titulo)}. ${esc(d.plantio.detalhe)}.">
          <h2 class="cartao-titulo">${icone('calendario', 26)} Plantio</h2>
          <div class="plantio-linha">
            ${semaforo(d.plantio.cor)}
            <div>
              <p class="plantio-titulo">${esc(d.plantio.titulo)}</p>
              <p class="cartao-frase">${esc(d.plantio.detalhe)}</p>
            </div>
          </div>
        </a>

        <a href="#/mapa" class="cartao cartao-fogo ${d.fogo ? 'tem-fogo' : ''}"
           data-ler="${d.fogo ? `Atenção: fogo a ${d.fogo.kmTexto}, para o ${d.fogo.direcao}. Visto por satélite.` : 'Nenhum fogo perto da sua roça.'}">
          <h2 class="cartao-titulo">${icone('fogo', 26)} Alerta</h2>
          <div class="fogo-linha">
            <div>
              <p class="fogo-titulo">${d.fogo ? `Fogo a ${d.fogo.kmTexto}` : 'Sem fogo perto'}</p>
              <p class="cartao-frase">${d.fogo ? 'Visto por satélite' : `Até ${CONFIG.raioFogoKm} km`}</p>
              <p class="ver-satelite">${icone('satelite', 22)} Ver no satélite</p>
            </div>
            ${miniMapa(d.fogo)}
          </div>
        </a>
        ${d.lavoura ? `
        <a href="#/lavoura" class="cartao cartao-lavoura ${d.lavoura.alerta ? 'tem-alerta' : ''}" data-ler="Lavoura vista do satélite: ${esc(d.lavoura.titulo)}.">
          <h2 class="cartao-titulo">${icone('satelite', 26)} Lavoura</h2>
          <div class="lavoura-linha">
            <canvas class="lavoura-mini" width="${LARGURA}" height="${ALTURA}" data-mini aria-hidden="true"></canvas>
            <div>
              <p class="lavoura-titulo">${esc(d.lavoura.titulo)}</p>
              <p class="cartao-frase">Visto pelo satélite</p>
              <p class="ver-satelite">${icone('satelite', 22)} Ver a lavoura</p>
            </div>
          </div>
        </a>` : ''}
      </div>

      <a class="faixa-ligar" href="#/ligar">${icone('telefone', 26)} Sem internet? Ouça pelo telefone</a>
      ${etiquetaExemplo(d.exemplo, `${d.clima.fonte}, ${d.plantioBruto.fonte}, ${d.fogoBruto.fonte}`)}
    </div>`;
  },

  async montar(el, app) {
    const c = el.querySelector('[data-mini]');
    if (!c) return;
    const d = await app.dados();
    const lav = d.lavouraBruta, r = d.lavoura;
    const ctx = c.getContext('2d');
    await desenharFoto(ctx, lav);
    try { await desenharPassagem(ctx, lav, r.ultima, 0.8); } catch { /* sem imagem */ }
    if (r.alerta) {
      const q = r.analise.pior.caixa;
      ctx.strokeStyle = '#fff'; ctx.lineWidth = 12;
      ctx.strokeRect(q[0] * LARGURA, q[1] * ALTURA, q[2] * LARGURA, q[3] * ALTURA);
    }
  },
};
