import { deISO, paraISO, somarDias, diasEntre, dataCurta } from './util.js';

export const CULTURAS = {
  soja: {
    id: 'soja',
    nome: 'Soja',
    rotuloColheita: 'colheita',
    tbase: 10,
    tmaxCorte: 34,
    taxaPadrao: 14,
    janelaMedia: 21,
    avisoDias: 20,
    gddColheita: 1550,
    fases: [
      { id: 'semente', nome: 'Semente na terra', ate: 80 },
      { id: 'brotou', nome: 'Brotou', ate: 200 },
      { id: 'folhas', nome: 'Crescendo folhas', ate: 650 },
      { id: 'flor', nome: 'Florescendo', ate: 900 },
      { id: 'vagem', nome: 'Enchendo vagens', ate: 1350 },
      { id: 'madura', nome: 'Amadurecendo', ate: 1550 },
      { id: 'colher', nome: 'Pronta para colher', ate: Infinity },
    ],
    ndvi: [[0, 0.12], [0.08, 0.2], [0.3, 0.6], [0.5, 0.86], [0.65, 0.88], [0.8, 0.7], [0.95, 0.35], [1, 0.25]],
  },
  cafe: {
    id: 'cafe',
    nome: 'Café',
    rotuloColheita: 'primeira colheita',
    tbase: 10,
    tmaxCorte: 30,
    taxaPadrao: 11,
    janelaMedia: 365,
    avisoDias: 60,
    gddColheita: 11800,
    fases: [
      { id: 'pegando', nome: 'Muda pegando', ate: 400 },
      { id: 'crescendo', nome: 'Crescendo', ate: 5500 },
      { id: 'ramos', nome: 'Formando ramos', ate: 8500 },
      { id: 'florada', nome: 'Florada', ate: 9100 },
      { id: 'granacao', nome: 'Granando', ate: 11000 },
      { id: 'madura', nome: 'Amadurecendo', ate: 11800 },
      { id: 'colher', nome: 'Pronto para colher', ate: Infinity },
    ],
    ndvi: [[0, 0.25], [0.1, 0.3], [0.4, 0.5], [0.7, 0.66], [1, 0.72]],
  },
};

const media = (v) => v.reduce((s, x) => s + x, 0) / (v.length || 1);

export function gddDoDia(max, min, c) {
  const a = Math.min(Math.max(max, c.tbase), c.tmaxCorte);
  const b = Math.min(Math.max(min, c.tbase), c.tmaxCorte);
  return (a + b) / 2 - c.tbase;
}

export function ndviEsperado(cultura, gdd) {
  const c = CULTURAS[cultura];
  const f = Math.min(Math.max(gdd / c.gddColheita, 0), 1);
  const k = c.ndvi;
  for (let i = 1; i < k.length; i++) {
    if (f <= k[i][0]) {
      const [x0, y0] = k[i - 1];
      const [x1, y1] = k[i];
      return y0 + (y1 - y0) * ((f - x0) / (x1 - x0));
    }
  }
  return k[k.length - 1][1];
}

function indicePico(c) {
  let i = 0;
  c.ndvi.forEach((p, k) => { if (p[1] > c.ndvi[i][1]) i = k; });
  return i;
}

function gddParaNdvi(cultura, alvo) {
  const c = CULTURAS[cultura];
  const k = c.ndvi;
  const p = indicePico(c);
  if (alvo <= k[0][1]) return 0;
  for (let i = 1; i <= p; i++) {
    if (alvo <= k[i][1]) {
      const [x0, y0] = k[i - 1];
      const [x1, y1] = k[i];
      return (x0 + (x1 - x0) * ((alvo - y0) / (y1 - y0))) * c.gddColheita;
    }
  }
  return k[p][0] * c.gddColheita;
}

function textoColheita(c, estado, gdd, taxa, hoje) {
  if (estado === 'epoca') {
    return {
      estado, inicio: null, fim: null,
      titulo: 'Está na época de colher',
      detalhe: 'Confira a lavoura e fale com o técnico para marcar o dia.',
    };
  }
  const falta = c.gddColheita - gdd;
  const rapido = Math.ceil(falta / (taxa * 1.15));
  const lento = Math.ceil(falta / (taxa * 0.85));
  const inicio = somarDias(hoje, rapido);
  const fim = somarDias(hoje, lento);
  const faixa = `entre ${dataCurta(inicio, hoje)} e ${dataCurta(fim, hoje)}`;
  return {
    estado: rapido <= c.avisoDias ? 'breve' : 'longe',
    inicio, fim,
    titulo: rapido <= c.avisoDias ? 'Vai dar para colher em breve' : 'Ainda falta para colher',
    detalhe: `Pelo clima, a ${c.rotuloColheita} deve ficar ${faixa}. É uma estimativa.`,
  };
}

export function simular(lavoura, historico, hoje = new Date()) {
  const c = CULTURAS[lavoura.cultura];
  const inicio = deISO(lavoura.plantio);
  const n = Math.max(diasEntre(inicio, hoje), 0);
  const ajuste = lavoura.ajusteGdd || 0;
  const porData = new Map((historico.dias || []).map((d) => [d.data, d]));

  const serie = [];
  const diarios = [];
  let acum = 0;
  let ultimo = null;
  for (let i = 0; i <= n; i++) {
    const data = paraISO(somarDias(inicio, i));
    const d = porData.get(data);
    let g;
    if (d && Number.isFinite(d.max) && Number.isFinite(d.min)) {
      g = gddDoDia(d.max, d.min, c);
      ultimo = g;
    } else {
      g = ultimo ?? c.taxaPadrao;
    }
    acum += g;
    diarios.push(g);
    serie.push({ data, bruto: acum, gdd: Math.max(acum + ajuste, 0) });
  }

  const gddBruto = acum;
  const gdd = serie[serie.length - 1].gdd;

  let faseIndex = c.fases.findIndex((f) => gdd < f.ate);
  if (faseIndex < 0) faseIndex = c.fases.length - 1;
  const faseIni = faseIndex === 0 ? 0 : c.fases[faseIndex - 1].ate;
  const faseFim = c.fases[faseIndex].ate;
  const progressoFase = faseFim === Infinity ? 1 : (gdd - faseIni) / (faseFim - faseIni);

  const taxa = diarios.length >= 7 ? Math.max(media(diarios.slice(-c.janelaMedia)), 1) : c.taxaPadrao;
  const estadoColheita = gdd >= c.gddColheita ? 'epoca' : 'a-calcular';

  const comChuva = (historico.dias || [])
    .filter((d) => Number.isFinite(d.chuvaMm))
    .sort((a, b) => a.data.localeCompare(b.data));
  let secoDias = 0;
  for (let i = comChuva.length - 1; i >= 0 && comChuva[i].chuvaMm < 2; i--) secoDias++;

  return {
    cultura: c.id,
    def: c,
    fase: c.fases[faseIndex],
    faseIndex,
    progressoFase,
    progressoTotal: Math.min(gdd / c.gddColheita, 1),
    gdd,
    gddBruto,
    dias: n,
    taxa,
    secoDias,
    serie,
    colheita: textoColheita(c, estadoColheita, gdd, taxa, hoje),
  };
}

export function comparar(sim, sat, hoje = new Date()) {
  const pontos = (sat.pontos || [])
    .filter((p) => Number.isFinite(p.ndvi))
    .sort((a, b) => a.data.localeCompare(b.data));

  if (!pontos.length) {
    return {
      estado: 'sem-dado', pontos, zonaFraca: null,
      titulo: 'Satélite: sem imagem ainda',
      detalhe: 'O satélite passa a cada 5 dias. Volte em alguns dias.',
    };
  }

  const ultimo = pontos[pontos.length - 1];
  if (diasEntre(deISO(ultimo.data), hoje) > 30) {
    return {
      estado: 'velho', pontos, zonaFraca: null, ultima: ultimo.data,
      titulo: 'Satélite: imagem antiga',
      detalhe: 'A última imagem boa tem mais de 30 dias. Pode ter sido nuvem.',
    };
  }

  const c = sim.def;
  const gddPorData = new Map(sim.serie.map((s) => [s.data, s.gdd]));
  const recentes = pontos.slice(-2);
  const gdds = recentes.map((p) => gddPorData.get(p.data) ?? sim.gdd);
  const obs = media(recentes.map((p) => p.ndvi));
  const esp = media(gdds.map((g) => ndviEsperado(sim.cultura, g)));
  const diff = obs - esp;
  const gddMeio = media(gdds);

  const fracaoPico = c.ndvi[indicePico(c)][0];
  let lag = null;
  if (diff < -0.04 && gddMeio / c.gddColheita <= fracaoPico + 0.02) {
    lag = Math.max(Math.round((gddMeio - gddParaNdvi(sim.cultura, obs)) / sim.taxa), 0);
  }

  let estado;
  if (lag) estado = lag <= 4 ? 'ok' : lag <= 12 ? 'atencao' : 'alerta';
  else estado = diff >= -0.07 ? 'ok' : diff >= -0.15 ? 'atencao' : 'alerta';

  let zonaFraca = null;
  if (sat.zonas?.length) {
    const m = media(sat.zonas.map((z) => z.ndvi));
    const pior = sat.zonas.reduce((a, b) => (b.ndvi < a.ndvi ? b : a));
    if (pior.ndvi < m - 0.12) zonaFraca = pior.id;
  }

  const causa = sim.secoDias >= 10
    ? `Faz ${sim.secoDias} dias sem chuva firme: pode ser falta d'água.`
    : 'Pode ser praga, solo ou falha de plantio: confira e tire uma foto da folha.';
  const quanto = lag
    ? `Pelo satélite, a lavoura está uns ${lag} dias atrás do previsto.`
    : 'Pelo satélite, a vegetação está abaixo do esperado para esta fase.';
  const zona = zonaFraca ? ` A zona ${zonaFraca} está mais fraca: comece por ela.` : '';

  const textos = {
    ok: { titulo: 'Satélite: no ritmo', detalhe: `A vegetação está como o esperado para esta fase.${zonaFraca ? ` A zona ${zonaFraca} está mais fraca: vale dar uma olhada.` : ''}` },
    atencao: { titulo: lag ? `Atrasada uns ${lag} dias` : 'Um pouco abaixo do esperado', detalhe: `${quanto} ${causa}${zona}` },
    alerta: { titulo: lag ? `Bem atrasada: uns ${lag} dias` : 'Bem abaixo do esperado', detalhe: `${quanto} ${causa}${zona}` },
  };

  return { estado, ...textos[estado], diff, obs, esp, lag, ultima: ultimo.data, zonaFraca, pontos };
}

export function ajusteParaCheckin(sim, resposta) {
  const f = sim.def.fases;
  const i = sim.faseIndex;
  let alvo = null;
  if (resposta === 'antes' && i > 0) {
    const ini = i === 1 ? 0 : f[i - 2].ate;
    alvo = f[i - 1].ate - 0.1 * (f[i - 1].ate - ini);
  }
  if (resposta === 'depois' && i < f.length - 1) {
    const largura = f[i + 1].ate === Infinity ? 0 : f[i + 1].ate - f[i].ate;
    alvo = f[i].ate + (largura ? 0.1 * largura : 1);
  }
  return alvo === null ? null : alvo - sim.gddBruto;
}
