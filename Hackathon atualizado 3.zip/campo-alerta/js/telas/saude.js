import { CONFIG } from '../config.js';
import { icone, aplicarIcones } from '../icones.js';
import { esc } from '../util.js';
import { resumoLavoura } from '../regras.js';
import { falar } from '../voz.js';
import { LARGURA, ALTURA, desenharFoto, desenharPassagem, prepararPassagem, desenharNuvens, compararPartes, estadoNdvi } from '../satelite.js';
import { horizonte } from './partes.js';

const dataCurta = (iso) => { const [, m, d] = iso.split('-'); return `${d}/${m}`; };

function mediaDa(lav, p) {
  return p.nuvem ? null : compararPartes(lav, p, p).media;
}

export default {
  titulo: 'Satélite',

  // Abre NA HORA: se o satélite ainda está chegando, mostra o quadro vazio e completa depois
  render(app) {
    if (!app.saudePronta) {
      this._lav = null;
      return `
      ${horizonte({ titulo: 'Saúde da lavoura', sub: 'O café visto do satélite', voltar: 'painel' })}
      <div class="pagina">
        <div class="lav-grade">
          <div class="lav-quadro lav-quadro-esperando" role="status">
            ${icone('satelite', 56)}
            <p data-ler data-esperando>Buscando as fotos do satélite…</p>
          </div>
        </div>
      </div>`;
    }
    return this.desenho(app.saudePronta);
  },

  desenho(l) {
    const lav = l.bruta;
    this._lav = lav;
    const simulado = lav.fonte === 'Simulação';
    // Abre na foto mais recente SEM nuvem
    const ultima = lav.passagens.map((x) => !x.nuvem).lastIndexOf(true);
    this._inicio = ultima;

    return `
    ${horizonte({ titulo: 'Saúde da lavoura', sub: lav.nome ? esc(lav.nome) : 'O café visto do satélite', voltar: 'painel' })}
    <div class="pagina">
      <div class="lav-grade">

        <div class="lav-coluna-mapa">
          <div class="lav-quadro" data-quadro>
            <canvas class="lav-foto" width="${LARGURA}" height="${ALTURA}" data-foto aria-hidden="true"></canvas>
            <canvas class="lav-ndvi" width="${LARGURA}" height="${ALTURA}" data-ndvi aria-hidden="true"></canvas>
            <span class="lav-pin" data-pin hidden>${icone('local', 22)} Olhe aqui</span>
            <span class="lav-nuvem" data-nuvem hidden>${icone('nuvem', 40)}<b>Nublado neste dia</b><span>As nuvens taparam a roça</span></span>
            <span class="lav-simulado">${simulado ? 'Simulação' : 'Satélite real'}</span>
          </div>

          <div class="lav-modo" role="radiogroup" aria-label="O que mostrar">
            <button type="button" role="radio" aria-checked="false" data-modo="foto">${icone('camera', 24)} Foto</button>
            <button type="button" role="radio" aria-checked="true" data-modo="saude">${icone('folha', 24)} Saúde</button>
          </div>
        </div>

        <div class="lav-coluna-info">
          <article class="lav-aviso" data-aviso aria-live="polite"></article>

          <section class="lav-tempo">
            <h2>Fotos do satélite</h2>
            <div class="lav-datas" role="radiogroup" aria-label="Data da foto">
              ${lav.passagens.map((p, i) => {
                const m = mediaDa(lav, p);
                const est = m == null ? null : estadoNdvi(m);
                return `<button type="button" role="radio" class="lav-data" data-i="${i}" aria-checked="${i === ultima}"
                  aria-label="${dataCurta(p.data)}${p.nuvem ? ', nuvem' : `, ${est.nome}`}">
                  ${p.nuvem ? icone('nuvem', 22) : `<span class="lav-bolinha" data-cor="${est.cor}"></span>`}
                  <span>${dataCurta(p.data)}</span>
                </button>`;
              }).join('')}
            </div>
            <p class="nota">${icone('satelite', 20)} O satélite passa a cada 5 dias. A próxima foto chega em ${lav.proximaEmDias} ${lav.proximaEmDias === 1 ? 'dia' : 'dias'}.</p>
          </section>

          <ul class="lav-legenda" aria-label="Legenda das cores">
            <li><span data-cor="verde"></span>Saudável</li>
            <li><span data-cor="amarelo"></span>Atenção</li>
            <li><span data-cor="vermelho"></span>Sofrendo</li>
          </ul>

          <details class="lav-explica">
            <summary>${icone('info', 22)} Como o satélite sabe?</summary>
            <p>O satélite mede o verde das folhas com uma luz que o nosso olho não enxerga. Folha saudável brilha muito nessa luz; folha amarela ou doente brilha pouco. Ele enxerga a lavoura inteira, mas não cada pé. Por isso, quando algo muda, pedimos uma foto da folha.</p>
          </details>

          ${simulado ? '<p class="fonte fonte-exemplo">' + icone('info', 18) + ' Imagem simulada para a demonstração</p>' : `<p class="fonte">${esc(lav.credito || 'Fonte: ' + lav.fonte)}</p>`}
        </div>
      </div>
    </div>`;
  },

  async montar(el, app, ehAtual) {
    if (!this._lav) {
      let l;
      try { l = await app.saude(); } catch { l = null; }
      if (!ehAtual()) return;
      if (!l) {
        el.querySelector('[data-esperando]').textContent = 'O satélite não respondeu agora. Tente de novo daqui a pouco.';
        return;
      }
      el.innerHTML = this.desenho(l);
      aplicarIcones(el);
    }
    const lav = this._lav;
    const fotoCtx = el.querySelector('[data-foto]').getContext('2d');
    const ndvi = el.querySelector('[data-ndvi]');
    const nctx = ndvi.getContext('2d');
    const pin = el.querySelector('[data-pin]');
    const nuvemMsg = el.querySelector('[data-nuvem]');
    const aviso = el.querySelector('[data-aviso]');
    let indice = this._inicio;
    let modo = 'saude';

    // Foto: real (Esri) ou simulada
    desenharFoto(fotoCtx, lav);

    let vez = 0;
    async function desenhar() {
      const minhaVez = ++vez;
      const p = lav.passagens[indice];
      if (!p.nuvem) { try { await prepararPassagem(p); } catch { /* segue sem imagem */ } }
      if (minhaVez !== vez || !ehAtual()) return; // a pessoa já trocou de data ou de tela
      const r = resumoLavoura(lav, indice);
      nctx.clearRect(0, 0, LARGURA, ALTURA);
      nuvemMsg.hidden = !p.nuvem;
      pin.hidden = true;

      if (p.nuvem) {
        desenharNuvens(nctx);
      } else {
        try { await desenharPassagem(nctx, lav, p); } catch { /* sem imagem: fica só a foto */ }
        if (r) {
          // linhas das 9 partes
          nctx.save();
          nctx.beginPath(); lav.talhao.forEach(([x, y], k) => (k ? nctx.lineTo(x * LARGURA, y * ALTURA) : nctx.moveTo(x * LARGURA, y * ALTURA))); nctx.closePath(); nctx.clip();
          nctx.strokeStyle = 'rgba(255,255,255,.55)'; nctx.lineWidth = 2; nctx.setLineDash([8, 8]);
          r.analise.partes.forEach((q) => nctx.strokeRect(q.caixa[0] * LARGURA, q.caixa[1] * ALTURA, q.caixa[2] * LARGURA, q.caixa[3] * ALTURA));
          nctx.restore();
          if (r.alerta) {
            const c = r.analise.pior.caixa;
            nctx.save();
            nctx.strokeStyle = '#fff'; nctx.lineWidth = 6;
            nctx.strokeRect(c[0] * LARGURA, c[1] * ALTURA, c[2] * LARGURA, c[3] * ALTURA);
            nctx.restore();
            pin.style.left = `${(c[0] + c[2] / 2) * 100}%`;
            pin.style.top = `${(c[1] + c[3] / 2) * 100}%`;
            pin.hidden = modo === 'foto';
          }
        }
      }
      ndvi.classList.toggle('lav-ndvi-off', modo === 'foto' && !p.nuvem);

      // Aviso embaixo/ao lado
      if (p.nuvem) {
        aviso.dataset.cor = 'ceu';
        aviso.innerHTML = `<span class="lav-aviso-icone">${icone('nuvem', 34)}</span>
          <div><h2 data-ler>Nublado no dia ${dataCurta(p.data)}</h2><p data-ler>As nuvens taparam a roça. Vale a foto anterior.</p></div>`;
      } else if (!r) {
        aviso.dataset.cor = 'folha';
        aviso.innerHTML = `<span class="lav-aviso-icone">${icone('folha', 34)}</span>
          <div><h2 data-ler>Primeira foto</h2><p data-ler>Lavoura ${estadoNdvi(mediaDa(lav, p)).nome.toLowerCase()}. As próximas fotos vão mostrar se algo mudou.</p></div>`;
      } else {
        aviso.dataset.cor = r.alerta ? 'grao' : 'folha';
        aviso.innerHTML = `<span class="lav-aviso-icone">${icone(r.alerta ? 'satelite' : 'ok', 34)}</span>
          <div><h2 data-ler>${esc(r.titulo)}</h2><p data-ler>${esc(r.detalhe)}</p></div>
          ${r.alerta ? `<div class="lav-aviso-botoes">
            <a class="botao" href="#/foto">${icone('camera', 26)} Tirar foto da folha</a>
            <a class="botao botao-contorno" href="tel:${CONFIG.tecnico.telefone}">${icone('telefone', 26)} Chamar técnico</a>
          </div>` : ''}`;
      }
    }

    el.querySelectorAll('[data-i]').forEach((b) => b.addEventListener('click', () => {
      indice = +b.dataset.i;
      el.querySelectorAll('[data-i]').forEach((x) => x.setAttribute('aria-checked', String(x === b)));
      desenhar();
    }));
    el.querySelectorAll('[data-modo]').forEach((b) => b.addEventListener('click', () => {
      modo = b.dataset.modo;
      el.querySelectorAll('[data-modo]').forEach((x) => x.setAttribute('aria-checked', String(x === b)));
      desenhar();
      if (modo === 'saude') falar('Verde é saudável. Amarelo é atenção. Vermelho é planta sofrendo.');
    }));

    desenhar();
  },
};
