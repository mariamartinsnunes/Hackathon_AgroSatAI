// Pedaços de tela usados em todo lugar
import { icone } from '../icones.js';
import { esc } from '../util.js';

export function botaoOuvir(texto = 'Ouvir') {
  return `<button type="button" class="ouvir" data-acao="ouvir" aria-label="Ouvir esta tela">
    ${icone('som', 28)}<span>${texto}</span></button>`;
}

// Cabeçalho "horizonte": céu claro, sol de fim de tarde e as fileiras de café no morro.
// ceu: 'sol' | 'nuvem' | 'chuva' | 'fogo' — muda o desenho do céu.
export function horizonte({ titulo, sub = '', ceu = 'sol', voltar = null, lerTitulo = true }) {
  return `
  <header class="horizonte" data-ceu="${ceu}">
    <div class="horizonte-topo">
      ${voltar ? `<a class="voltar" href="#/${voltar}" aria-label="Voltar">${icone('voltar', 28)}</a>` : ''}
      <div class="horizonte-texto">
        <h1 ${lerTitulo ? 'data-ler' : ''}>${titulo}</h1>
        ${sub ? `<p>${sub}</p>` : ''}
      </div>
      ${botaoOuvir()}
    </div>
    <svg class="morro" viewBox="0 0 400 64" preserveAspectRatio="none" aria-hidden="true">
      <path class="morro-longe" d="M0 30 C60 14 120 16 185 28 C245 39 305 16 400 22 L400 64 L0 64Z"/>
      <path class="morro-meio" d="M0 42 C80 28 150 32 225 42 C295 51 345 36 400 38 L400 64 L0 64Z"/>
      <path class="morro-linhas" d="M0 47 C80 34 150 38 225 47 C295 56 345 42 400 44 M0 52 C80 40 150 44 225 52 C295 60 345 48 400 50"/>
      <path class="morro-frente" d="M0 56 C90 48 170 50 250 56 C320 61 360 54 400 54 L400 64 L0 64Z"/>
    </svg>
  </header>`;
}

export function etiquetaExemplo(exemplo, fonte) {
  if (exemplo) return `<p class="fonte fonte-exemplo">${icone('info', 18)} Dados de exemplo</p>`;
  return fonte ? `<p class="fonte">Fonte: ${esc(fonte)}</p>` : '';
}

// Cada fonte aparece separada: dado real pelo nome (ex.: ZARC/MAPA), exemplo marcado como exemplo.
// itens = [['Tempo', resultado], ['Plantio', resultado], ...]
export function fontesDados(itens) {
  const partes = itens.map(([rotulo, r]) => (r.exemplo ? `${rotulo}: exemplo` : r.fonte));
  return `<p class="fonte">${icone('info', 18)} Fontes: ${esc(partes.join(' · '))}</p>`;
}
