import { CONFIG } from '../config.js';
import { icone } from '../icones.js';
import { ouvir, falar, podeOuvir } from '../voz.js';
import { distanciaKm, esc } from '../util.js';
import { horizonte } from './partes.js';
import { DESENHOS } from '../desenhos.js';

function limparNome(frase) {
  const n = frase.replace(/^(meu nome (e|é)|me chamo|eu sou( o| a)?|sou( o| a)?)\s+/i, '').trim();
  return n.replace(/\b\p{L}/gu, (c) => c.toUpperCase());
}

async function municipioMaisPerto(lat, lon) {
  const r = await fetch('dados/municipios.json');
  const { municipios } = await r.json();
  return municipios.reduce((melhor, m) =>
    (!melhor || distanciaKm({ lat, lon }, m) < distanciaKm({ lat, lon }, melhor) ? m : melhor), null);
}

export default {
  titulo: 'Cadastro',

  render(app) {
    const p = app.perfil;
    const local = p.municipio ? `${p.municipio.nome} – ${p.municipio.uf}` : '';
    return `
    ${horizonte({ titulo: 'Olá! Vamos nos conhecer', sub: 'São só 3 perguntas. Pode falar ou digitar.' })}
    <div class="pagina pagina-estreita">

      <section class="passo">
        <label class="passo-titulo" for="nome" data-ler="Como você se chama?">Como você se chama?</label>
        <div class="campo-voz">
          <input id="nome" name="nome" autocomplete="given-name" value="${esc(p.nome)}" placeholder="Ex.: João">
          <button type="button" class="mic" data-ouvir-nome aria-label="Falar meu nome">${icone('mic', 30)}</button>
        </div>
      </section>

      <section class="passo">
        <h2 class="passo-titulo" data-ler="Onde fica sua roça?">Onde fica sua roça?</h2>
        <button type="button" class="botao botao-contorno botao-local" data-local>
          ${icone('local', 30)}<span data-local-texto>${local ? `${esc(local)} ${icone('ok', 24)}` : 'Usar minha localização'}</span>
        </button>
        <p class="nota">Seu nome e sua localização ficam guardados só no seu celular.</p>
      </section>

      <section class="passo">
        <h2 class="passo-titulo" data-ler="O que você planta? Por enquanto, café.">O que você planta?</h2>
        <div class="culturas" role="radiogroup" aria-label="Cultura">
          ${CONFIG.culturas.map((c) => `
            <button type="button" role="radio" class="cultura cultura-${c.id}" aria-checked="${c.id === p.cultura}" ${c.ativo ? '' : 'disabled'}>
              <span class="cultura-desenho">${DESENHOS[c.id]}</span>
              <span class="cultura-nome">${c.nome}</span>
              ${c.ativo ? '' : '<span class="cultura-breve">em breve</span>'}
            </button>`).join('')}
        </div>
      </section>

      <button type="button" class="botao botao-grande" data-pronto>${icone('ok', 32)} Continuar</button>
    </div>`;
  },

  montar(el, app) {
    const nome = el.querySelector('#nome');

    el.querySelector('[data-ouvir-nome]').addEventListener('click', async () => {
      if (!podeOuvir()) return falar('Este navegador não consegue ouvir. Digite seu nome, ou abra no Chrome.');
      await falar('Pode falar o seu nome');
      try { nome.value = limparNome((await ouvir())[0]); } catch { falar('Não consegui ouvir. Toque no microfone e fale de novo.'); }
    });

    el.querySelector('[data-local]').addEventListener('click', () => {
      const span = el.querySelector('[data-local-texto]');
      if (!navigator.geolocation) {
        app.salvar({ municipio: CONFIG.municipioPadrao });
        span.innerHTML = `${CONFIG.municipioPadrao.nome} – ${CONFIG.municipioPadrao.uf}`;
        return;
      }
      span.textContent = 'Procurando…';
      navigator.geolocation.getCurrentPosition(async ({ coords }) => {
        const m = await municipioMaisPerto(coords.latitude, coords.longitude);
        app.salvar({ lat: coords.latitude, lon: coords.longitude, municipio: m });
        span.innerHTML = `${esc(m.nome)} – ${m.uf} ${icone('ok', 24)}`;
        falar(`Achei! Sua roça fica perto de ${m.nome}.`);
      }, () => {
        app.salvar({ municipio: CONFIG.municipioPadrao });
        span.innerHTML = `${CONFIG.municipioPadrao.nome} – ${CONFIG.municipioPadrao.uf}`;
        falar(`Tudo bem. Por enquanto, vou usar ${CONFIG.municipioPadrao.nome}.`);
      }, { timeout: 10000, maximumAge: 600000 });
    });

    el.querySelector('[data-pronto]').addEventListener('click', () => {
      app.salvar({
        nome: nome.value.trim(),
        cultura: 'cafe',
        municipio: app.perfil.municipio || CONFIG.municipioPadrao,
      });
      app.ir('saber');
    });
  },
};
