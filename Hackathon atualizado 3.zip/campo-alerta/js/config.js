// ============================================================
//  CONFIGURAÇÃO — o único arquivo que vocês precisam mexer
//  para trocar de API. Cada serviço tem vários "provedores".
//  'mock' = dados de exemplo (funciona sem internet, bom pra demo).
// ============================================================

export const CONFIG = {
  provedores: {
    clima: 'openmeteo', // 'mock' | 'openmeteo' | 'inmet' | 'nasa'
    fogo: 'mock',      // 'mock' | 'inpe'  | 'firms'
    plantio: 'zarc',   // 'mock' | 'zarc'   (lê dados/zarc-cafe.json — Tábua de Risco do ZARC, MAPA)
    produtos: 'agrofit', // 'mock' | 'agrofit' (lê dados/agrofit-cafe.json — Agrofit, MAPA)
    ia: 'api',         // 'api' (modelo de vocês no Render) | 'teachable' | 'mock'
    saude: 'planetary',   // 'mock' | 'planetary' (Sentinel-2 real) | 'copernicus' (lê dados/lavoura.json)
    historico: 'mock',    // 'mock' | 'nasa'     (temperatura e chuva desde o plantio, para as lavouras)
    ndvi: 'mock',         // 'mock' | 'arquivo'  (NDVI de cada lavoura, para comparar com o crescimento)
  },

  // Se um provedor real falhar, o app cai automaticamente no 'mock'
  // e mostra a etiqueta "dados de exemplo". Nunca fica tela em branco.
  usarMockSeFalhar: true,

  // Endereço das funções do Vercel (pasta /api). Em produção fica ''.
  // Rodando local com Live Server, as funções não existem: use mock.
  baseApi: '',

  // VOZ CLONADA (ElevenLabs). A chave NÃO fica aqui: fica escondida no Vercel
  // (variáveis ELEVENLABS_API_KEY e ELEVENLABS_VOICE_ID). Veja o README.
  // Sem o Vercel (ex.: Live Server), o app usa a voz do navegador sozinho.
  vozIA: { ativa: true, aviso: 'Voz gerada por IA' },

  // API da IA da folha (FastAPI no Render, modelo MobileNetV2 treinado com DigiPathos).
  // proxy: caminho da função do Vercel que repassa a foto (resolve o bloqueio de CORS).
  iaApi: { url: 'https://fastapi-ml-7fcy.onrender.com', proxy: '/api/folha', esperaMs: 90000 },

  // Teachable Machine: cole aqui o link do modelo exportado
  // (ou deixe './modelo/' se colocar os arquivos na pasta modelo).
  modeloIA: './modelo/',

  // NASA FIRMS (reserva do fogo). Chave grátis: firms.modaps.eosdis.nasa.gov/api/map_key
  firmsKey: '',

  // Raio (km) para avisar fogo perto da roça
  raioFogoKm: 30,

  // El Niño 2026/27 ativo: deixa os avisos de plantio mais cautelosos
  elNino: true,

  // Só para a demo das lavouras (ndvi: 'mock'): quantos dias a lavoura aparece atrasada
  demoNdvi: { atrasoDias: 8, zonaFraca: true },

  // Contato do técnico (Emater / Casa da Agricultura / cooperativa)
  tecnico: { nome: 'Casa da Agricultura', telefone: '+5516999999999' },

  // Município usado quando a pessoa não libera a localização
  municipioPadrao: { nome: 'Araraquara', uf: 'SP', geocodigo: '3503208', lat: -21.79, lon: -48.18 },

  // Lavoura usada na demonstração: um cafezal REAL em Pedregulho (SP).
  // bbox = [oeste, sul, leste, norte]; talhao = contorno, de 0 a 1 dentro do bbox (x para a direita, y para baixo).
  // No produto, o produtor desenha o contorno da roça dele (e isso fica só no celular).
  lavouraDemo: {
    nome: 'Cafezal em Pedregulho (SP)',
    bbox: [-47.4720, -20.2805, -47.4600, -20.2715],
    talhao: [[0.21, 0.11], [0.45, 0.18], [0.70, 0.26], [0.75, 0.31], [0.75, 0.70], [0.34, 0.71], [0.21, 0.42]],
  },

  culturas: [
    { id: 'cafe', nome: 'Café', ativo: true },
    { id: 'milho', nome: 'Milho', ativo: false },
    { id: 'mandioca', nome: 'Mandioca', ativo: false },
    { id: 'feijao', nome: 'Feijão', ativo: false },
  ],
};
