import { lerPerfil, salvarPerfil } from './estado.js';
import { carregarTudo, carregarSaude, carregarLavouras } from './regras.js';
import { icone, aplicarIcones } from './icones.js';
import { lerTela, pararDeFalar } from './voz.js';
import { acordarIA } from './api/ia.js';

import cadastro from './telas/cadastro.js';
import saber from './telas/saber.js';
import painel from './telas/painel.js';
import foto from './telas/foto.js';
import avisos from './telas/avisos.js';
import voz from './telas/voz.js';
import radio from './telas/radio.js';
import ligar from './telas/ligar.js';
import mapa, { carregarLeaflet } from './telas/mapa.js';
import saude from './telas/saude.js';
import lavouras from './telas/lavouras.js';
import novaLavoura from './telas/nova-lavoura.js';
import lavoura from './telas/lavoura.js';

const TELAS = {
  cadastro, saber, painel, foto, avisos, voz, radio, ligar, mapa, saude, lavouras, 'nova-lavoura': novaLavoura, lavoura,
};
// Telas "filhas": marcam no menu o item da tela mãe
const MAE = { lavoura: 'lavouras', 'nova-lavoura': 'lavouras' };
const LIVRES = ['cadastro', 'saber']; // telas que abrem sem cadastro pronto

// Menus (celular embaixo, computador do lado)
const MENU_BARRA = [
  { rota: 'painel', nome: 'Início', icone: 'casa' },
  { rota: 'foto', nome: 'Foto', icone: 'camera' },
  { rota: 'voz', nome: 'Falar', icone: 'mic', central: true },
  { rota: 'lavouras', nome: 'Lavouras', icone: 'planta' },
  { rota: 'avisos', nome: 'Avisos', icone: 'sino' },
];
const MENU_LATERAL = [
  { rota: 'painel', nome: 'Início', icone: 'casa' },
  { rota: 'lavouras', nome: 'Minhas lavouras', icone: 'planta' },
  { rota: 'foto', nome: 'Foto da folha', icone: 'camera' },
  { rota: 'avisos', nome: 'Avisos', icone: 'sino' },
  { rota: 'saude', nome: 'Satélite', icone: 'satelite' },
  { rota: 'mapa', nome: 'Fogo', icone: 'fogo' },
  { rota: 'radio', nome: 'Rádio', icone: 'radio' },
  { rota: 'ligar', nome: 'Ligar', icone: 'telefone' },
];

const main = document.querySelector('#conteudo');

// Objeto compartilhado com todas as telas
export const app = {
  perfil: lerPerfil(),
  _dados: null,
  _saude: null,
  saudePronta: null,
  _lavouras: null,
  lavourasProntas: null,

  // Tempo + fogo + plantio: busca uma vez e reaproveita entre as telas
  dados() {
    if (!this._dados) {
      this._dados = carregarTudo(this.perfil).then((d) => {
        if (this.saudePronta) d.lavoura = this.saudePronta.resumo;
        if (this.lavourasProntas) d.lavouras = this.lavourasProntas;
        return d;
      });
      this._dados.catch(() => { this._dados = null; }); // se falhar, tenta de novo na próxima tela
    }
    return this._dados;
  },

  // Satélite real da lavoura (demora alguns segundos): carrega à parte, sem travar nenhuma tela
  saude() {
    if (!this._saude) {
      this._saude = carregarSaude(this.perfil).then(async (s) => {
        this.saudePronta = s;
        if (this._dados) (await this._dados).lavoura = s.resumo;
        return s;
      });
      this._saude.catch(() => { this._saude = null; });
    }
    return this._saude;
  },

  // Lavouras cadastradas (crescimento + colheita + satélite): também à parte
  lavouras() {
    if (!this._lavouras) {
      this._lavouras = carregarLavouras(this.perfil).then(async (lista) => {
        this.lavourasProntas = lista;
        if (this._dados) (await this._dados).lavouras = lista;
        return lista;
      });
      this._lavouras.catch(() => { this._lavouras = null; });
    }
    return this._lavouras;
  },

  salvar(mudancas) {
    this.perfil = salvarPerfil(mudancas);
    this._dados = null;
    if ('lavouras' in mudancas) { this._lavouras = null; this.lavourasProntas = null; }
  },
  ir(rota) { location.hash = '#/' + rota; },
};

// Menus: montados uma vez só; depois só muda qual está marcado
function montarMenus() {
  document.querySelector('[data-barra]').innerHTML = MENU_BARRA.map((m) => `
    <a href="#/${m.rota}" data-rota="${m.rota}" class="${m.central ? 'barra-falar' : ''}">
      ${icone(m.icone, m.central ? 34 : 28)}<span>${m.nome}</span>
    </a>`).join('');
  document.querySelector('[data-menu]').innerHTML = MENU_LATERAL.map((m) => `
    <a href="#/${m.rota}" data-rota="${m.rota}">${icone(m.icone, 28)}<span>${m.nome}</span></a>`).join('');
}

function marcarMenu(atual) {
  const item = MAE[atual] || atual;
  document.querySelectorAll('[data-rota]').forEach((a) => {
    if (a.dataset.rota === item) a.setAttribute('aria-current', 'page');
    else a.removeAttribute('aria-current');
  });
  document.body.classList.toggle('sem-menu', LIVRES.includes(atual) || atual === 'voz');
}

let navegacao = 0; // cada troca de tela ganha um número; só a última pode desenhar

async function mostrar() {
  const minha = ++navegacao;
  const ehAtual = () => minha === navegacao;
  pararDeFalar();

  let rota = (location.hash.replace(/^#\/?/, '') || 'painel').split('?')[0];
  if (!TELAS[rota]) rota = 'painel';
  if (!app.perfil.pronto && !LIVRES.includes(rota)) rota = 'cadastro';
  const tela = TELAS[rota];
  document.title = `${tela.titulo} · Campo Alerta`;
  marcarMenu(rota);

  // Só mostra "carregando" se demorar; a tela anterior fica até a nova estar pronta
  const espera = setTimeout(() => ehAtual() && document.body.classList.add('carregando-tela'), 80);
  let html;
  try {
    html = await tela.render(app);
  } catch (erro) {
    console.error(erro);
    html = `
      <section class="erro">
        <h1>Não deu para abrir esta tela</h1>
        <p>Confira a internet e tente de novo.</p>
        <a class="botao" href="#/painel">Voltar ao início</a>
      </section>`;
  }
  clearTimeout(espera);
  if (!ehAtual()) return; // a pessoa já foi para outra tela
  document.body.classList.remove('carregando-tela');

  main.dataset.tela = rota;
  main.innerHTML = html;
  aplicarIcones(main);
  main.classList.remove('entrando');
  void main.offsetWidth; // reinicia a animação de entrada
  main.classList.add('entrando');
  window.scrollTo(0, 0);
  main.focus({ preventScroll: true });

  try { await tela.montar?.(main, app, ehAtual); } catch (erro) { console.error(erro); }
}

// Botão "Ouvir" de qualquer tela: lê tudo que tem data-ler (ou para, se já estiver falando)
document.addEventListener('click', (e) => {
  const b = e.target.closest('[data-acao="ouvir"]');
  if (!b) return;
  if (document.body.classList.contains('falando')) pararDeFalar();
  else lerTela();
});

aplicarIcones(document);
montarMenus();
window.addEventListener('hashchange', mostrar);
mostrar();

// Já deixa os dados a caminho enquanto a pessoa olha a primeira tela.
// Primeiro o que a tela de início precisa; o resto só quando o celular fica à toa,
// para não disputar a internet com o que está na tela.
const quandoLivre = (fn, maxMs = 2000) =>
  ('requestIdleCallback' in window ? requestIdleCallback(() => fn(), { timeout: maxMs }) : setTimeout(fn, 300));

if (app.perfil.pronto) {
  app.lavouras().catch(() => {});
  app.dados().catch(() => {}).finally(() => quandoLivre(() => app.saude().catch(() => {})));
  quandoLivre(() => {
    acordarIA(); // o servidor gratuito da IA demora a acordar: já vai acordando
    carregarLeaflet().catch(() => {}); // o mapa do fogo abre na hora depois
  }, 5000);
}

// Funciona offline depois da primeira visita (PWA)
if ('serviceWorker' in navigator && location.protocol === 'https:') {
  navigator.serviceWorker.register('sw.js').catch(() => {});
}
