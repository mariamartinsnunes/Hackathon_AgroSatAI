// Junta clima desde o plantio + simulação de crescimento + satélite, para cada lavoura cadastrada.
// Guarda o resultado na memória: abrir a mesma lavoura de novo é instantâneo.
import { simular, comparar } from './crescimento.js';
import { buscarHistorico, buscarNdvi } from './api/index.js';
import { paraISO } from './util.js';

const memoria = new Map();

export function analisarLavoura(lavoura, ctx, hoje = new Date()) {
  const chave = [lavoura.id, lavoura.plantio, lavoura.ajusteGdd || 0, paraISO(hoje), ctx.municipio.geocodigo].join('|');
  if (memoria.has(chave)) return memoria.get(chave);

  const promessa = (async () => {
    const historico = await buscarHistorico({ ...ctx, inicio: lavoura.plantio, fim: paraISO(hoje) });
    const sim = simular(lavoura, historico, hoje);
    const sat = await buscarNdvi({ ...ctx, lavoura, serie: sim.serie, taxa: sim.taxa });
    const comp = comparar(sim, sat, hoje);
    return {
      lavoura, sim, sat, comp,
      exemplo: Boolean(historico.exemplo || sat.exemplo),
      fontes: [historico.fonte, sat.fonte].filter(Boolean).join(', '),
    };
  })();

  memoria.set(chave, promessa);
  promessa.catch(() => memoria.delete(chave));
  return promessa;
}

export async function analisarTodas(perfil, ctx, hoje = new Date()) {
  const lista = perfil.lavouras || [];
  const feitas = await Promise.all(lista.map((l) => analisarLavoura(l, ctx, hoje).catch(() => null)));
  return feitas.filter(Boolean);
}
