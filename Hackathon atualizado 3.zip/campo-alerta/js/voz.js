// ============================================================
//  VOZ — falar (ler a tela) e ouvir (entender comandos)
//  Falar: 1º tenta a voz clonada (ElevenLabs, pela função /api/voz do Vercel);
//         se não der, usa a voz do navegador (speechSynthesis), que funciona até sem internet.
//  Ouvir: SpeechRecognition — só Chrome/Edge, precisa de internet e HTTPS
//         (no Vercel já é HTTPS; local, "localhost" também vale).
// ============================================================

import { CONFIG } from './config.js';

const legenda = () => document.querySelector('.legenda');
let audioAtual = null;
const cacheAudio = new Map(); // texto -> áudio já gerado (economiza crédito da ElevenLabs)
let vozIAFora = false;        // se a voz IA falhar uma vez, usa a do navegador até recarregar
let vozBR = null;
let falaAtual = 0;

function escolherVoz() {
  const vozes = window.speechSynthesis?.getVoices() || [];
  vozBR = vozes.find((v) => v.lang === 'pt-BR' && /google|luciana|francisca|maria/i.test(v.name))
       || vozes.find((v) => v.lang?.startsWith('pt-BR'))
       || vozes.find((v) => v.lang?.startsWith('pt'))
       || null;
}
if ('speechSynthesis' in window) {
  escolherVoz();
  window.speechSynthesis.onvoiceschanged = escolherVoz;
}

function mostrarLegenda(texto, tipo = 'fala') {
  const el = legenda();
  if (!el) return;
  el.textContent = texto;
  el.dataset.tipo = tipo;
  el.hidden = !texto;
}

export const podeFalar = () => 'speechSynthesis' in window;
export const podeOuvir = () => 'SpeechRecognition' in window || 'webkitSpeechRecognition' in window;

// Pede o áudio da voz clonada para a função /api/voz (a chave fica escondida no Vercel)
async function audioDaIA(texto) {
  if (cacheAudio.has(texto)) return cacheAudio.get(texto);
  const r = await fetch(`${CONFIG.baseApi}/api/voz?texto=${encodeURIComponent(texto)}`);
  if (!r.ok || !(r.headers.get('content-type') || '').includes('audio')) throw new Error('voz IA indisponível (' + r.status + ')');
  const url = URL.createObjectURL(await r.blob());
  cacheAudio.set(texto, url);
  return url;
}

function comecar(texto) { mostrarLegenda(texto, 'fala'); document.body.classList.add('falando'); }
function terminouSe(minha) {
  if (minha === falaAtual) { mostrarLegenda(''); document.body.classList.remove('falando'); }
}

// Toca um arquivo de áudio (MP3) mostrando a legenda
export function tocarAudio(url, texto = '', minha = ++falaAtual) {
  return new Promise((fim) => {
    const a = new Audio(url);
    audioAtual = a;
    let acabou = false;
    const terminar = () => { if (acabou) return; acabou = true; terminouSe(minha); fim(); };
    a.onended = a.onerror = a.onpause = terminar;
    comecar(texto);
    a.play().catch(terminar);
  });
}

function falarNavegador(texto, minha) {
  return new Promise((fim) => {
    if (!podeFalar()) return fim();
    const u = new SpeechSynthesisUtterance(texto);
    u.lang = 'pt-BR';
    u.rate = 0.92;           // um pouco mais devagar: mais fácil de entender
    if (vozBR) u.voice = vozBR;
    let acabou = false;
    const terminar = () => { if (acabou) return; acabou = true; terminouSe(minha); fim(); };
    u.onend = u.onerror = terminar;
    // Segurança: alguns navegadores nunca avisam que terminou
    setTimeout(terminar, 2500 + texto.split(/\s+/).length * 480);
    comecar(texto);
    window.speechSynthesis.speak(u);
  });
}

// Fala um texto. Devolve uma Promise que termina quando acaba de falar.
export async function falar(texto) {
  if (!texto) return;
  pararDeFalar();
  const minha = ++falaAtual;
  if (CONFIG.vozIA?.ativa && !vozIAFora) {
    try {
      comecar(texto);
      const url = await audioDaIA(texto);
      if (minha !== falaAtual) return; // já pediram outra fala
      return await tocarAudio(url, texto, minha);
    } catch (e) {
      vozIAFora = true;
      console.warn('Voz IA indisponível, usando a voz do navegador:', e.message);
    }
  }
  return falarNavegador(texto, minha);
}

export function pararDeFalar() {
  if (podeFalar()) window.speechSynthesis.cancel();
  if (audioAtual) { audioAtual.pause(); audioAtual = null; }
  mostrarLegenda('');
  document.body.classList.remove('falando');
}

// LER A TELA: junta, em ordem, tudo que tem o atributo data-ler.
//   <h2 data-ler>Espere</h2>              -> lê o texto do elemento
//   <div data-ler="Fogo a 4 quilômetros"> -> lê o texto do atributo
export function textoDaTela(raiz = document.querySelector('#conteudo')) {
  return [...raiz.querySelectorAll('[data-ler]')]
    .filter((el) => !el.closest('[hidden]'))
    .map((el) => (el.dataset.ler || el.textContent).replace(/\s+/g, ' ').trim())
    .filter(Boolean)
    .join('. ')
    .replace(/\.\s*\./g, '.')
    .replace(/(\d+)\s?km/g, '$1 quilômetros')
    .replace(/(\d+)°/g, '$1 graus');
}

export function lerTela() { return falar(textoDaTela()); }

// OUVIR: devolve as frases que o reconhecedor entendeu (até 5 alternativas)
export function ouvir() {
  return new Promise((ok, erro) => {
    const R = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!R) return erro(new Error('sem-suporte'));
    pararDeFalar();
    const rec = new R();
    rec.lang = 'pt-BR';
    rec.interimResults = false;
    rec.maxAlternatives = 5;
    let entendeu = false;
    mostrarLegenda('Pode falar…', 'ouvindo');
    document.body.classList.add('ouvindo');
    rec.onresult = (e) => {
      entendeu = true;
      const frases = [...e.results[0]].map((a) => a.transcript.toLowerCase().trim());
      mostrarLegenda(`“${frases[0]}”`, 'ouvindo');
      ok(frases);
    };
    rec.onerror = (e) => erro(new Error(e.error || 'erro'));
    rec.onend = () => {
      document.body.classList.remove('ouvindo');
      if (!entendeu) { mostrarLegenda(''); erro(new Error('silencio')); }
    };
    rec.start();
  });
}

// ENTENDER: transforma o que a pessoa falou numa intenção.
// Palavras do jeito que o produtor fala, sem acento.
const INTENCOES = [
  { ir: 'foto', palavras: ['foto', 'folha', 'doenca', 'doente', 'mancha', 'praga', 'ferrugem', 'bicho', 'amarel', 'furad'] },
  { ir: 'saude', palavras: ['satelite', 'verde', 'cafezal', 'saude'] },
  { ir: 'lavouras', palavras: ['lavoura', 'plantacao', 'crescimento', 'crescendo', 'colher', 'colheita', 'soja'] },
  { ir: 'plantio', palavras: ['plantar', 'plantio', 'planto', 'muda', 'semente', 'epoca'] },
  { ir: 'fogo', palavras: ['fogo', 'queimada', 'fumaca', 'incendio', 'queimando'] },
  { ir: 'tempo', palavras: ['tempo', 'chuva', 'chover', 'sol', 'calor', 'frio', 'previsao', 'temperatura'] },
  { ir: 'avisos', palavras: ['aviso', 'alerta', 'novidade', 'recado'] },
  { ir: 'radio', palavras: ['radio', 'boletim', 'noticia'] },
  { ir: 'ligar', palavras: ['ligar', 'ligacao', 'telefone', 'tecnico'] },
  { ir: 'ler', palavras: ['ler', 'leia', 'fala ai', 'o que tem', 'repete', 'repetir'] },
  { ir: 'inicio', palavras: ['inicio', 'voltar', 'comeco', 'painel', 'casa'] },
];

const semAcento = (t) => t.normalize('NFD').replace(/[̀-ͯ]/g, '');

export function entender(frases) {
  for (const frase of frases) {
    const f = semAcento(frase);
    for (const it of INTENCOES) {
      if (it.palavras.some((p) => f.includes(p))) return { ir: it.ir, frase };
    }
  }
  return { ir: null, frase: frases[0] };
}
