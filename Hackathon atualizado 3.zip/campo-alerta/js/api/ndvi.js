// NDVI DA LAVOURA ao longo do tempo (para comparar com o crescimento esperado).
// Todo provedor devolve: { pontos: [{ data, ndvi }], zonas: [{ id: 'A1', ndvi }] | null, fonte }
import { CONFIG } from '../config.js';
import { ndviEsperado } from '../crescimento.js';
import { aleatorioDe as aleatorio } from '../util.js';


const limitar = (v) => Math.min(Math.max(Math.round(v * 100) / 100, 0), 1);

export const provedores = {
  async mock({ lavoura, serie, taxa }) {
    const atraso = CONFIG.demoNdvi.atrasoDias * taxa;
    const desloca = Math.floor(aleatorio(lavoura.id) * 5);
    const pontos = [];
    for (let i = 5 + desloca; i < serie.length; i += 5) {
      if (aleatorio(`${lavoura.id}${i}nuvem`) < 0.18) continue;
      const g = Math.max(serie[i].bruto - atraso, 0);
      const ruido = (aleatorio(`${lavoura.id}${i}r`) - 0.5) * 0.04;
      pontos.push({ data: serie[i].data, ndvi: limitar(ndviEsperado(lavoura.cultura, g) + ruido) });
    }

    let zonas = null;
    if (pontos.length) {
      const base = pontos[pontos.length - 1].ndvi;
      zonas = [];
      for (const linha of ['A', 'B', 'C']) {
        for (const coluna of [1, 2, 3]) {
          const id = `${linha}${coluna}`;
          const fraca = CONFIG.demoNdvi.zonaFraca && id === 'C1' ? -0.2 : 0;
          zonas.push({ id, ndvi: limitar(base + (aleatorio(lavoura.id + id) - 0.5) * 0.08 + fraca) });
        }
      }
    }
    return { pontos, zonas, fonte: 'Exemplo' };
  },

  async arquivo() {
    const r = await fetch('dados/ndvi.json');
    if (!r.ok) throw new Error('Arquivo dados/ndvi.json não encontrado');
    const d = await r.json();
    return { pontos: d.pontos || [], zonas: d.zonas || null, fonte: d.fonte || 'Sentinel-2 (processado)' };
  },
};
