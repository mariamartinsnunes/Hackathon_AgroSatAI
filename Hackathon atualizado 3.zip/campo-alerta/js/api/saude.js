// SAÚDE DA LAVOURA (NDVI do Sentinel-2) — todo provedor devolve:
// {
//   passagens: [{ data: 'AAAA-MM-DD', nuvem: bool, grade: [[ndvi...]...] | null }],  // mais antiga primeiro
//   colunas, linhas,           // tamanho da grade (cada célula ≈ 10 x 10 m)
//   talhao: [[x,y]...],        // contorno da lavoura, de 0 a 1 (relativo à imagem)
//   foto: 'url' | null,        // foto real (cor verdadeira). null = desenha simulação
//   proximaEmDias, fonte
// }
// NDVI: 0,8 = muito verde/saudável · 0,5 = atenção · 0,3 ou menos = planta sofrendo

import { CONFIG } from '../config.js';
import { caixasDasPartes, recortar } from '../satelite.js';

const COLS = 36, LINHAS = 27;
const PC = 'https://planetarycomputer.microsoft.com/api';
// NDVI = (infravermelho - vermelho) / (infravermelho + vermelho).
// No Sentinel-2 L2A (desde 2022) cada banda vem somada de 1000: por isso o "- 2000".
const NDVI = '(B08-B04)/(B08+B04-2000)';
const NUVEM = [3, 8, 9, 10]; // classes do mapa SCL: sombra de nuvem, nuvem média, nuvem alta, cirro

const diaISO = (d) => d.toISOString().slice(0, 10);

function poligonoGeo(bbox, pontos) {
  const ll = ([x, y]) => [bbox[0] + x * (bbox[2] - bbox[0]), bbox[3] - y * (bbox[3] - bbox[1])];
  const anel = pontos.map(ll);
  return { type: 'Feature', properties: {}, geometry: { type: 'Polygon', coordinates: [[...anel, anel[0]]] } };
}

// Fração da roça coberta por nuvem ou sombra (mapa de classes SCL do Sentinel-2)
function fracaoNublada(scl) {
  const [contagens, classes] = scl.histogram;
  return classes.reduce((soma, c, i) => soma + (NUVEM.includes(c) ? contagens[i] : 0), 0) / scl.count;
}

async function estatistica(item, params, feature) {
  const r = await fetch(`${PC}/data/v1/item/statistics?collection=sentinel-2-l2a&item=${item}&${params}`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(feature),
  });
  if (!r.ok) throw new Error('Planetary Computer respondeu ' + r.status);
  return Object.values((await r.json()).properties.statistics)[0];
}
export const TALHAO = [[0.17, 0.2], [0.83, 0.13], [0.89, 0.77], [0.13, 0.86]];

// Ruído suave e determinístico (mesma "roça" toda vez)
function ruido(x, y) {
  return (Math.sin(x * 12.9 + y * 4.1) + Math.sin(x * 5.3 - y * 9.7) + Math.sin((x + y) * 17.1)) / 3;
}

function gradeDoDia(queda) {
  // A mancha começa embaixo, à esquerda, e cresce com o tempo
  const cx = 0.3, cy = 0.72, s = 0.15 + queda * 0.35;
  return Array.from({ length: LINHAS }, (_, j) => Array.from({ length: COLS }, (_, i) => {
    const x = (i + 0.5) / COLS, y = (j + 0.5) / LINHAS;
    const g = Math.exp(-((x - cx) ** 2 + (y - cy) ** 2) / (2 * s * s));
    return +(0.76 + 0.035 * ruido(x, y) - queda * g).toFixed(3);
  }));
}

export const provedores = {
  async mock() {
    const hoje = new Date();
    const dias = [20, 15, 10, 5, 0].map((n) => new Date(hoje.getTime() - (n + 1) * 864e5).toISOString().slice(0, 10));
    const quedas = [0, 0.05, null, 0.17, 0.27]; // null = dia de nuvem
    return {
      passagens: dias.map((data, k) => ({ data, nuvem: quedas[k] === null, grade: quedas[k] === null ? null : gradeDoDia(quedas[k]) })),
      colunas: COLS, linhas: LINHAS, talhao: TALHAO, foto: null, proximaEmDias: 4,
      fonte: 'Simulação',
    };
  },

  // DADO REAL: Sentinel-2 pelo Microsoft Planetary Computer (grátis, sem chave, aceita CORS).
  // Busca as últimas passagens, descarta as nubladas e calcula o NDVI médio de cada uma das 9 partes.
  // Foto de fundo: Esri World Imagery (alta resolução, mas pode ser de meses atrás).
  async planetary() {
    const { bbox, talhao, nome } = CONFIG.lavouraDemo;
    const e = encodeURIComponent;

    const busca = await fetch(`${PC}/stac/v1/search`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        collections: ['sentinel-2-l2a'], bbox,
        datetime: `${diaISO(new Date(Date.now() - 80 * 864e5))}/${diaISO(new Date())}`,
        query: { 'eo:cloud_cover': { lt: 60 } },
        sortby: [{ field: 'datetime', direction: 'desc' }], limit: 30,
      }),
    });
    if (!busca.ok) throw new Error('Busca do Sentinel-2 falhou');
    const itens = (await busca.json()).features;

    // Uma imagem por dia (a com menos nuvem), da mais nova para a mais antiga
    const porDia = new Map();
    for (const f of itens) {
      const dia = f.properties.datetime.slice(0, 10);
      if (!porDia.has(dia) || f.properties['eo:cloud_cover'] < porDia.get(dia).properties['eo:cloud_cover']) porDia.set(dia, f);
    }
    const dias = [...porDia.entries()].sort((a, b) => (a[0] < b[0] ? 1 : -1)).slice(0, 10);

    const todo = poligonoGeo(bbox, talhao);
    const partesGeo = caixasDasPartes(talhao).map(({ caixa }) => {
      const pedaco = recortar(talhao, caixa);
      return pedaco.length >= 3 ? poligonoGeo(bbox, pedaco) : null;
    });

    // 1º passo (rápido, tudo junto): quanto da roça estava coberto de nuvem em cada data
    const nublado = await Promise.all(dias.map(([, item]) =>
      estatistica(item.id, 'assets=SCL&categorical=true', todo).then(fracaoNublada).catch(() => 1)));

    // Pega as datas mais recentes até juntar 4 fotos limpas (mais de 10% de nuvem = "nublado")
    const escolhidos = [];
    let limpas = 0;
    for (let k = 0; k < dias.length && limpas < 4; k++) {
      const limpa = nublado[k] <= 0.1;
      escolhidos.push({ data: dias[k][0], id: dias[k][1].id, nuvem: !limpa });
      if (limpa) limpas++;
    }
    if (limpas < 2) throw new Error('Sem fotos limpas do satélite nas últimas semanas');
    escolhidos.reverse(); // da mais antiga para a mais nova

    // 2º passo: NDVI de cada uma das 9 partes, só nas fotos limpas
    const params = `assets=B04&assets=B08&asset_as_band=true&expression=${e(NDVI)}`;
    const passagens = await Promise.all(escolhidos.map(async ({ data, id, nuvem }) => {
      if (nuvem) return { data, nuvem: true, grade: null };
      const partes = await Promise.all(partesGeo.map((g) => (g ? estatistica(id, params, g).then((x) => x.mean).catch(() => null) : null)));
      const imagem = `${PC}/data/v1/item/bbox/${bbox.join(',')}/960x720.png?collection=sentinel-2-l2a&item=${id}&${params}&rescale=0.3,0.8&colormap_name=rdylgn`;
      return { data, nuvem: false, partes, imagem };
    }));

    const ultima = new Date(escolhidos.at(-1).data);
    const desde = Math.floor((Date.now() - ultima) / 864e5);
    return {
      passagens, talhao, nome,
      foto: `https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/export?bbox=${bbox.join(',')}&bboxSR=4326&imageSR=4326&size=960,720&format=jpg&f=image`,
      credito: 'Cores da saúde: Copernicus Sentinel-2 (via Microsoft Planetary Computer). Foto de fundo: Esri, Maxar, Earthstar Geographics.',
      proximaEmDias: Math.max(1, 5 - (desde % 5)),
      fonte: 'Sentinel-2',
    };
  },

  // Lê o que o script scripts/gerar_lavoura.py salvou (dados reais do Copernicus/Sentinel-2)
  async copernicus() {
    const r = await fetch('dados/lavoura.json');
    if (!r.ok) throw new Error('Rode scripts/gerar_lavoura.py primeiro');
    const d = await r.json();
    return { ...d, fonte: 'Copernicus Sentinel-2' };
  },
};
