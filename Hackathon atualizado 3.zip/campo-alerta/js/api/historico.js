// HISTÓRICO DO CLIMA desde o plantio (temperatura e chuva de cada dia) — usado pelas lavouras.
// Todo provedor devolve: { dias: [{ data, max, min, chuvaMm }], fonte }
import { CONFIG } from '../config.js';
import { arredondar, deISO, paraISO, somarDias, diasEntre, aleatorioDe as aleatorio } from '../util.js';


function diaDoAno(d) {
  return diasEntre(new Date(d.getFullYear(), 0, 0), d);
}

export const provedores = {
  async mock({ inicio, fim }) {
    const ini = deISO(inicio);
    const total = diasEntre(ini, deISO(fim));
    const dias = [];
    for (let i = 0; i <= total; i++) {
      const dia = somarDias(ini, i);
      const data = paraISO(dia);
      const estacao = Math.cos((2 * Math.PI * (diaDoAno(dia) - 20)) / 365);
      const max = 29.5 + 3.5 * estacao + (aleatorio(data + 'x') - 0.5) * 5;
      const min = 16 + 4 * estacao + (aleatorio(data + 'n') - 0.5) * 3;
      const chove = aleatorio(data + 'c') < 0.26 + 0.2 * estacao;
      const chuvaMm = chove ? Math.round(2 + aleatorio(data + 'q') * 24) : 0;
      dias.push({ data, max: Math.round(max * 10) / 10, min: Math.round(min * 10) / 10, chuvaMm });
    }
    return { dias, fonte: 'Exemplo' };
  },

  async nasa({ centro, inicio, fim }) {
    const q = `fonte=nasa-hist&lat=${arredondar(centro.lat)}&lon=${arredondar(centro.lon)}&inicio=${inicio}&fim=${fim}`;
    const r = await fetch(`${CONFIG.baseApi}/api/clima?${q}`);
    if (!r.ok) throw new Error('NASA POWER fora do ar');
    return r.json();
  },
};
