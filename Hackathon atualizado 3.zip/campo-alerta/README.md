# Campo Alerta

App (celular e computador) que avisa o pequeno produtor de café sobre tempo, plantio, fogo e doença na folha, por voz. Tem também um boletim de 1 minuto para a rádio e um "0800" para celular de botão.
Feito para o Hackathon de Dados Abertos (IFSP Araraquara, 2026).

## Rodar no VS Code

1. Abra esta pasta no VS Code (Arquivo > Abrir pasta).
2. Instale a extensão **Live Server** e clique em **Go Live** (canto de baixo).
   Ou rode no terminal: `npm run dev`. Depois abra http://localhost:3000
3. Use o **Chrome ou o Edge**. São os navegadores que ouvem a voz.

> Não abra o `index.html` com dois cliques: os módulos JS precisam de um servidor.

## Onde mexer

| Quero... | Arquivo |
|---|---|
| Trocar de API (mock → real) | `js/config.js` |
| Mudar textos dos avisos, semáforo, boletim | `js/regras.js` |
| Mudar uma tela | `js/telas/<tela>.js` |
| Mudar cores e tamanhos | `css/estilo.css` (topo: `:root`) |
| Palavras que a voz entende | `js/voz.js` (lista `INTENCOES`) |
| Fases, graus-dia e colheita das lavouras | `js/crescimento.js` |

## APIs: como trocar sem quebrar nada

Cada serviço tem vários **provedores**, e todos devolvem **o mesmo formato**. As telas nunca chamam uma API direto: elas chamam `js/api/index.js`.

```js
// js/config.js
provedores: {
  clima: 'openmeteo', // 'mock' | 'inmet' | 'nasa'
  fogo: 'mock',      // 'inpe'  | 'firms'
  plantio: 'zarc',   // 'mock'   (ZARC do MAPA, dado REAL já incluído)
  produtos: 'agrofit', // 'mock' (Agrofit do MAPA, dado REAL já incluído)
  ia: 'api',         // 'teachable' | 'mock'
  saude: 'planetary', // 'mock' | 'copernicus'   (satélite real da lavoura)
  historico: 'mock', // 'nasa'                   (clima desde o plantio, Minhas lavouras)
  ndvi: 'mock',      // 'arquivo'                (verde de cada lavoura, Minhas lavouras)
}
```

- Se o provedor real falhar, o app usa o **mock** e mostra a etiqueta "Dados de exemplo". Assim a demo nunca fica em branco.
- Para testar outra API: crie mais uma função em `js/api/<servico>.js` que devolva o mesmo formato e coloque o nome dela no `config.js`.
- **Open-Meteo** (tempo) é chamado direto do navegador: aceita CORS e não pede chave. Manda só a localização arredondada (~11 km). Traz temperatura agora, umidade, vento, chuva e previsão de 5 dias. É grátis para uso não comercial.
- **INMET e INPE** passam pelas funções do Vercel (`api/clima.js` e `api/fogo.js`), por causa de CORS. Elas só funcionam com o projeto publicado no Vercel (ou rodando `vercel dev`).
- **ZARC e Agrofit (dados.agricultura.gov.br) já estão ligados com dado real**, em JSON pequeno dentro de `dados/`:
  - `dados/zarc-cafe.json`: Tábua de Risco do ZARC, arquivo *Perene, Olerícola e Sem Safra* (535 MB, 2,3 milhões de linhas). Ficou só **Café Arábica Implantação, sequeiro**, nos **640 municípios de SP** com café zoneado (73 deles só têm canéfora). Portarias 582/2021 (arábica) e 07/2024 (canéfora). Usado no **semáforo de plantio** (início, avisos, rádio, telefone e voz).
  - `dados/agrofit-cafe.json`: Agrofit, *Produto Formulado* (392 MB). Conta os registros ativos para café de cada doença que a IA reconhece (ex.: ferrugem 257, olho-pardo 173, bicho-mineiro 242, phoma 97). Usado em **Ver produtos registrados**, depois da foto da folha. Só contagem: nada de nome comercial nem dose.
  - Na tela de início aparece "Dado oficial do MAPA · ZARC" e, no rodapé, a fonte de cada informação.
- Para refazer com um arquivo mais novo, os scripts continuam valendo:
  ```
  python scripts/gerar_zarc.py "dados-abertos-tabua-de-risco-safra-perene-olericola-sem-safra.csv"
  python scripts/gerar_agrofit.py "Produto Formulado.CSV"
  ```
  Os scripts mostram os nomes das colunas. Se não acharem alguma, ajustem o nome no script.
- **IA da folha**: veja `modelo/LEIA.md` (Teachable Machine).

## IA da folha (API de vocês)

O app manda a foto da folha para `https://fastapi-ml-7fcy.onrender.com/predict` (FastAPI, MobileNetV2 treinado com DigiPathos). Código em `js/api/ia.js`, `ia: 'api'` no `config.js`.

- A foto é **reduzida para 512 px** antes de enviar (fica ~20 KB, rápido até no 3G).
- A API reconhece 6 doenças: ferrugem, cercosporiose (olho-pardo), bicho-mineiro, mancha-aureolada, mancha-manteigosa e phoma. O app mostra as 3 mais prováveis.
- **Ela não tem a classe "folha sadia"**: sempre aponta uma doença. O app avisa isso na tela. Vale treinar essa classe.
- **Servidor gratuito do Render dorme** depois de um tempo parado e leva até 1 minuto para acordar. O app já "acorda" a API ao abrir e ao entrar na tela da foto, e avisa a pessoa se demorar. **Antes do pitch, abram a tela da foto uma vez.**
- Se a IA falhar, o app **não inventa diagnóstico**: mostra "Não consegui analisar" com o botão do técnico.

**CORS (importante):** hoje a API bloqueia chamadas de outros sites, então o app não consegue chamar direto. Duas saídas:
1. **Melhor:** quem fez a API adiciona no `main.py` e faz deploy de novo:
   ```python
   from fastapi.middleware.cors import CORSMiddleware
   app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["GET", "POST"], allow_headers=["*"])
   ```
2. **Já pronto:** publicado no Vercel, o app passa pela função `api/folha.js`, que repassa a foto e não sofre com CORS.

No Live Server, sem uma das duas, a análise da foto não funciona.

## Voz: como funciona

**O app fala (lê a tela).** Todo texto que deve ser lido tem o atributo `data-ler`:

```html
<h2 data-ler>Espere</h2>                       <!-- lê o texto -->
<a data-ler="Fogo a 4 quilômetros">…</a>        <!-- lê o que está no atributo -->
```

O botão amarelo **Ouvir** junta, em ordem, tudo que tem `data-ler` e fala com `speechSynthesis` (voz pt-BR do sistema, funciona sem internet). Tela nova = é só marcar o que deve ser lido.

**O app ouve (comandos).** O botão **Falar** usa `SpeechRecognition` (Chrome/Edge, precisa de internet e HTTPS; `localhost` também vale). O que a pessoa fala passa por `entender()` em `js/voz.js`, que procura palavras-chave:

| Fala | Faz |
|---|---|
| "vai chover?", "tempo", "calor" | responde o tempo |
| "posso plantar?", "muda" | responde o semáforo do plantio |
| "tem fogo?", "queimada" | responde o fogo mais perto |
| "folha doente", "mancha", "ferrugem" | abre a foto da folha |
| "aviso", "rádio", "ligar", "voltar" | abre a tela |

Os 4 botões de exemplo na tela Falar funcionam como se a pessoa tivesse falado. Se o microfone falhar no pitch, toque neles.

## Minhas lavouras: crescimento simulado + satélite

O produtor cadastra o que plantou (soja ou café), a área e o dia do plantio. O app conta os dias, soma o calor de cada dia (graus-dia) e mostra a planta crescendo por fases. Quando chega a época, avisa.

| Quero... | Arquivo |
|---|---|
| Mudar fases, graus-dia e curva de NDVI de uma cultura | `js/crescimento.js` (objeto `CULTURAS`) |
| Mudar os desenhos da planta | `js/planta.js` |
| Trocar a fonte de temperatura e chuva | `js/config.js` → `historico: 'mock' \| 'nasa'` |
| Trocar a fonte do satélite | `js/config.js` → `ndvi: 'mock' \| 'arquivo'` |
| Mudar os textos de atraso e colheita | `js/crescimento.js` (`comparar`, `textoColheita`) |

**Como funciona**
- Cada dia soma `(Tmax + Tmin) / 2 - Tbase`. Cada fase acontece quando a soma chega a um valor. A janela de colheita vem do ritmo recente de calor (soja: últimos 21 dias; café: último ano).
- O satélite entrega NDVI (verde da vegetação) a cada ~5 dias. O app compara com o NDVI esperado para aquele ponto da simulação. Se está abaixo, diz quantos dias de atraso e cruza com os dias sem chuva (pode ser água) ou sugere olhar praga, solo e falha de plantio.
- O mapa 3x3 mostra a zona mais fraca ("comece pela C1").
- O check-in ("Confere com a sua lavoura?") ajusta a simulação com o que o produtor vê.

**Atenção: o que ainda é de exemplo**
- `historico: 'nasa'` usa a função `api/clima.js` (NASA POWER). Precisa do projeto publicado no Vercel e ainda não foi testado com a API de verdade.
- `ndvi: 'mock'` inventa pontos de NDVI (com atraso de `demoNdvi.atrasoDias` para a demo). `ndvi: 'arquivo'` lê `dados/ndvi.json` no formato `{ "fonte": "...", "pontos": [{ "data": "AAAA-MM-DD", "ndvi": 0.6 }], "zonas": [{ "id": "A1", "ndvi": 0.6 }] }`. NDVI de verdade vem do Sentinel-2 (Copernicus) e precisa ser processado fora do app.
- Os valores de graus-dia e as curvas de NDVI são aproximações. Confiram com a Embrapa ou um agrônomo antes de apresentar como dado oficial.
- No café o NDVI muda pouco entre as fases: o aviso de atraso funciona melhor na soja.
- Lavouras ficam só no aparelho (localStorage). Para o servidor vai só a localização arredondada (~11 km).

## Satélite: saúde da lavoura com dado real (tela `#/saude`)

A tela abre pelo cartão **Satélite** do início. Mostra:
- a foto aérea da roça com o **índice de verde (NDVI)** pintado por cima: verde = saudável, amarelo = atenção, vermelho = sofrendo;
- a roça dividida em 9 partes. A parte que mais perdeu verde ganha o marcador **"Olhe aqui"**;
- as datas em que o satélite passou (a cada 5 dias), com um exemplo de dia nublado;
- o aviso "Vá lá e tire foto de uma folha", que leva para a IA da folha e para o técnico.

Pode rodar com dado real (`saude: 'planetary'`) ou em **simulação** (`saude: 'mock'`), e a tela mostra isso numa etiqueta. Para usar dados reais, um script deve salvar `dados/lavoura.json` no mesmo formato descrito em `js/api/lavoura.js` (Copernicus Data Space ou Brazil Data Cube/INPE). Depois é só trocar para `saude: 'copernicus'`.

## Tela Satélite (fogo)

A tela Satélite abre ao tocar no cartão **Alerta**. Ela mostra:
- a imagem de ontem do satélite **MODIS Terra** (NASA GIBS, sem chave), que deixa ver fumaça e queimadas grandes;
- a roça, o raio de 30 km e os focos de fogo do INPE.

O mapa usa **Leaflet** (cdnjs). Sem internet, aparece o mapinha desenhado no lugar.

Próximo passo: o índice de verde da lavoura (NDVI) pelo **SATVeg/Embrapa** (AgroAPI), para mostrar "sua lavoura está mais seca que o normal".

## Voz clonada (ElevenLabs)

O app fala com a voz clonada quando está publicado no Vercel. Rodando no Live Server, ele usa a voz do navegador sozinho.

1. Na ElevenLabs, clone a voz e copie o **Voice ID**. Gere uma **API key**.
2. No Vercel: **Settings > Environment Variables**. Crie `ELEVENLABS_API_KEY` e `ELEVENLABS_VOICE_ID` (veja `.env.example`). Depois faça **Redeploy**.
3. Pronto: o botão Ouvir, a tela Falar, a rádio e o telefone passam a usar a voz clonada (`api/voz.js`).

- **A chave nunca vai no código do app nem no GitHub**: quem abre o site veria a chave e gastaria seus créditos.
- Cada frase nova gasta crédito. O app guarda o áudio já gerado e o Vercel também.
- Para gerar o MP3 do boletim para o pitch: `python scripts/gerar_audio.py boletim.txt boletim.mp3`.
- Só clone a voz de alguém que **autorizou**. O app mostra "Voz gerada por IA" na rádio.

## Ética e privacidade (critério eliminatório)

- Nome e localização exata ficam **só no aparelho** (localStorage). Para o servidor vai só o município, ou a localização arredondada (~11 km) no caso do fogo.
- A distância até o fogo é calculada **no celular**.
- A foto da folha **não sai do celular**: o modelo roda no navegador.
- A IA mostra sempre **3 possibilidades**, nunca certeza, e o botão **Chamar técnico**.
- Agrofit: só **contagem** de produtos registrados. Nunca nome com dose. Aviso de receituário agronômico.

## Publicar (Vercel)

```
npm i -g vercel
vercel        # na pasta do projeto
```

Pronto: o app fica em HTTPS (a voz funciona) e as funções `/api/clima` e `/api/fogo` passam a existir.

## Velocidade e visual

- **Troca de tela instantânea:** nenhuma tela espera a internet para abrir. O satélite abre com o quadro vazio e se completa sozinho.
- **Resultado guardado no aparelho** (`js/api/index.js`): tempo e fogo valem 30 min, plantio e produtos 7 dias, satélite 6 h. Sem internet, mostra o último valor salvo (com aviso). Nada sai do celular.
- **Tempo máximo por API:** tempo 6 s, fogo 8 s, satélite 30 s. Passou disso, usa o último valor salvo ou o exemplo. A IA da folha nunca cai no exemplo.
- **Visual:** verde #006633, títulos Poppins (negrito + fino), texto Roboto, botões de canto 10 px com sombra, menu com o item atual em pílula verde. As cores ficam todas em `:root` no começo de `css/estilo.css`.

## Fontes de dados

ZARC e Agrofit (MAPA, dados.agricultura.gov.br) · INPE Queimadas · INMET · NASA POWER/FIRMS (reserva). Fontes de letra: Poppins (títulos e botões) e Roboto (texto), licença OFL, guardadas em `fontes/`.
